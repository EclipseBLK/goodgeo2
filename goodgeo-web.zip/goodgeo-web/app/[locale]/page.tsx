import { getTranslations, setRequestLocale } from 'next-intl/server';

export default async function HomePage({
  params,
}: {
  params: Promise<{ locale: string }>;
}) {
  const { locale } = await params;
  setRequestLocale(locale);
  const t = await getTranslations('home');

  return (
    <main>
      {/* HERO */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-b from-brand-primary/20 to-transparent pointer-events-none" />
        <div className="max-w-6xl mx-auto px-4 pt-20 pb-24 relative">
          <div className="max-w-3xl">
            <h1 className="text-4xl md:text-6xl font-bold leading-tight mb-6">
              {t('heroTitle')}
            </h1>
            <p className="text-lg md:text-xl text-slate-300 mb-4">
              {t('heroSubtitle')}
            </p>

            {/* Юридическое уведомление */}
            <div className="mt-6 p-4 bg-brand-surface/60 border border-brand-border rounded-xl">
              <div className="flex items-start gap-3">
                <svg className="w-5 h-5 text-brand-accent mt-0.5 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
                </svg>
                <p className="text-sm text-slate-300 leading-relaxed">{t('heroNotice')}</p>
              </div>
            </div>

            {/* CTA */}
            <div className="mt-8 flex flex-col sm:flex-row gap-3">
              <a href="#download" className="px-6 py-3 bg-brand-accent hover:bg-brand-accent/90 text-white font-semibold rounded-xl transition text-center">
                {t('ctaTrial')}
              </a>
              <span className="px-6 py-3 border border-brand-border rounded-xl text-center text-slate-300">
                {t('ctaPrice')}
              </span>
            </div>
            <p className="mt-3 text-sm text-slate-400">{t('trustNote')}</p>
          </div>
        </div>
      </section>

      {/* FEATURES */}
      <section className="py-20 bg-brand-surface/30">
        <div className="max-w-6xl mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-3">{t('featuresTitle')}</h2>
            <p className="text-slate-300 max-w-2xl mx-auto">{t('featuresSubtitle')}</p>
          </div>

          <div className="grid md:grid-cols-3 gap-6">
            <FeatureCard
              icon={
                <svg className="w-7 h-7" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" />
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" />
                </svg>
              }
              title={t('feature1Title')}
              text={t('feature1Text')}
            />
            <FeatureCard
              icon={
                <svg className="w-7 h-7" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 20l-5.447-2.724A1 1 0 013 16.382V5.618a1 1 0 011.447-.894L9 7m0 13l6-3m-6 3V7m6 10l4.553 2.276A1 1 0 0021 18.382V7.618a1 1 0 00-.553-.894L15 4m0 13V4m0 0L9 7" />
                </svg>
              }
              title={t('feature2Title')}
              text={t('feature2Text')}
            />
            <FeatureCard
              icon={
                <svg className="w-7 h-7" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
                </svg>
              }
              title={t('feature3Title')}
              text={t('feature3Text')}
            />
          </div>
        </div>
      </section>

      {/* CTA SECTION */}
      <section id="download" className="py-20">
        <div className="max-w-4xl mx-auto px-4 text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">{t('ctaTitle')}</h2>
          <p className="text-lg text-slate-300 mb-8">{t('ctaText')}</p>

          <div className="flex flex-col sm:flex-row gap-3 justify-center mb-6">
            
              <a href="#"
              className="flex items-center gap-3 px-6 py-3 bg-brand-surface hover:bg-brand-primary border border-brand-border rounded-xl transition"
            >
              <svg className="w-7 h-7" viewBox="0 0 24 24" fill="currentColor">
                <path d="M17.523 15.34l1.802-3.124a.378.378 0 00-.654-.378l-1.823 3.16C15.473 14.32 13.802 13.91 12 13.91c-1.802 0-3.473.41-4.848 1.087L5.33 11.838a.378.378 0 00-.654.378l1.802 3.124C3.34 17.022 1.135 19.788 1 23h22c-.135-3.213-2.34-5.978-5.477-7.66zM6.477 20.07a.93.93 0 110-1.86.93.93 0 010 1.86zm11.046 0a.93.93 0 110-1.86.93.93 0 010 1.86z" />
              </svg>
              <div className="text-left">
                <div className="text-xs text-slate-400">Android</div>
                <div className="font-semibold">{t('ctaAndroid')}</div>
              </div>
            </a>

            
              <a href="#"
              className="flex items-center gap-3 px-6 py-3 bg-brand-surface hover:bg-brand-primary border border-brand-border rounded-xl transition"
            >
              <svg className="w-7 h-7" viewBox="0 0 24 24" fill="currentColor">
                <path d="M17.05 20.28c-.98.95-2.05.8-3.08.35-1.09-.46-2.09-.48-3.24 0-1.44.62-2.2.44-3.06-.35C2.79 15.25 3.51 7.59 9.05 7.31c1.35.07 2.29.74 3.08.8 1.18-.24 2.31-.93 3.57-.84 1.51.12 2.65.72 3.4 1.8-3.12 1.87-2.38 5.98.48 7.13-.57 1.5-1.31 2.99-2.54 4.09zM12.03 7.25c-.15-2.23 1.66-4.07 3.74-4.25.29 2.58-2.34 4.5-3.74 4.25z" />
              </svg>
              <div className="text-left">
                <div className="text-xs text-slate-400">iOS</div>
                <div className="font-semibold">{t('ctaIos')}</div>
              </div>
            </a>
          </div>

          
            <a href="#"
            className="inline-block px-8 py-3 bg-brand-accent hover:bg-brand-accent/90 text-white font-semibold rounded-xl transition"
          >
            {t('ctaButton')}
          </a>
        </div>
      </section>
    </main>
  );
}

function FeatureCard({
  icon,
  title,
  text,
}: {
  icon: React.ReactNode;
  title: string;
  text: string;
}) {
  return (
    <div className="p-6 bg-brand-bg border border-brand-border rounded-2xl hover:border-brand-accent/50 transition">
      <div className="w-12 h-12 rounded-xl bg-brand-accent/10 text-brand-accent flex items-center justify-center mb-4">
        {icon}
      </div>
      <h3 className="text-xl font-semibold mb-2">{title}</h3>
      <p className="text-slate-300 leading-relaxed">{text}</p>
    </div>
  );
}