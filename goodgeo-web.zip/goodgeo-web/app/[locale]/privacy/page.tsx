import { getTranslations, setRequestLocale } from 'next-intl/server';
import { Link } from '@/i18n/routing';

export default async function PrivacyPage({
  params,
}: {
  params: Promise<{ locale: string }>;
}) {
  const { locale } = await params;
  setRequestLocale(locale);
  const t = await getTranslations('privacy');

  return (
    <main className="max-w-3xl mx-auto px-4 py-16">
      <h1 className="text-4xl font-bold mb-2">{t('title')}</h1>
      <p className="text-sm text-slate-400 mb-8">
        {t('lastUpdated')}: April 28, 2026
      </p>

      {locale !== 'en' && (
        <div className="mb-8 p-4 bg-brand-surface/60 border border-brand-border rounded-xl text-sm text-slate-300">
          {t('languageNote')}
        </div>
      )}

      <article className="prose prose-invert max-w-none space-y-6 text-slate-300 leading-relaxed">
        <section>
          <h2 className="text-2xl font-semibold text-white mt-8 mb-3">1. Introduction</h2>
          <p>
            This Privacy Policy describes how GoodGeo (&quot;we&quot;, &quot;us&quot;, &quot;our&quot;) collects, uses, and protects
            information when you use the GoodGeo mobile application and website (the &quot;Service&quot;).
            By using the Service, you agree to the collection and use of information in accordance with this policy.
          </p>
        </section>

        <section>
          <h2 className="text-2xl font-semibold text-white mt-8 mb-3">2. Information We Collect</h2>
          <h3 className="text-lg font-semibold text-white mt-4 mb-2">2.1 Account Information</h3>
          <ul className="list-disc pl-6 space-y-1">
            <li>Email address (required for account creation)</li>
            <li>Optional display name</li>
            <li>Password (stored encrypted; we cannot read it)</li>
          </ul>

          <h3 className="text-lg font-semibold text-white mt-4 mb-2">2.2 Device Information</h3>
          <ul className="list-disc pl-6 space-y-1">
            <li>Device fingerprint (a hashed identifier used to prevent trial abuse)</li>
            <li>Operating system, OS version, device model</li>
            <li>App version</li>
          </ul>

          <h3 className="text-lg font-semibold text-white mt-4 mb-2">2.3 Usage Data</h3>
          <ul className="list-disc pl-6 space-y-1">
            <li>Search history (addresses you searched within the app)</li>
            <li>Visited entrances (for personal statistics)</li>
            <li>Subscription status</li>
            <li>Approximate location (only when actively using navigation)</li>
          </ul>

          <h3 className="text-lg font-semibold text-white mt-4 mb-2">2.4 What We Do NOT Collect</h3>
          <ul className="list-disc pl-6 space-y-1">
            <li>We do not collect biometric data</li>
            <li>We do not access your contacts, photos, or messages</li>
            <li>We do not track your location in the background</li>
            <li>We do not store intercom codes or building access information</li>
          </ul>
        </section>

        <section>
          <h2 className="text-2xl font-semibold text-white mt-8 mb-3">3. How We Use Your Information</h2>
          <ul className="list-disc pl-6 space-y-1">
            <li>To provide and maintain the Service</li>
            <li>To manage your subscription and billing</li>
            <li>To prevent fraudulent trial reuse via device fingerprinting</li>
            <li>To improve the app and fix technical issues</li>
            <li>To communicate with you about service updates and support</li>
          </ul>
        </section>

        <section>
          <h2 className="text-2xl font-semibold text-white mt-8 mb-3">4. Data Sharing</h2>
          <p>We do not sell your personal data. We share data only with:</p>
          <ul className="list-disc pl-6 space-y-1 mt-2">
            <li><strong>Supabase</strong> — backend and database hosting (EU servers, GDPR-compliant)</li>
            <li><strong>Apple App Store / Google Play</strong> — for subscription management</li>
            <li><strong>Mapbox</strong> — for map rendering (no personal data is sent)</li>
          </ul>
        </section>

        <section>
          <h2 className="text-2xl font-semibold text-white mt-8 mb-3">5. Your Rights (GDPR)</h2>
          <p>If you are in the European Economic Area, you have the right to:</p>
          <ul className="list-disc pl-6 space-y-1 mt-2">
            <li>Access your personal data</li>
            <li>Correct inaccurate data</li>
            <li>Request deletion of your data</li>
            <li>Export your data in a portable format</li>
            <li>Withdraw consent at any time</li>
            <li>Lodge a complaint with a supervisory authority</li>
          </ul>
          <p className="mt-3">
            To exercise these rights, contact us at <a href="mailto:support@goodgeo.app" className="text-brand-accent hover:underline">support@goodgeo.app</a>.
          </p>
        </section>

        <section>
          <h2 className="text-2xl font-semibold text-white mt-8 mb-3">6. Data Retention</h2>
          <p>
            We retain your account data while your account is active. After account deletion,
            we permanently remove your personal data within 30 days, except where retention is
            required by law (e.g., billing records kept for tax purposes).
          </p>
        </section>

        <section>
          <h2 className="text-2xl font-semibold text-white mt-8 mb-3">7. Security</h2>
          <p>
            We use industry-standard security measures including encrypted connections (HTTPS),
            encrypted password storage, and Row-Level Security at the database level.
            However, no method of transmission over the internet is 100% secure.
          </p>
        </section>

        <section>
          <h2 className="text-2xl font-semibold text-white mt-8 mb-3">8. Children&apos;s Privacy</h2>
          <p>
            The Service is not intended for users under 16. We do not knowingly collect data
            from children under 16. If you believe we have collected such data, please contact us.
          </p>
        </section>

        <section>
          <h2 className="text-2xl font-semibold text-white mt-8 mb-3">9. Changes to This Policy</h2>
          <p>
            We may update this Privacy Policy from time to time. We will notify you of any
            significant changes via the app or by email.
          </p>
        </section>

        <section>
          <h2 className="text-2xl font-semibold text-white mt-8 mb-3">10. Contact</h2>
          <p>
            For any questions about this Privacy Policy, contact us at:{' '}
            <a href="mailto:support@goodgeo.app" className="text-brand-accent hover:underline">
              support@goodgeo.app
            </a>
          </p>
        </section>
      </article>

      <div className="mt-12 pt-8 border-t border-brand-border">
        <Link href="/support" className="text-brand-accent hover:underline">
          → {t('contactCta')}
        </Link>
      </div>
    </main>
  );
}