import { getTranslations, setRequestLocale } from 'next-intl/server';

export default async function SupportPage({
  params,
}: {
  params: Promise<{ locale: string }>;
}) {
  const { locale } = await params;
  setRequestLocale(locale);
  const t = await getTranslations('support');

  return (
    <main className="max-w-3xl mx-auto px-4 py-16">
      <h1 className="text-4xl md:text-5xl font-bold mb-3">{t('title')}</h1>
      <p className="text-lg text-slate-300 mb-12">{t('subtitle')}</p>

      {/* Email card */}
      <div className="p-6 bg-brand-surface/60 border border-brand-border rounded-2xl mb-12">
        <div className="flex items-start gap-4">
          <div className="w-12 h-12 rounded-xl bg-brand-accent/10 text-brand-accent flex items-center justify-center flex-shrink-0">
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
            </svg>
          </div>
          <div className="flex-1">
            <p className="text-sm text-slate-400 mb-1">{t('emailLabel')}</p>
            
             <a href={`mailto:${t('emailValue')}`}
              className="text-xl font-semibold text-brand-accent hover:underline"
            >
              {t('emailValue')}
            </a>
            <p className="text-sm text-slate-400 mt-3">{t('responseTime')}</p>
          </div>
        </div>
      </div>

      {/* FAQ */}
      <section>
        <h2 className="text-2xl font-bold mb-6">{t('faqTitle')}</h2>
        <div className="space-y-4">
          <FaqItem question={t('faq1Q')} answer={t('faq1A')} />
          <FaqItem question={t('faq2Q')} answer={t('faq2A')} />
          <FaqItem question={t('faq3Q')} answer={t('faq3A')} />
          <FaqItem question={t('faq4Q')} answer={t('faq4A')} />
        </div>
      </section>
    </main>
  );
}

function FaqItem({ question, answer }: { question: string; answer: string }) {
  return (
    <details className="group p-5 bg-brand-surface/30 border border-brand-border rounded-xl cursor-pointer hover:border-brand-accent/50 transition">
      <summary className="flex items-center justify-between font-semibold list-none">
        <span>{question}</span>
        <svg
          className="w-5 h-5 text-brand-accent transition-transform group-open:rotate-180"
          fill="none"
          stroke="currentColor"
          viewBox="0 0 24 24"
        >
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
        </svg>
      </summary>
      <p className="mt-3 text-slate-300 leading-relaxed">{answer}</p>
    </details>
  );
}