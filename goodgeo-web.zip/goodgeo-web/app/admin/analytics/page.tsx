import {
  getRegistrationsStats,
  getPaymentStats,
  getDuplicateDeviceAlerts,
  getCompletedBuildingsHeatmap,
  getActivityStats,
} from '@/lib/admin/analytics';
import AnalyticsClient from '@/components/admin/analytics/AnalyticsClient';

export const dynamic = 'force-dynamic';

export default async function AnalyticsPage() {
  const [registrations, payments, alerts, heatmapPoints, activity] = await Promise.all([
    getRegistrationsStats(),
    getPaymentStats(),
    getDuplicateDeviceAlerts(),
    getCompletedBuildingsHeatmap(),
    getActivityStats(),
  ]);

  return (
    <div>
      <h1 className="text-2xl font-bold text-slate-800 mb-2">Аналитика</h1>
      <p className="text-slate-500 mb-8">Метрики роста и активности</p>
      <AnalyticsClient
        registrations={registrations}
        payments={payments}
        alerts={alerts}
        heatmapPoints={heatmapPoints}
        activity={activity}
      />
    </div>
  );
}