'use server';

import { createClient } from '@/lib/supabase/server';
import { revalidatePath } from 'next/cache';
import type { CompletedBuilding } from '@/lib/admin/types';

export type EntranceInput = {
  entrance_number: string | null;
  apt_from?: number | null;     // ← опционально (диапазоны теперь в отдельной таблице)
  apt_to?: number | null;       // ← опционально
  lat: number;
  lng: number;
  mapbox_building_id?: string | null;
  address?: string | null;
  korpus?: string | null;
};

export type AptRange = {
  id: string;
  entrance_id: string;
  apt_from: number;
  apt_to: number;
  order_index: number;
};

export type AptRangeInput = {
  apt_from: number;
  apt_to: number;
  order_index: number;
};

// === Reverse Geocoding via Mapbox ===
async function reverseGeocode(lat: number, lng: number): Promise<string | null> {
  const token = process.env.NEXT_PUBLIC_MAPBOX_TOKEN;
  if (!token) return null;

  try {
    const url = `https://api.mapbox.com/geocoding/v5/mapbox.places/${lng},${lat}.json?access_token=${token}&language=pl&types=address&limit=1`;
    const res = await fetch(url);
    if (!res.ok) return null;
    const data = await res.json();
    const feature = data.features?.[0];
    if (!feature) return null;

    // Mapbox returns: text = "Marszałkowska", address = "81"
    const street = (feature.text ?? '').trim();
    const number = (feature.address ?? '').trim();
    const combined = `${street} ${number}`.trim();
    return combined || feature.place_name || null;
  } catch {
    return null;
  }
}

export async function createEntrance(input: EntranceInput) {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();

  if (!user) return { error: 'Не авторизован' };

  // Автоматически определяем адрес, если не передан
  let address = input.address;
  if (!address) {
    address = await reverseGeocode(input.lat, input.lng);
  }

  const { data, error } = await supabase
    .from('entrances')
    .insert({ ...input, address, created_by: user.id })
    .select()
    .single();

  if (error) return { error: error.message };

  revalidatePath('/admin/entrances');
  return { data };
}

export async function updateEntrance(id: string, input: Partial<EntranceInput>) {
  const supabase = await createClient();

  let finalInput = { ...input };

  // Lazy-миграция: если у существующей записи нет address — догрузим
  if (input.address === undefined) {
    const { data: existing } = await supabase
      .from('entrances')
      .select('address, lat, lng')
      .eq('id', id)
      .single();

    if (existing && !existing.address) {
      const lat = input.lat ?? existing.lat;
      const lng = input.lng ?? existing.lng;
      const newAddress = await reverseGeocode(lat, lng);
      if (newAddress) finalInput.address = newAddress;
    }
  }

  const { data, error } = await supabase
    .from('entrances')
    .update(finalInput)
    .eq('id', id)
    .select()
    .single();

  if (error) return { error: error.message };

  revalidatePath('/admin/entrances');
  return { data };
}

export async function deleteEntrance(id: string) {
  const supabase = await createClient();
  const { error } = await supabase.from('entrances').delete().eq('id', id);

  if (error) return { error: error.message };

  revalidatePath('/admin/entrances');
  return { success: true };
}

export async function getAllEntrances() {
  const supabase = await createClient();
  const [entrancesResult, rangesResult] = await Promise.all([
    supabase
      .from('entrances')
      .select('id, entrance_number, apt_from, apt_to, apt_extras, lat, lng, mapbox_building_id, address, korpus, verified_count, negative_count, is_flagged, created_at')
      .order('created_at', { ascending: false }),
    supabase
      .from('entrance_apt_ranges')
      .select('id, entrance_id, apt_from, apt_to, order_index')
      .order('order_index', { ascending: true }),
  ]);

  const entrances = entrancesResult.data ?? [];
  const ranges = rangesResult.data ?? [];

  // Группируем диапазоны по entrance_id
  const rangesByEntrance = new Map<string, AptRange[]>();
  for (const r of ranges) {
    const list = rangesByEntrance.get(r.entrance_id) ?? [];
    list.push(r);
    rangesByEntrance.set(r.entrance_id, list);
  }

  // Прикладываем диапазоны к каждому подъезду
  return entrances.map((e) => ({
    ...e,
    ranges: rangesByEntrance.get(e.id) ?? [],
  }));
}

export async function getCompletedBuildings(): Promise<CompletedBuilding[]> {
  const supabase = await createClient();
  const { data } = await supabase
    .from('completed_buildings')
    .select('mapbox_building_id, completed_at');
  return data ?? [];
}

export async function markBuildingComplete(buildingId: string) {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return { error: 'Не авторизован' };

  const { error } = await supabase
    .from('completed_buildings')
    .upsert({ mapbox_building_id: buildingId, completed_by: user.id });

  if (error) return { error: error.message };

  revalidatePath('/admin/entrances');
  return { success: true };
}

export async function unmarkBuildingComplete(buildingId: string) {
  const supabase = await createClient();
  const { error } = await supabase
    .from('completed_buildings')
    .delete()
    .eq('mapbox_building_id', buildingId);

  if (error) return { error: error.message };

  revalidatePath('/admin/entrances');
  return { success: true };
}
// =====================================================
// === ENTRANCE APPROACHES (точки подхода к подъезду) ===
// =====================================================

export type ApproachInput = {
  entrance_id: string;
  lat: number;
  lng: number;
  order_index: number; // 1, 2 или 3
};

export type Approach = {
  id: string;
  entrance_id: string;
  mapbox_building_id: string | null;
  lat: number;
  lng: number;
  order_index: number;
  created_at: string;
};

export async function createApproach(input: ApproachInput) {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();

  if (!user) return { error: 'Не авторизован' };

  // Проверяем что для этого подъезда ещё нет точки с таким order_index
  const { data: existing } = await supabase
    .from('entrance_approaches')
    .select('id')
    .eq('entrance_id', input.entrance_id)
    .eq('order_index', input.order_index)
    .maybeSingle();

  if (existing) {
    return { error: `Точка ${input.order_index} уже существует. Удалите её перед добавлением новой.` };
  }

  // mapbox_building_id заполнит триггер автоматически
  const { data, error } = await supabase
    .from('entrance_approaches')
    .insert({ ...input, created_by: user.id })
    .select()
    .single();

  if (error) return { error: error.message };

  revalidatePath('/admin/entrances');
  return { data };
}

export async function updateApproach(
  id: string,
  patch: Partial<Pick<Approach, 'lat' | 'lng' | 'order_index'>>
) {
  const supabase = await createClient();

  const { data, error } = await supabase
    .from('entrance_approaches')
    .update(patch)
    .eq('id', id)
    .select()
    .single();

  if (error) return { error: error.message };

  revalidatePath('/admin/entrances');
  return { data };
}

export async function deleteApproach(id: string) {
  const supabase = await createClient();
  const { error } = await supabase
    .from('entrance_approaches')
    .delete()
    .eq('id', id);

  if (error) return { error: error.message };

  revalidatePath('/admin/entrances');
  return { success: true };
}

export async function getApproachesForEntrance(entranceId: string): Promise<Approach[]> {
  const supabase = await createClient();
  const { data } = await supabase
    .from('entrance_approaches')
    .select('id, entrance_id, mapbox_building_id, lat, lng, order_index, created_at')
    .eq('entrance_id', entranceId)
    .order('order_index', { ascending: true });

  return data ?? [];
}

export async function getAllApproaches(): Promise<Approach[]> {
  const supabase = await createClient();
  const { data } = await supabase
    .from('entrance_approaches')
    .select('id, entrance_id, mapbox_building_id, lat, lng, order_index, created_at')
    .order('order_index', { ascending: true });

  return data ?? [];
}

// =====================================================
// === APT RANGES (диапазоны квартир) ===
// =====================================================

export async function getAptRangesForEntrance(entranceId: string): Promise<AptRange[]> {
  const supabase = await createClient();
  const { data } = await supabase
    .from('entrance_apt_ranges')
    .select('id, entrance_id, apt_from, apt_to, order_index')
    .eq('entrance_id', entranceId)
    .order('order_index', { ascending: true });
  return data ?? [];
}

export async function getAllAptRanges(): Promise<AptRange[]> {
  const supabase = await createClient();
  const { data } = await supabase
    .from('entrance_apt_ranges')
    .select('id, entrance_id, apt_from, apt_to, order_index')
    .order('order_index', { ascending: true });
  return data ?? [];
}

/**
 * Перезаписывает все диапазоны квартир для подъезда.
 * Удаляет старые → вставляет новые. Атомарно через транзакцию.
 */
export async function setAptRanges(entranceId: string, ranges: AptRangeInput[]) {
  const supabase = await createClient();

  // 1) Удаляем старые
  const { error: deleteError } = await supabase
    .from('entrance_apt_ranges')
    .delete()
    .eq('entrance_id', entranceId);

  if (deleteError) return { error: deleteError.message };

  // 2) Вставляем новые (если есть)
  const validRanges = ranges
    .filter((r) => r.apt_from > 0 && r.apt_to >= r.apt_from)
    .map((r) => ({ ...r, entrance_id: entranceId }));

  if (validRanges.length > 0) {
    const { error: insertError } = await supabase
      .from('entrance_apt_ranges')
      .insert(validRanges);

    if (insertError) return { error: insertError.message };
  }

  // 3) Также обновляем legacy поля apt_from/apt_to в entrances —
  //    берём минимум apt_from и максимум apt_to для поиска как fallback
  if (validRanges.length > 0) {
    const minFrom = Math.min(...validRanges.map((r) => r.apt_from));
    const maxTo = Math.max(...validRanges.map((r) => r.apt_to));
    await supabase
      .from('entrances')
      .update({ apt_from: minFrom, apt_to: maxTo })
      .eq('id', entranceId);
  } else {
    await supabase
      .from('entrances')
      .update({ apt_from: null, apt_to: null })
      .eq('id', entranceId);
  }

  revalidatePath('/admin/entrances');
  return { success: true };
}
export type VerificationStat = {
  entrance_id: string;
  correct_count: number;
  incorrect_count: number;
};

export async function listVerificationStats(): Promise<VerificationStat[]> {
  const supabase = await createClient();
  const { data, error } = await supabase
    .from('entrance_verification_stats')
    .select('entrance_id, correct_count, incorrect_count');

  if (error) {
    console.warn('listVerificationStats:', error.message);
    return [];
  }
  return (data ?? []) as VerificationStat[];
}