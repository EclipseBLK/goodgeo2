'use server';

import { createClient } from '@/lib/supabase/server';
import { revalidatePath } from 'next/cache';

// =====================================================
// === ТИПЫ ===
// =====================================================

export type SuggestionStatus = 'pending' | 'approved' | 'rejected' | 'expired';

export type SuggestionRangeInput = {
  apt_from: number;
  apt_to: number;
  order_index: number;
};

export type SuggestionInput = {
  entrance_number: string | null;
  apt_from?: number | null;
  apt_to?: number | null;
  apt_extras?: string[];
  korpus?: string | null;
  lat: number;
  lng: number;
  mapbox_building_id?: string | null;
  address?: string | null;
  ranges?: SuggestionRangeInput[]; // диапазоны квартир
};

export type SuggestionRange = {
  id: string;
  suggestion_id: string;
  apt_from: number;
  apt_to: number;
  order_index: number;
};

export type Suggestion = {
  id: string;
  entrance_number: string | null;
  apt_from: number | null;
  apt_to: number | null;
  apt_extras: string[];
  korpus: string | null;
  lat: number;
  lng: number;
  mapbox_building_id: string | null;
  address: string | null;
  suggested_by: string | null;
  status: SuggestionStatus;
  rejection_reason: string | null;
  reviewed_by: string | null;
  reviewed_at: string | null;
  created_at: string;
  expires_at: string;
  approved_entrance_id: string | null;
  ranges?: SuggestionRange[];
  // Доп.поля из джойна с profiles (для админки)
  suggester?: {
    client_number: string | null;
    name: string | null;
    email: string;
  } | null;
};

export type LeaderboardEntry = {
  user_id: string;
  client_number: string | null;
  name: string | null;
  approved_count: number;
  total_count: number;
  rank: number;
};

export type VerificationVote = 'correct' | 'wrong_coords' | 'wrong_apt_range' | 'not_exists';

// =====================================================
// === SUGGESTIONS — мобилка отправляет ===
// =====================================================

/**
 * Курьер создаёт предложение нового подъезда.
 * Проверяет:
 *  1) что юзер — creator или admin
 *  2) что в радиусе 50м нет существующего подъезда
 *  3) что в радиусе 50м нет другого pending-suggestion младше 24ч
 */
export async function submitSuggestion(input: SuggestionInput) {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();

  if (!user) return { error: 'Не авторизован' };

  // Проверка роли
  const { data: profile } = await supabase
    .from('profiles')
    .select('role')
    .eq('id', user.id)
    .single();

  if (!profile || (profile.role !== 'creator' && profile.role !== 'admin')) {
    return { error: 'Только creator может предлагать подъезды' };
  }

  // Проверка дублей в радиусе 50м (грубо, по box-фильтру для скорости)
  const radiusDeg = 0.0005; // ~50м

  const { data: nearbyEntrances } = await supabase
    .from('entrances')
    .select('id, lat, lng')
    .gte('lat', input.lat - radiusDeg)
    .lte('lat', input.lat + radiusDeg)
    .gte('lng', input.lng - radiusDeg)
    .lte('lng', input.lng + radiusDeg);

  if (nearbyEntrances && nearbyEntrances.length > 0) {
    const tooClose = nearbyEntrances.some((e) => {
      const dist = haversineMeters(input.lat, input.lng, e.lat, e.lng);
      return dist <= 20;
    });
    if (tooClose) {
      return { error: 'Подъезд уже есть в этой точке (ближе 20м)' };
    }
  }

  const { data: nearbyPending } = await supabase
    .from('entrance_suggestions')
    .select('id, lat, lng, expires_at')
    .eq('status', 'pending')
    .gte('lat', input.lat - radiusDeg)
    .lte('lat', input.lat + radiusDeg)
    .gte('lng', input.lng - radiusDeg)
    .lte('lng', input.lng + radiusDeg);

  if (nearbyPending && nearbyPending.length > 0) {
    const now = Date.now();
    const blocking = nearbyPending.find((s) => {
      const expiresAt = new Date(s.expires_at).getTime();
      if (expiresAt < now) return false; // истёкший — не блокирует
      const dist = haversineMeters(input.lat, input.lng, s.lat, s.lng);
      return dist <= 30;
    });
    if (blocking) {
      return { error: 'Уже есть предложение для этого места (на проверке)' };
    }
  }

  // Reverse geocoding если address не передан
  let address = input.address ?? null;
  if (!address) {
    address = await reverseGeocode(input.lat, input.lng);
  }

  // Создаём suggestion
  const { data: suggestion, error: insertError } = await supabase
    .from('entrance_suggestions')
    .insert({
      entrance_number: input.entrance_number,
      apt_from: input.apt_from ?? null,
      apt_to: input.apt_to ?? null,
      apt_extras: input.apt_extras ?? [],
      korpus: input.korpus ?? null,
      lat: input.lat,
      lng: input.lng,
      mapbox_building_id: input.mapbox_building_id ?? null,
      address,
      suggested_by: user.id,
    })
    .select()
    .single();

  if (insertError) return { error: insertError.message };

  // Вставляем диапазоны если есть
  if (input.ranges && input.ranges.length > 0) {
    const ranges = input.ranges.map((r) => ({
      suggestion_id: suggestion.id,
      apt_from: r.apt_from,
      apt_to: r.apt_to,
      order_index: r.order_index,
    }));

    const { error: rangesError } = await supabase
      .from('entrance_suggestion_apt_ranges')
      .insert(ranges);

    if (rangesError) {
      // Откатываем suggestion если диапазоны не вставились
      await supabase.from('entrance_suggestions').delete().eq('id', suggestion.id);
      return { error: 'Ошибка сохранения диапазонов: ' + rangesError.message };
    }
  }

  // Инкрементим счётчик total
  await supabase.rpc('increment_suggestions_total', { p_user_id: user.id }).then(
    () => {},
    async () => {
      // Если RPC нет — апдейтим напрямую
      const { data: p } = await supabase
        .from('profiles')
        .select('suggestions_total_count')
        .eq('id', user.id)
        .single();
      if (p) {
        await supabase
          .from('profiles')
          .update({ suggestions_total_count: (p.suggestions_total_count ?? 0) + 1 })
          .eq('id', user.id);
      }
    }
  );

  revalidatePath('/admin/suggestions');
  return { data: suggestion };
}

// =====================================================
// === SUGGESTIONS — админка просматривает ===
// =====================================================

export async function listSuggestions(filter?: {
  status?: SuggestionStatus | 'all';
}): Promise<Suggestion[]> {
  const supabase = await createClient();

  let query = supabase
    .from('entrance_suggestions')
    .select(`
      id, entrance_number, apt_from, apt_to, apt_extras, korpus,
      lat, lng, mapbox_building_id, address,
      suggested_by, status, rejection_reason, reviewed_by, reviewed_at,
      created_at, expires_at, approved_entrance_id
    `)
    .order('created_at', { ascending: false });

  if (filter?.status && filter.status !== 'all') {
    query = query.eq('status', filter.status);
  } else if (!filter?.status) {
    // По умолчанию — только pending
    query = query.eq('status', 'pending');
  }

  const { data: suggestions, error } = await query;
  if (error || !suggestions) return [];

  // Подгружаем профили курьеров
  const userIds = Array.from(
    new Set(suggestions.map((s) => s.suggested_by).filter(Boolean) as string[])
  );

  const profilesMap = new Map<string, { client_number: string | null; name: string | null; email: string }>();
  if (userIds.length > 0) {
    const { data: profiles } = await supabase
      .from('profiles')
      .select('id, client_number, name, email')
      .in('id', userIds);

    for (const p of profiles ?? []) {
      profilesMap.set(p.id, {
        client_number: p.client_number,
        name: p.name,
        email: p.email,
      });
    }
  }

  // Подгружаем диапазоны
  const suggestionIds = suggestions.map((s) => s.id);
  const rangesMap = new Map<string, SuggestionRange[]>();
  if (suggestionIds.length > 0) {
    const { data: ranges } = await supabase
      .from('entrance_suggestion_apt_ranges')
      .select('id, suggestion_id, apt_from, apt_to, order_index')
      .in('suggestion_id', suggestionIds)
      .order('order_index', { ascending: true });

    for (const r of ranges ?? []) {
      const list = rangesMap.get(r.suggestion_id) ?? [];
      list.push(r);
      rangesMap.set(r.suggestion_id, list);
    }
  }

  return suggestions.map((s) => ({
    ...s,
    ranges: rangesMap.get(s.id) ?? [],
    suggester: s.suggested_by ? profilesMap.get(s.suggested_by) ?? null : null,
  }));
}

export async function getPendingSuggestionsCount(): Promise<number> {
  const supabase = await createClient();
  const { count } = await supabase
    .from('entrance_suggestions')
    .select('*', { count: 'exact', head: true })
    .eq('status', 'pending');
  return count ?? 0;
}

// =====================================================
// === SUGGESTIONS — админ принимает/отклоняет ===
// =====================================================

export async function approveSuggestion(suggestionId: string) {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();

  if (!user) return { error: 'Не авторизован' };

  // Проверка роли admin
  const { data: profile } = await supabase
    .from('profiles')
    .select('role')
    .eq('id', user.id)
    .single();

  if (profile?.role !== 'admin') {
    return { error: 'Только admin может одобрять предложения' };
  }

  // Вызываем SQL-функцию (атомарно копирует suggestion → entrances + диапазоны + бонус)
  const { data, error } = await supabase.rpc('approve_entrance_suggestion', {
    p_suggestion_id: suggestionId,
    p_admin_id: user.id,
  });

  if (error) return { error: error.message };

  revalidatePath('/admin/suggestions');
  revalidatePath('/admin/entrances');
  revalidatePath('/admin');
  return { data: { entrance_id: data } };
}

export async function rejectSuggestion(suggestionId: string, reason?: string) {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();

  if (!user) return { error: 'Не авторизован' };

  const { data: profile } = await supabase
    .from('profiles')
    .select('role')
    .eq('id', user.id)
    .single();

  if (profile?.role !== 'admin') {
    return { error: 'Только admin может отклонять предложения' };
  }

  const { error } = await supabase.rpc('reject_entrance_suggestion', {
    p_suggestion_id: suggestionId,
    p_admin_id: user.id,
    p_reason: reason ?? null,
  });

  if (error) return { error: error.message };

  revalidatePath('/admin/suggestions');
  revalidatePath('/admin');
  return { success: true };
}

// =====================================================
// === ROLE MANAGEMENT ===
// =====================================================

/**
 * Курьер из мобилки подаёт заявку на роль creator.
 * Только устанавливает is_creator_applied = true. Админ потом меняет роль вручную.
 */
export async function applyForCreator() {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();

  if (!user) return { error: 'Не авторизован' };

  const { data: profile } = await supabase
    .from('profiles')
    .select('role, is_creator_applied')
    .eq('id', user.id)
    .single();

  if (!profile) return { error: 'Профиль не найден' };

  if (profile.role === 'creator' || profile.role === 'admin') {
    return { error: 'У вас уже есть права creator' };
  }

  if (profile.is_creator_applied) {
    return { error: 'Вы уже подали заявку, ожидайте решения' };
  }

  const { error } = await supabase
    .from('profiles')
    .update({
      is_creator_applied: true,
      creator_applied_at: new Date().toISOString(),
    })
    .eq('id', user.id);

  if (error) return { error: error.message };

  return { success: true };
}

/**
 * Админ меняет роль юзера. Только admin.
 */
export async function setUserRole(userId: string, role: 'user' | 'creator' | 'admin') {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();

  if (!user) return { error: 'Не авторизован' };

  const { data: callerProfile } = await supabase
    .from('profiles')
    .select('role')
    .eq('id', user.id)
    .single();

  if (callerProfile?.role !== 'admin') {
    return { error: 'Только admin может менять роли' };
  }

  // Если выдаём creator — также сбрасываем флаг заявки
  const updates: { role: string; is_creator_applied?: boolean } = { role };
  if (role === 'creator') {
    updates.is_creator_applied = false;
  }

  const { error } = await supabase
    .from('profiles')
    .update(updates)
    .eq('id', userId);

  if (error) return { error: error.message };

  revalidatePath('/admin/users');
  return { success: true };
}

// =====================================================
// === STATS & LEADERBOARD ===
// =====================================================

export type CreatorStats = {
  client_number: string | null;
  role: string;
  is_creator_applied: boolean;
  total_count: number;
  approved_count: number;
  bonus_days_earned: number;
  next_bonus_in: number; // сколько ещё подъездов до следующего бонусного дня
};

export async function getCreatorStats(): Promise<CreatorStats | null> {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return null;

  const { data } = await supabase
    .from('profiles')
    .select('client_number, role, is_creator_applied, suggestions_total_count, suggestions_approved_count, bonus_days_earned')
    .eq('id', user.id)
    .single();

  if (!data) return null;

  const approved = data.suggestions_approved_count ?? 0;
  const nextBonusIn = 10 - (approved % 10);

  return {
    client_number: data.client_number,
    role: data.role,
    is_creator_applied: data.is_creator_applied ?? false,
    total_count: data.suggestions_total_count ?? 0,
    approved_count: approved,
    bonus_days_earned: data.bonus_days_earned ?? 0,
    next_bonus_in: nextBonusIn,
  };
}

export async function getLeaderboard(limit: number = 50): Promise<LeaderboardEntry[]> {
  const supabase = await createClient();

  const { data } = await supabase
    .from('profiles')
    .select('id, client_number, name, suggestions_approved_count, suggestions_total_count')
    .in('role', ['creator', 'admin'])
    .gt('suggestions_approved_count', 0)
    .order('suggestions_approved_count', { ascending: false })
    .limit(limit);

  if (!data) return [];

  return data.map((p, idx) => ({
    user_id: p.id,
    client_number: p.client_number,
    name: p.name,
    approved_count: p.suggestions_approved_count ?? 0,
    total_count: p.suggestions_total_count ?? 0,
    rank: idx + 1,
  }));
}

// =====================================================
// === VERIFICATIONS ===
// =====================================================

/**
 * Курьер голосует за качество подъезда после прибытия.
 */
export async function submitVerification(entranceId: string, vote: VerificationVote) {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();

  if (!user) return { error: 'Не авторизован' };

  // upsert чтобы избежать дублей (UNIQUE constraint на entrance_id+user_id)
  const { error } = await supabase
    .from('entrance_verifications')
    .insert({
      entrance_id: entranceId,
      user_id: user.id,
      vote,
    });

  if (error) {
    // Если уже голосовал — игнорируем (не считаем ошибкой)
    if (error.code === '23505') {
      return { success: true, alreadyVoted: true };
    }
    return { error: error.message };
  }

  return { success: true };
}

/**
 * Проверить голосовал ли уже юзер за этот подъезд.
 * Используется чтобы не показывать диалог повторно.
 */
export async function hasUserVerified(entranceId: string): Promise<boolean> {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return false;

  const { data } = await supabase
    .from('entrance_verifications')
    .select('id')
    .eq('entrance_id', entranceId)
    .eq('user_id', user.id)
    .maybeSingle();

  return !!data;
}

/**
 * Админка: список зафлаганных подъездов (5+ negative).
 */
export async function getFlaggedEntrances() {
  const supabase = await createClient();

  const { data } = await supabase
    .from('entrances')
    .select('id, entrance_number, address, korpus, lat, lng, verified_count, negative_count, created_by, created_at')
    .eq('is_flagged', true)
    .order('negative_count', { ascending: false });

  return data ?? [];
}

/**
 * Админ снимает флаг (после проверки).
 */
export async function unflagEntrance(entranceId: string) {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();

  if (!user) return { error: 'Не авторизован' };

  const { data: profile } = await supabase
    .from('profiles')
    .select('role')
    .eq('id', user.id)
    .single();

  if (profile?.role !== 'admin') {
    return { error: 'Только admin' };
  }

  const { error } = await supabase
    .from('entrances')
    .update({ is_flagged: false, negative_count: 0 })
    .eq('id', entranceId);

  if (error) return { error: error.message };

  revalidatePath('/admin');
  return { success: true };
}

// =====================================================
// === ВСПОМОГАТЕЛЬНЫЕ ===
// =====================================================

async function reverseGeocode(lat: number, lng: number): Promise<string | null> {
  const token = process.env.NEXT_PUBLIC_MAPBOX_TOKEN;
  if (!token) return null;
  try {
    const url = `https://api.mapbox.com/geocoding/v5/mapbox.places/${lng},${lat}.json?access_token=${token}&language=pl&types=address&limit=1`;
    const res = await fetch(url);
    if (!res.ok) return null;
    const data = await res.json();
    const feature = data.features?.[0];
    if (!feature) return null;
    const street = (feature.text ?? '').trim();
    const number = (feature.address ?? '').trim();
    const combined = `${street} ${number}`.trim();
    return combined || feature.place_name || null;
  } catch {
    return null;
  }
}

function haversineMeters(lat1: number, lng1: number, lat2: number, lng2: number): number {
  const R = 6371000;
  const toRad = (deg: number) => (deg * Math.PI) / 180;
  const dLat = toRad(lat2 - lat1);
  const dLng = toRad(lng2 - lng1);
  const a = toRad(lat1);
  const b = toRad(lat2);
  const x =
    Math.sin(dLat / 2) ** 2 + Math.sin(dLng / 2) ** 2 * Math.cos(a) * Math.cos(b);
  return 2 * R * Math.asin(Math.sqrt(x));
}