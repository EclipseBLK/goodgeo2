import EntrancesMap from '@/components/admin/EntrancesMap';
import { getAllEntrances, getCompletedBuildings, getAllApproaches } from './actions';

export const dynamic = 'force-dynamic';

export default async function EntrancesPage() {
  const [entrances, completedBuildings, approaches] = await Promise.all([
    getAllEntrances(),
    getCompletedBuildings(),
    getAllApproaches(),
  ]);

  return (
    <div>
      <h1 className="text-2xl font-bold text-slate-800 mb-2">Подъезды</h1>
      <p className="text-slate-500 mb-6">Карта Варшавы и управление подъездами</p>
      <EntrancesMap
        initialEntrances={entrances}
        initialCompletedBuildings={completedBuildings}
        initialApproaches={approaches}
      />
    </div>
  );
}