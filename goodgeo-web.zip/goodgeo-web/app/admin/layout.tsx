import { ReactNode } from 'react';
import Sidebar from '@/components/admin/Sidebar';
import Topbar from '@/components/admin/Topbar';
import '../globals.css';

export const metadata = {
  title: 'GoodGeo Admin',
};

export default function AdminLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="ru">
      <body className="bg-slate-50 text-slate-800 min-h-screen">
        <Sidebar />
        <div className="md:ml-60 flex flex-col min-h-screen">
          <div className="hidden md:block">
            <Topbar />
          </div>
          <main className="flex-1 md:p-6">{children}</main>
        </div>
      </body>
    </html>
  );
}