'use client';

import { useState, Suspense } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import { createClient } from '@/lib/supabase/client';
import Image from 'next/image';

function LoginForm() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  // Сообщение если выкинуло из-за role
  const urlError = searchParams.get('error');
  const errorMessage = urlError === 'not_admin' 
    ? 'У этого аккаунта нет прав администратора' 
    : '';

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    const supabase = createClient();
    const { data, error: authError } = await supabase.auth.signInWithPassword({
      email,
      password,
    });

    if (authError) {
      setError(authError.message);
      setLoading(false);
      return;
    }

    // Проверяем role
    if (data.user) {
      const { data: profile } = await supabase
        .from('profiles')
        .select('role')
        .eq('id', data.user.id)
        .single();

      if (profile?.role !== 'admin') {
        await supabase.auth.signOut();
        setError('У этого аккаунта нет прав администратора');
        setLoading(false);
        return;
      }

      router.push('/admin');
      router.refresh();
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-6">
      <div className="w-full max-w-sm">
        <div className="text-center mb-8">
          <Image src="/logo.png" alt="GoodGeo" width={64} height={64} className="mx-auto mb-3" />
          <h1 className="text-2xl font-bold">GoodGeo Admin</h1>
          <p className="text-sm text-slate-400 mt-2">Вход для администраторов</p>
        </div>

        <form onSubmit={handleLogin} className="space-y-3">
          <input
            type="email"
            placeholder="Email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
            disabled={loading}
            className="w-full px-4 py-3 bg-brand-surface border border-brand-border rounded-xl text-white placeholder:text-slate-400 focus:outline-none focus:border-brand-accent transition"
          />
          <input
            type="password"
            placeholder="Пароль"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
            disabled={loading}
            className="w-full px-4 py-3 bg-brand-surface border border-brand-border rounded-xl text-white placeholder:text-slate-400 focus:outline-none focus:border-brand-accent transition"
          />

          {(error || errorMessage) && (
            <div className="p-3 bg-red-900/30 border border-red-700 rounded-xl text-sm text-red-300">
              {error || errorMessage}
            </div>
          )}

          <button
            type="submit"
            disabled={loading}
            className="w-full px-4 py-3 bg-brand-accent hover:bg-brand-accent/90 disabled:opacity-50 text-white font-semibold rounded-xl transition"
          >
            {loading ? 'Вход...' : 'Войти'}
          </button>
        </form>
      </div>
    </div>
  );
}

export default function AdminLoginPage() {
  return (
    <Suspense>
      <LoginForm />
    </Suspense>
  );
}