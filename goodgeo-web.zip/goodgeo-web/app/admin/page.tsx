import { Users, CreditCard, Clock, Wifi, MapPin, Inbox } from 'lucide-react';
import Link from 'next/link';
import StatCard from '@/components/admin/StatCard';
import { getDashboardStats, getRecentUsers, getRecentEntrances } from '@/lib/admin/stats';
import { getPendingSuggestionsCount } from '@/app/admin/entrances/creator-actions';

export const dynamic = 'force-dynamic';

export default async function AdminHomePage() {
  const [stats, recentUsers, recentEntrances, pendingSuggestions] = await Promise.all([
    getDashboardStats(),
    getRecentUsers(),
    getRecentEntrances(),
    getPendingSuggestionsCount(),
  ]);

  return (
    <div>
      <h1 className="text-2xl font-bold text-slate-800 mb-2">Дашборд</h1>
      <p className="text-slate-500 mb-8">Обзор основных показателей GoodGeo</p>

      {/* KPI cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-6 gap-4 mb-8">
        <StatCard
          icon={Users}
          label="Всего пользователей"
          value={stats.totalUsers}
          iconColor="text-blue-600"
          iconBg="bg-blue-50"
        />
        <StatCard
          icon={CreditCard}
          label="Активных подписок"
          value={stats.activeSubscriptions}
          iconColor="text-teal-600"
          iconBg="bg-teal-50"
        />
        <StatCard
          icon={Clock}
          label="На триале"
          value={stats.onTrial}
          iconColor="text-amber-600"
          iconBg="bg-amber-50"
        />
        <StatCard
          icon={Wifi}
          label="Онлайн сейчас"
          value={stats.onlineNow}
          iconColor="text-green-600"
          iconBg="bg-green-50"
        />
        <StatCard
          icon={MapPin}
          label="Домов в базе"
          value={stats.totalHouses}
          iconColor="text-purple-600"
          iconBg="bg-purple-50"
        />
        <Link href="/admin/suggestions" className="block">
          <StatCard
            icon={Inbox}
            label="Новых предложений"
            value={pendingSuggestions}
            iconColor={pendingSuggestions > 0 ? 'text-rose-600' : 'text-slate-400'}
            iconBg={pendingSuggestions > 0 ? 'bg-rose-50' : 'bg-slate-50'}
          />
        </Link>
      </div>

      {/* Tables */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Последние регистрации */}
        <div className="bg-white border border-slate-200 rounded-2xl overflow-hidden">
          <div className="px-5 py-4 border-b border-slate-200">
            <h2 className="font-semibold text-slate-800">Последние регистрации</h2>
          </div>
          {recentUsers.length === 0 ? (
            <div className="p-8 text-center text-slate-400 text-sm">Пока никого нет</div>
          ) : (
            <table className="w-full text-sm">
              <thead className="bg-slate-50 text-slate-500 text-xs uppercase">
                <tr>
                  <th className="text-left px-5 py-3 font-medium">Пользователь</th>
                  <th className="text-left px-5 py-3 font-medium">Статус</th>
                  <th className="text-right px-5 py-3 font-medium">Дата</th>
                </tr>
              </thead>
              <tbody>
                {recentUsers.map((user) => (
                  <tr key={user.id} className="border-t border-slate-100">
                    <td className="px-5 py-3">
                      <div className="font-medium text-slate-800">{user.name ?? '—'}</div>
                      <div className="text-xs text-slate-400">{user.email}</div>
                    </td>
                    <td className="px-5 py-3">
                      <StatusBadge status={user.subscription_status} />
                    </td>
                    <td className="px-5 py-3 text-right text-slate-500 text-xs">
                      {formatDate(user.created_at)}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>

        {/* Последние подъезды */}
        <div className="bg-white border border-slate-200 rounded-2xl overflow-hidden">
          <div className="px-5 py-4 border-b border-slate-200">
            <h2 className="font-semibold text-slate-800">Последние подъезды</h2>
          </div>
          {recentEntrances.length === 0 ? (
            <div className="p-8 text-center text-slate-400 text-sm">Пока пусто</div>
          ) : (
            <table className="w-full text-sm">
              <thead className="bg-slate-50 text-slate-500 text-xs uppercase">
                <tr>
                  <th className="text-left px-5 py-3 font-medium">Подъезд</th>
                  <th className="text-left px-5 py-3 font-medium">Квартиры</th>
                  <th className="text-right px-5 py-3 font-medium">Дата</th>
                </tr>
              </thead>
              <tbody>
                {recentEntrances.map((entrance) => (
                  <tr key={entrance.id} className="border-t border-slate-100">
                    <td className="px-5 py-3">
                      <div className="font-medium text-slate-800">
                        №{entrance.entrance_number ?? '—'}
                      </div>
                      <div className="text-xs text-slate-400">
                        {entrance.creator_email ?? '—'}
                      </div>
                    </td>
                    <td className="px-5 py-3 text-slate-600">
                      {entrance.apt_from && entrance.apt_to
                        ? `${entrance.apt_from}–${entrance.apt_to}`
                        : '—'}
                    </td>
                    <td className="px-5 py-3 text-right text-slate-500 text-xs">
                      {formatDate(entrance.created_at)}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </div>
    </div>
  );
}

function StatusBadge({ status }: { status: string }) {
  const styles: Record<string, string> = {
    trial: 'bg-amber-50 text-amber-700',
    active: 'bg-teal-50 text-teal-700',
    expired: 'bg-red-50 text-red-700',
    cancelled: 'bg-slate-100 text-slate-600',
  };
  const labels: Record<string, string> = {
    trial: 'Триал',
    active: 'Активна',
    expired: 'Истекла',
    cancelled: 'Отменена',
  };
  return (
    <span
      className={`inline-block px-2 py-1 rounded-md text-xs font-medium ${
        styles[status] ?? 'bg-slate-100 text-slate-600'
      }`}
    >
      {labels[status] ?? status}
    </span>
  );
}

function formatDate(iso: string): string {
  const d = new Date(iso);
  const now = new Date();
  const diffMs = now.getTime() - d.getTime();
  const diffMin = Math.floor(diffMs / 60000);
  const diffH = Math.floor(diffMs / 3600000);
  const diffD = Math.floor(diffMs / 86400000);

  if (diffMin < 1) return 'только что';
  if (diffMin < 60) return `${diffMin} мин назад`;
  if (diffH < 24) return `${diffH} ч назад`;
  if (diffD < 7) return `${diffD} д назад`;

  return d.toLocaleDateString('ru-RU', { day: '2-digit', month: 'short' });
}