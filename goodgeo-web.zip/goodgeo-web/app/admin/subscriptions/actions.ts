'use server';

import { createClient } from '@/lib/supabase/server';
import type { User } from '@/lib/admin/types';

const FIELDS = 'id, email, name, avatar_url, subscription_status, subscription_source, subscription_ends_at, trial_ends_at, platform_transaction_id, is_blocked, role, last_seen_at, created_at';

export async function getAllSubscriptions(): Promise<User[]> {
  const supabase = await createClient();
  const { data } = await supabase
    .from('profiles')
    .select(FIELDS)
    .neq('subscription_source', 'trial')
    .order('subscription_ends_at', { ascending: false, nullsFirst: false });

  return (data ?? []) as User[];
}