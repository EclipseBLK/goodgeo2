import { getAllSubscriptions } from './actions';
import SubscriptionsClient from '@/components/admin/subscriptions/SubscriptionsClient';

export const dynamic = 'force-dynamic';

export default async function SubscriptionsPage() {
  const subscriptions = await getAllSubscriptions();

  return (
    <div>
      <h1 className="text-2xl font-bold text-slate-800 mb-2">Подписки</h1>
      <p className="text-slate-500 mb-8">Платные и ручные подписки пользователей</p>
      <SubscriptionsClient initialSubscriptions={subscriptions} />
    </div>
  );
}