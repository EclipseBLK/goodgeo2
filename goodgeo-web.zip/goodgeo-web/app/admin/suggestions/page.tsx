import { listSuggestions } from '@/app/admin/entrances/creator-actions';
import SuggestionsClient from '@/components/admin/suggestions/SuggestionsClient';

export const dynamic = 'force-dynamic';

export default async function SuggestionsPage() {
  // По умолчанию показываем pending
  const suggestions = await listSuggestions({ status: 'pending' });

  return (
    <div>
      <h1 className="text-2xl font-bold text-slate-800 mb-2">Предложения курьеров</h1>
      <p className="text-slate-500 mb-8">
        Модерация подъездов, добавленных пользователями с ролью creator
      </p>
      <SuggestionsClient initialSuggestions={suggestions} />
    </div>
  );
}