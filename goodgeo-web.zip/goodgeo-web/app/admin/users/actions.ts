'use server';

import { createClient } from '@/lib/supabase/server';
import { revalidatePath } from 'next/cache';
import type { User } from '@/lib/admin/types';

const USER_FIELDS = `
  id, email, name, avatar_url, subscription_status, subscription_source,
  subscription_ends_at, trial_ends_at, platform_transaction_id, is_blocked,
  role, last_seen_at, created_at,
  client_number, suggestions_total_count, suggestions_approved_count,
  bonus_days_earned, is_creator_applied, creator_applied_at
`;

export async function getUsersList(): Promise<User[]> {
  const supabase = await createClient();
  const { data } = await supabase
    .from('profiles')
    .select(USER_FIELDS)
    .order('created_at', { ascending: false });
  return (data ?? []) as User[];
}

export async function extendTrial(userId: string, days: number = 7) {
  const supabase = await createClient();

  const { data: existing } = await supabase
    .from('profiles')
    .select('trial_ends_at')
    .eq('id', userId)
    .single();

  // Если триал ещё не истёк — продляем от него; иначе от текущего момента
  const baseDate =
    existing?.trial_ends_at && new Date(existing.trial_ends_at) > new Date()
      ? new Date(existing.trial_ends_at)
      : new Date();

  const newDate = new Date(baseDate.getTime() + days * 24 * 60 * 60 * 1000);

  const { error } = await supabase
    .from('profiles')
    .update({
      trial_ends_at: newDate.toISOString(),
      subscription_status: 'trial',
      subscription_source: 'trial',
    })
    .eq('id', userId);

  if (error) return { error: error.message };

  revalidatePath('/admin/users');
  return { success: true };
}

export async function activateSubscriptionManually(userId: string, months: number = 1) {
  const supabase = await createClient();

  const { data: existing } = await supabase
    .from('profiles')
    .select('subscription_ends_at')
    .eq('id', userId)
    .single();

  const baseDate =
    existing?.subscription_ends_at && new Date(existing.subscription_ends_at) > new Date()
      ? new Date(existing.subscription_ends_at)
      : new Date();

  const newDate = new Date(baseDate);
  newDate.setMonth(newDate.getMonth() + months);

  const { error } = await supabase
    .from('profiles')
    .update({
      subscription_status: 'active',
      subscription_source: 'manual',
      subscription_ends_at: newDate.toISOString(),
    })
    .eq('id', userId);

  if (error) return { error: error.message };

  revalidatePath('/admin/users');
  return { success: true };
}

export async function toggleBlockUser(userId: string, isBlocked: boolean) {
  const supabase = await createClient();
  const { error } = await supabase
    .from('profiles')
    .update({ is_blocked: isBlocked })
    .eq('id', userId);

  if (error) return { error: error.message };

  revalidatePath('/admin/users');
  return { success: true };
}

export async function getUserDetails(userId: string) {
  const supabase = await createClient();

  const { data: user } = await supabase
    .from('profiles')
    .select(USER_FIELDS)
    .eq('id', userId)
    .single();

  if (!user) return null;

  const { data: history } = await supabase
    .from('history')
    .select('id, address, visited_at')
    .eq('user_id', userId)
    .order('visited_at', { ascending: false })
    .limit(10);

  return {
    user: user as User,
    history: history ?? [],
  };
}

/**
 * Изменение роли юзера админом.
 * Защита: нельзя снять роль admin с самого себя (чтобы не заблокироваться).
 */
export async function changeUserRole(
  userId: string,
  newRole: 'user' | 'creator' | 'admin'
) {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) return { error: 'Не авторизован' };

  // Проверка что вызывающий — admin
  const { data: caller } = await supabase
    .from('profiles')
    .select('role')
    .eq('id', user.id)
    .single();

  if (caller?.role !== 'admin') {
    return { error: 'Только admin может менять роли' };
  }

  // Защита от самоблокировки
  if (userId === user.id && newRole !== 'admin') {
    return { error: 'Нельзя снять роль admin с самого себя' };
  }

  // Если выдаём creator — также сбрасываем флаг заявки
  const updates: { role: string; is_creator_applied?: boolean } = { role: newRole };
  if (newRole === 'creator') {
    updates.is_creator_applied = false;
  }

  const { error } = await supabase
    .from('profiles')
    .update(updates)
    .eq('id', userId);

  if (error) return { error: error.message };

  revalidatePath('/admin/users');
  return { success: true };
}