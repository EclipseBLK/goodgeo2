import { getUsersList } from './actions';
import UsersClient from '@/components/admin/users/UsersClient';

export const dynamic = 'force-dynamic';

export default async function UsersPage() {
  const users = await getUsersList();

  return (
    <div>
      <h1 className="text-2xl font-bold text-slate-800 mb-2">Пользователи</h1>
      <p className="text-slate-500 mb-8">Управление аккаунтами курьеров</p>
      <UsersClient initialUsers={users} />
    </div>
  );
}