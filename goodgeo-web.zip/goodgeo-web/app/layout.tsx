import type { Metadata } from 'next';

export const metadata: Metadata = {
  title: 'GoodGeo — Navigation for couriers in Warsaw',
  description: 'Find the right entrance faster.',
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return children;
}