import { getTranslations } from 'next-intl/server';
import { Link } from '@/i18n/routing';

export default async function Footer() {
  const tFooter = await getTranslations('footer');
  const tNav = await getTranslations('nav');
  const year = new Date().getFullYear();

  return (
    <footer className="border-t border-brand-border bg-brand-bg mt-16">
      <div className="max-w-6xl mx-auto px-4 py-10 flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
        <div>
          <div className="flex items-center gap-2 mb-2">
            <span className="text-lg font-bold">GoodGeo</span>
          </div>
          <p className="text-sm text-slate-400">© {year} GoodGeo. {tFooter('rights')}.</p>
        </div>

        <nav className="flex flex-wrap gap-x-6 gap-y-2 text-sm text-slate-300">
          <Link href="/privacy" className="hover:text-white transition">{tNav('privacy')}</Link>
          <Link href="/terms" className="hover:text-white transition">{tNav('terms')}</Link>
          <Link href="/support" className="hover:text-white transition">{tFooter('contact')}</Link>
        </nav>
      </div>
    </footer>
  );
}