import { getTranslations } from 'next-intl/server';
import Image from 'next/image';
import { Link } from '@/i18n/routing';
import LanguageSwitcher from './LanguageSwitcher';

export default async function Header() {
  const t = await getTranslations('nav');

  return (
    <header className="sticky top-0 z-40 bg-brand-bg/95 backdrop-blur border-b border-brand-border">
      <div className="max-w-6xl mx-auto px-4 h-16 flex items-center justify-between">
        <Link href="/" className="flex items-center gap-2">
          <Image src="/logo.png" alt="GoodGeo" width={36} height={36} priority />
          <span className="text-xl font-bold">GoodGeo</span>
        </Link>

        <nav className="hidden md:flex items-center gap-6 text-sm text-slate-300">
          <Link href="/" className="hover:text-white transition">{t('home')}</Link>
          <Link href="/support" className="hover:text-white transition">{t('support')}</Link>
          <Link href="/privacy" className="hover:text-white transition">{t('privacy')}</Link>
          <Link href="/terms" className="hover:text-white transition">{t('terms')}</Link>
        </nav>

        <LanguageSwitcher />
      </div>
    </header>
  );
}