'use client';

import { useEffect, useMemo, useRef, useState } from 'react';
import mapboxgl from 'mapbox-gl';
import 'mapbox-gl/dist/mapbox-gl.css';
import {
  Search, MapPin, X, Trash2, Save, Plus, List, Locate,
  CheckCircle2, Circle, ChevronDown, ChevronRight, ChevronLeft,
  Inbox, Check, Eye, EyeOff,
} from 'lucide-react';
import type { Entrance, CompletedBuilding } from '@/lib/admin/types';
import {
  createEntrance,
  updateEntrance,
  deleteEntrance,
  markBuildingComplete,
  unmarkBuildingComplete,
  createApproach,
  updateApproach,
  deleteApproach,
  setAptRanges,
  type Approach,
  type AptRange,
} from '@/app/admin/entrances/actions';
import {
  listSuggestions,
  approveSuggestion,
  rejectSuggestion,
  type Suggestion,
} from '@/app/admin/entrances/creator-actions';
import {
  listVerificationStats,
  type VerificationStat,
} from '@/app/admin/entrances/actions';
import { useRouter, useSearchParams } from 'next/navigation';
import { loadSvgAsImage } from '@/lib/admin/loadSvgImage';

mapboxgl.accessToken = process.env.NEXT_PUBLIC_MAPBOX_TOKEN!;

const WARSAW_CENTER: [number, number] = [21.0122, 52.2297];
const MOBILE_BREAKPOINT = 768;

type Mode =
  | { type: 'idle' }
  | { type: 'creating'; lat: number; lng: number; buildingId: string | null }
  | { type: 'editing'; entrance: Entrance };

type FormValues = {
  number: string;
  korpus: string;
  address: string; // редактируемый адрес (пустая строка = оставить как есть/не менять)
  ranges: { from: string; to: string }[];
};

type Group = {
  key: string;
  address: string;
  buildingId: string | null;
  isComplete: boolean;
  entrances: Entrance[];
  facadeCount: number;
  hasUnattached: boolean;
  allAddresses: string[];
};

const SOURCE_ID = 'entrances-source';
const ICON_LAYER_ID = 'entrances-icons';
const LABEL_LAYER_ID = 'entrances-labels';
const ICON_NAME = 'door-marker';
const COMPLETED_FILL_LAYER_ID = 'buildings-completed-fill';
const BUILDING_LAYER_NATIVE = 'building';

// Точки подхода
const APPROACHES_SOURCE_ID = 'approaches-source';
const APPROACHES_CIRCLE_LAYER = 'approaches-circles';
const APPROACHES_LABEL_LAYER = 'approaches-labels';
const APPROACH_LINES_SOURCE_ID = 'approach-lines-source';
const APPROACH_LINES_LAYER = 'approach-lines';

// Pending suggestions (предложения курьеров на проверке)
const SUGGESTIONS_SOURCE_ID = 'suggestions-source';
const SUGGESTIONS_ICON_LAYER = 'suggestions-icons';
const SUGGESTIONS_LABEL_LAYER = 'suggestions-labels';
const SUGGESTION_ICON_NAME = 'door-marker-pending';

// Порог жалоб для бейджа "проблемный подъезд"
const VERIFICATION_BAD_THRESHOLD = 3;

export default function EntrancesMap({
  initialEntrances,
  initialCompletedBuildings = [],
  initialApproaches = [],
}: {
  initialEntrances: Entrance[];
  initialCompletedBuildings?: CompletedBuilding[];
  initialApproaches?: Approach[];
}) {
  const mapContainer = useRef<HTMLDivElement>(null);
  const map = useRef<mapboxgl.Map | null>(null);
  const tempMarker = useRef<mapboxgl.Marker | null>(null);
  const approachMarkersRef = useRef<Map<string, mapboxgl.Marker>>(new Map());
  const styleLoaded = useRef(false);

  const [entrances, setEntrances] = useState(initialEntrances);
  const [approaches, setApproaches] = useState<Approach[]>(initialApproaches);
  const [completedIds, setCompletedIds] = useState<Set<string>>(
    () => new Set(initialCompletedBuildings.map((b) => b.mapbox_building_id))
  );
  const [mode, setMode] = useState<Mode>({ type: 'idle' });
  const [search, setSearch] = useState('');
  // Lazy init: вычисляем mobile сразу, до первого рендера.
  // На SSR window нет — fallback false (desktop). На клиенте сразу правильное значение.
  const [isMobile, setIsMobile] = useState<boolean>(() =>
    typeof window !== 'undefined' ? window.innerWidth < MOBILE_BREAKPOINT : false
  );
  const [showMobileList, setShowMobileList] = useState(false);
  const [sheetExpanded, setSheetExpanded] = useState(false);

  // Pending suggestions
  const [suggestions, setSuggestions] = useState<Suggestion[]>([]);
  const suggestionsRef = useRef<Suggestion[]>([]);

  // Verification stats: Map<entrance_id, {correct, incorrect}>
  const [verifyStats, setVerifyStats] = useState<Map<string, VerificationStat>>(new Map());
  const [onlyComplaints, setOnlyComplaints] = useState(false);
  const [showSuggestions, setShowSuggestions] = useState(true);
  const [activeSuggestion, setActiveSuggestion] = useState<Suggestion | null>(null);
  const [suggestionBusy, setSuggestionBusy] = useState(false);

  const router = useRouter();
  const searchParams = useSearchParams();

  // Detect mobile viewport
  useEffect(() => {
    const check = () => setIsMobile(window.innerWidth < MOBILE_BREAKPOINT);
    check();
    window.addEventListener('resize', check);
    return () => window.removeEventListener('resize', check);
  }, []);

  // Если меняется mode — сворачиваем шторку обратно
  useEffect(() => {
    setSheetExpanded(false);
  }, [mode.type, mode.type === 'editing' ? mode.entrance.id : null]);

  // Загружаем pending suggestions при монтировании
  useEffect(() => {
    let cancelled = false;
    async function load() {
      const data = await listSuggestions({ status: 'pending' });
      if (!cancelled) {
        setSuggestions(data);
        suggestionsRef.current = data;
      }
    }
    load();
    return () => {
      cancelled = true;
    };
  }, []);

  // Загружаем статистику верификаций
  useEffect(() => {
    let cancelled = false;
    async function load() {
      const stats = await listVerificationStats();
      if (cancelled) return;
      const map = new Map<string, VerificationStat>();
      for (const s of stats) map.set(s.entrance_id, s);
      setVerifyStats(map);
    }
    load();
    return () => {
      cancelled = true;
    };
  }, []);

  // Синхронизируем ref когда меняется state
  useEffect(() => {
    suggestionsRef.current = suggestions;
  }, [suggestions]);

  const queryBuildingIdAt = (point: mapboxgl.Point | { x: number; y: number }) => {
    if (!map.current) return null;
    if (!map.current.getLayer(BUILDING_LAYER_NATIVE)) return null;
    const features = map.current.queryRenderedFeatures(point as mapboxgl.Point, {
      layers: [BUILDING_LAYER_NATIVE],
    });
    return features[0]?.id?.toString() ?? null;
  };

  // Init map
  useEffect(() => {
    if (!mapContainer.current || map.current) return;

    map.current = new mapboxgl.Map({
      container: mapContainer.current,
      style: 'mapbox://styles/mapbox/streets-v12',
      center: WARSAW_CENTER,
      zoom: 11,
    });

    map.current.addControl(new mapboxgl.NavigationControl(), 'top-right');
    map.current.addControl(
      new mapboxgl.GeolocateControl({
        positionOptions: { enableHighAccuracy: true },
        trackUserLocation: true,
        showUserHeading: true,
        showAccuracyCircle: true,
      }),
      'top-right'
    );

    map.current.on('load', async () => {
      try {
        const doorImage = await loadSvgAsImage('/door-marker.svg', 60);
        if (map.current && !map.current.hasImage(ICON_NAME)) {
          map.current.addImage(ICON_NAME, doorImage);
        }
      } catch (e) {
        console.error('🚪 Не удалось загрузить иконку:', e);
        return;
      }

      if (!map.current) return;

      const styleLayers = map.current.getStyle().layers ?? [];
      const firstSymbolId = styleLayers.find((l: { type: string; id: string }) => l.type === 'symbol')?.id;

      // === Здания ===
      map.current.addLayer(
        {
          id: COMPLETED_FILL_LAYER_ID,
          type: 'fill',
          source: 'composite',
          'source-layer': 'building',
          paint: {
            'fill-color': '#10b981',
            'fill-opacity': 0.4,
            'fill-outline-color': '#059669',
          },
          filter: [
            'in',
            ['to-string', ['id']],
            ['literal', Array.from(completedIds)],
          ],
        },
        firstSymbolId
      );

      // === Линии точек подхода (рисуем под подъездами) ===
      map.current.addSource(APPROACH_LINES_SOURCE_ID, {
        type: 'geojson',
        data: { type: 'FeatureCollection', features: [] },
      });

      map.current.addLayer({
        id: APPROACH_LINES_LAYER,
        type: 'line',
        source: APPROACH_LINES_SOURCE_ID,
        layout: {
          'line-cap': 'round',
          'line-join': 'round',
        },
        paint: {
          'line-color': '#2DB8A8',
          'line-width': 3,
          'line-dasharray': [2, 2],
        },
      });

      // === Подъезды ===
      map.current.addSource(SOURCE_ID, {
        type: 'geojson',
        data: { type: 'FeatureCollection', features: [] },
      });

      map.current.addLayer({
        id: ICON_LAYER_ID,
        type: 'symbol',
        source: SOURCE_ID,
        minzoom: 17,
        layout: {
          'icon-image': ICON_NAME,
          'icon-size': [
            'interpolate', ['linear'], ['zoom'],
            17, 0.06,
            18, 0.15,
            19, 0.20,
          ],
          'icon-allow-overlap': true,
          'icon-anchor': 'bottom',
        },
        paint: {
          'icon-opacity': [
            'interpolate', ['linear'], ['zoom'],
            14.8, 0,
            15.2, 1,
          ],
        },
      });

      map.current.addLayer({
        id: LABEL_LAYER_ID,
        type: 'symbol',
        source: SOURCE_ID,
        minzoom: 17.5,
        layout: {
          'text-field': [
            'format',
            ['get', 'entrance_number'],
            { 'font-scale': 1.3 },
            '\n',
            {},
            ['coalesce', ['get', 'apt_range'], ''],
            { 'font-scale': 0.85 },
          ],
          'text-font': ['Open Sans Bold', 'Arial Unicode MS Bold'],
          'text-size': [
            'interpolate', ['linear'], ['zoom'],
            17, 0,
            17.5, 9,
            18, 12,
          ],
          'text-anchor': 'top',
          'text-offset': [0, 0.3],
          'text-allow-overlap': false,
          'text-line-height': 1.1,
        },
        paint: {
          'text-color': '#1B3A5C',
          'text-opacity': [
            'interpolate', ['linear'], ['zoom'],
            16, 0,
            16.5, 1,
          ],
        },
      });

      // === Точки подхода (поверх подъездов) ===
      map.current.addSource(APPROACHES_SOURCE_ID, {
        type: 'geojson',
        data: { type: 'FeatureCollection', features: [] },
      });

      map.current.addLayer({
        id: APPROACHES_CIRCLE_LAYER,
        type: 'circle',
        source: APPROACHES_SOURCE_ID,
        minzoom: 16,
        paint: {
          'circle-radius': [
            'interpolate', ['linear'], ['zoom'],
            16, 6,
            18, 11,
            20, 14,
          ],
          'circle-color': '#2DB8A8',
          'circle-stroke-color': '#ffffff',
          'circle-stroke-width': 2.5,
          'circle-opacity': [
            'interpolate', ['linear'], ['zoom'],
            15.5, 0,
            16, 1,
          ],
        },
      });

      map.current.addLayer({
        id: APPROACHES_LABEL_LAYER,
        type: 'symbol',
        source: APPROACHES_SOURCE_ID,
        minzoom: 16.5,
        layout: {
          'text-field': ['get', 'order_index'],
          'text-font': ['Open Sans Bold', 'Arial Unicode MS Bold'],
          'text-size': [
            'interpolate', ['linear'], ['zoom'],
            16.5, 9,
            18, 12,
            20, 14,
          ],
          'text-allow-overlap': true,
          'text-ignore-placement': true,
        },
        paint: {
          'text-color': '#ffffff',
          'text-opacity': [
            'interpolate', ['linear'], ['zoom'],
            16, 0,
            16.5, 1,
          ],
        },
      });

      // === Suggestions (предложения на проверке) ===
      try {
        const pendingImage = await loadSvgAsImage('/door-marker-pending.svg', 60);
        if (map.current && !map.current.hasImage(SUGGESTION_ICON_NAME)) {
          map.current.addImage(SUGGESTION_ICON_NAME, pendingImage);
        }
      } catch (e) {
        console.warn('🟡 Не удалось загрузить иконку pending:', e);
      }

      if (!map.current) return;

      map.current.addSource(SUGGESTIONS_SOURCE_ID, {
        type: 'geojson',
        data: { type: 'FeatureCollection', features: [] },
      });

      map.current.addLayer({
        id: SUGGESTIONS_ICON_LAYER,
        type: 'symbol',
        source: SUGGESTIONS_SOURCE_ID,
        minzoom: 14,
        layout: {
          'icon-image': SUGGESTION_ICON_NAME,
          'icon-size': [
            'interpolate', ['linear'], ['zoom'],
            14, 0.4,
            17, 0.6,
            19, 0.8,
          ],
          'icon-allow-overlap': true,
          'icon-anchor': 'bottom',
        },
      });

      map.current.addLayer({
        id: SUGGESTIONS_LABEL_LAYER,
        type: 'symbol',
        source: SUGGESTIONS_SOURCE_ID,
        minzoom: 16,
        layout: {
          'text-field': '?',
          'text-font': ['Open Sans Bold', 'Arial Unicode MS Bold'],
          'text-size': 14,
          'text-anchor': 'top',
          'text-offset': [0, 0.4],
          'text-allow-overlap': true,
        },
        paint: {
          'text-color': '#92400e',
          'text-halo-color': '#ffffff',
          'text-halo-width': 1.5,
        },
      });

      styleLoaded.current = true;
      updateSource(entrances);
      updateSuggestionsSource(suggestions, showSuggestions);
      updateApproachesSource(approaches, mode);
      updateApproachLines(approaches, mode);

      // Применяем URL-параметры центрирования (если есть)
      const lat = parseFloat(searchParams.get('lat') ?? '');
      const lng = parseFloat(searchParams.get('lng') ?? '');
      const zoom = parseFloat(searchParams.get('zoom') ?? '17');
      if (!isNaN(lat) && !isNaN(lng)) {
        map.current.flyTo({
          center: [lng, lat],
          zoom: isNaN(zoom) ? 17 : zoom,
        });
      }
    });

    map.current.on('click', (e) => {
      const isMobileNow = window.innerWidth < MOBILE_BREAKPOINT;

      // Сначала проверяем клик по pending suggestion
      const pendingFeatures = map.current!.queryRenderedFeatures(e.point, {
        layers: [SUGGESTIONS_ICON_LAYER, SUGGESTIONS_LABEL_LAYER],
      });

      if (pendingFeatures.length > 0) {
        const sid = pendingFeatures[0].properties?.id;
        const sugg = suggestionsRef.current.find((x) => x.id === sid);
        if (sugg) {
          setActiveSuggestion(sugg);
          map.current!.flyTo({ center: [sugg.lng, sugg.lat], zoom: 18 });
          return;
        }
      }

      const features = map.current!.queryRenderedFeatures(e.point, {
        layers: [ICON_LAYER_ID, LABEL_LAYER_ID],
      });

      if (features.length > 0) {
        const id = features[0].properties?.id;
        const entrance = entrances.find((x) => x.id === id);
        if (entrance) {
          setMode({ type: 'editing', entrance });
          if (tempMarker.current) {
            tempMarker.current.remove();
            tempMarker.current = null;
          }
          map.current!.flyTo({ center: [entrance.lng, entrance.lat], zoom: 17 });
          return;
        }
      }

      if (isMobileNow) return;

      const buildingId = queryBuildingIdAt(e.point);

      setMode({
        type: 'creating',
        lat: e.lngLat.lat,
        lng: e.lngLat.lng,
        buildingId,
      });

      if (tempMarker.current) tempMarker.current.remove();

      const tempEl = document.createElement('div');
      tempEl.style.cursor = 'pointer';
      tempEl.innerHTML =
        '<img src="/door-marker-temp.svg" width="30" height="50" style="display:block" />';

      tempMarker.current = new mapboxgl.Marker({
        element: tempEl,
        anchor: 'bottom',
        draggable: true,
      })
        .setLngLat(e.lngLat)
        .addTo(map.current!);

      tempMarker.current.on('dragend', () => {
        const lngLat = tempMarker.current!.getLngLat();
        const px = map.current!.project(lngLat);
        const newBuildingId = queryBuildingIdAt(px);
        setMode({
          type: 'creating',
          lat: lngLat.lat,
          lng: lngLat.lng,
          buildingId: newBuildingId,
        });
      });
    });

    map.current.on('mouseenter', ICON_LAYER_ID, () => {
      if (map.current) map.current.getCanvas().style.cursor = 'pointer';
    });
    map.current.on('mouseleave', ICON_LAYER_ID, () => {
      if (map.current) map.current.getCanvas().style.cursor = '';
    });

    return () => {
      // Cleanup approach markers
      approachMarkersRef.current.forEach((m) => m.remove());
      approachMarkersRef.current.clear();
      map.current?.remove();
      map.current = null;
      styleLoaded.current = false;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    if (styleLoaded.current) updateSource(entrances);
  }, [entrances]);

  useEffect(() => {
    if (!styleLoaded.current || !map.current) return;
    if (map.current.getLayer(COMPLETED_FILL_LAYER_ID)) {
      map.current.setFilter(COMPLETED_FILL_LAYER_ID, [
        'in',
        ['to-string', ['id']],
        ['literal', Array.from(completedIds)],
      ]);
    }
  }, [completedIds]);

  useEffect(() => {
    if (!styleLoaded.current) return;
    updateApproachesSource(approaches, mode);
    updateApproachLines(approaches, mode);
  }, [approaches, mode]);

  // Обновление source pending suggestions
  useEffect(() => {
    if (!styleLoaded.current) return;
    updateSuggestionsSource(suggestions, showSuggestions);
  }, [suggestions, showSuggestions]);

  useEffect(() => {
    if (!styleLoaded.current || !map.current) return;

    if (mode.type !== 'editing') {
      approachMarkersRef.current.forEach((m) => m.remove());
      approachMarkersRef.current.clear();
      return;
    }

    const currentApproaches = approaches.filter(
      (a) => a.entrance_id === mode.entrance.id
    );
    const newIds = new Set(currentApproaches.map((a) => a.id));

    for (const [id, marker] of approachMarkersRef.current.entries()) {
      if (!newIds.has(id)) {
        marker.remove();
        approachMarkersRef.current.delete(id);
      }
    }

    for (const approach of currentApproaches) {
      const existing = approachMarkersRef.current.get(approach.id);
      if (existing) {
        existing.setLngLat([approach.lng, approach.lat]);
        const el = existing.getElement();
        if (el.dataset.orderIndex !== String(approach.order_index)) {
          el.textContent = String(approach.order_index);
          el.dataset.orderIndex = String(approach.order_index);
        }
      } else {
        const el = document.createElement('div');
        el.style.cssText =
          'cursor:grab;width:32px;height:32px;display:flex;align-items:center;justify-content:center;background:#2DB8A8;border:3px solid white;border-radius:50%;box-shadow:0 2px 8px rgba(0,0,0,0.3);font-weight:700;font-size:14px;color:white;font-family:system-ui;-webkit-user-select:none;user-select:none;touch-action:none';
        el.textContent = String(approach.order_index);
        el.dataset.orderIndex = String(approach.order_index);

        const marker = new mapboxgl.Marker({
          element: el,
          draggable: true,
          anchor: 'center',
        })
          .setLngLat([approach.lng, approach.lat])
          .addTo(map.current!);

        marker.on('dragstart', () => {
          el.style.cursor = 'grabbing';
        });

        marker.on('dragend', async () => {
          el.style.cursor = 'grab';
          const ll = marker.getLngLat();
          const result = await updateApproach(approach.id, {
            lat: ll.lat,
            lng: ll.lng,
          });
          if (result.error) {
            alert('Ошибка: ' + result.error);
            setApproaches((prev) => [...prev]);
            return;
          }
          setApproaches((prev) =>
            prev.map((a) =>
              a.id === approach.id ? { ...a, lat: ll.lat, lng: ll.lng } : a
            )
          );
        });

        approachMarkersRef.current.set(approach.id, marker);
      }
    }
  }, [mode, approaches]);

  function updateSource(list: Entrance[]) {
    if (!map.current) return;
    const source = map.current.getSource(SOURCE_ID) as mapboxgl.GeoJSONSource | undefined;
    if (!source) return;

    source.setData({
      type: 'FeatureCollection',
      features: list.map((e) => ({
        type: 'Feature',
        geometry: { type: 'Point', coordinates: [e.lng, e.lat] },
        properties: {
          id: e.id,
          entrance_number: e.entrance_number ?? '?',
          apt_range: formatRange(e),
        },
      })),
    });
  }

  function updateApproachesSource(list: Approach[], currentMode: Mode) {
    if (!map.current) return;
    const source = map.current.getSource(APPROACHES_SOURCE_ID) as mapboxgl.GeoJSONSource | undefined;
    if (!source) return;

    const hideEntranceId = currentMode.type === 'editing' ? currentMode.entrance.id : null;
    const filtered = hideEntranceId
      ? list.filter((a) => a.entrance_id !== hideEntranceId)
      : list;

    source.setData({
      type: 'FeatureCollection',
      features: filtered.map((a) => ({
        type: 'Feature',
        geometry: { type: 'Point', coordinates: [a.lng, a.lat] },
        properties: {
          id: a.id,
          order_index: a.order_index,
          entrance_id: a.entrance_id,
        },
      })),
    });
  }

  function updateApproachLines(list: Approach[], currentMode: Mode) {
    if (!map.current) return;
    const source = map.current.getSource(APPROACH_LINES_SOURCE_ID) as mapboxgl.GeoJSONSource | undefined;
    if (!source) return;

    if (currentMode.type !== 'editing') {
      source.setData({ type: 'FeatureCollection', features: [] });
      return;
    }

    const ent = currentMode.entrance;
    const entApproaches = list
      .filter((a) => a.entrance_id === ent.id)
      .sort((a, b) => a.order_index - b.order_index);

    if (entApproaches.length === 0) {
      source.setData({ type: 'FeatureCollection', features: [] });
      return;
    }

    const coords: [number, number][] = entApproaches.map((a) => [a.lng, a.lat]);
    coords.push([ent.lng, ent.lat]);

    source.setData({
      type: 'FeatureCollection',
      features: [
        {
          type: 'Feature',
          properties: {},
          geometry: { type: 'LineString', coordinates: coords },
        },
      ],
    });
  }

  function updateSuggestionsSource(list: Suggestion[], visible: boolean) {
    if (!map.current) return;
    const source = map.current.getSource(SUGGESTIONS_SOURCE_ID) as
      | mapboxgl.GeoJSONSource
      | undefined;
    if (!source) return;

    if (!visible) {
      source.setData({ type: 'FeatureCollection', features: [] });
      return;
    }

    source.setData({
      type: 'FeatureCollection',
      features: list.map((s) => ({
        type: 'Feature',
        geometry: { type: 'Point', coordinates: [s.lng, s.lat] },
        properties: {
          id: s.id,
          entrance_number: s.entrance_number ?? '?',
        },
      })),
    });
  }

  async function handleApproveSuggestion(id: string) {
    if (!confirm('Одобрить это предложение? Подъезд появится на карте.')) return;
    setSuggestionBusy(true);
    const res = await approveSuggestion(id);
    if (res.error) {
      alert('Ошибка: ' + res.error);
      setSuggestionBusy(false);
      return;
    }
    setSuggestions((prev) => prev.filter((s) => s.id !== id));
    setActiveSuggestion(null);
    setSuggestionBusy(false);
    router.refresh();
  }

  async function handleRejectSuggestion(id: string) {
    const reason = prompt('Причина отклонения (можно пропустить):');
    if (reason === null) return;
    setSuggestionBusy(true);
    const res = await rejectSuggestion(id, reason || undefined);
    if (res.error) {
      alert('Ошибка: ' + res.error);
      setSuggestionBusy(false);
      return;
    }
    setSuggestions((prev) => prev.filter((s) => s.id !== id));
    setActiveSuggestion(null);
    setSuggestionBusy(false);
    router.refresh();
  }

  const handleClose = () => {
    setMode({ type: 'idle' });
    if (tempMarker.current) {
      tempMarker.current.remove();
      tempMarker.current = null;
    }
  };

  const parseInput = (input: FormValues) => ({
    entrance_number: input.number.trim() || null,
    korpus: input.korpus.trim() ? input.korpus.trim().toUpperCase() : null,
    address: input.address.trim() || null,
  });

  // Парсим массив диапазонов из формы → AptRangeInput[]
  const parseRanges = (input: FormValues) => {
    return input.ranges
      .map((r, idx) => {
        const from = parseInt(r.from.trim(), 10);
        const to = parseInt(r.to.trim(), 10);
        if (!from || !to || isNaN(from) || isNaN(to)) return null;
        if (from > to) return null;
        return { apt_from: from, apt_to: to, order_index: idx + 1 };
      })
      .filter((r): r is { apt_from: number; apt_to: number; order_index: number } => r !== null);
  };

  const handleMobileAddHere = () => {
    if (!map.current) return;
    const center = map.current.getCenter();
    const px = map.current.project(center);
    const buildingId = queryBuildingIdAt(px);

    setMode({
      type: 'creating',
      lat: center.lat,
      lng: center.lng,
      buildingId,
    });
  };

  const handleCreate = async (input: FormValues) => {
    if (mode.type !== 'creating') return;
    const result = await createEntrance({
      ...parseInput(input),
      lat: mode.lat,
      lng: mode.lng,
      mapbox_building_id: mode.buildingId,
    });
    if (result.error) {
      alert('Ошибка: ' + result.error);
      return;
    }

    // Сохраняем диапазоны квартир для нового подъезда
    const ranges = parseRanges(input);
    if (ranges.length > 0) {
      const rangesResult = await setAptRanges(result.data!.id, ranges);
      if (rangesResult.error) {
        alert('Ошибка диапазонов: ' + rangesResult.error);
      }
    }

    setEntrances([{ ...result.data!, ranges: ranges.map((r, idx) => ({
      id: `temp-${idx}`,
      entrance_id: result.data!.id,
      apt_from: r.apt_from,
      apt_to: r.apt_to,
      order_index: r.order_index,
    })) }, ...entrances]);

    if (tempMarker.current) {
      tempMarker.current.remove();
      tempMarker.current = null;
    }

    setMode({ type: 'editing', entrance: result.data! });
    router.refresh();
  };

  const handleUpdate = async (input: FormValues) => {
    if (mode.type !== 'editing') return;

    const extra: Partial<{ mapbox_building_id: string | null }> = {};
    if (!mode.entrance.mapbox_building_id && map.current) {
      const px = map.current.project([mode.entrance.lng, mode.entrance.lat]);
      const bid = queryBuildingIdAt(px);
      if (bid) extra.mapbox_building_id = bid;
    }

    const result = await updateEntrance(mode.entrance.id, {
      ...parseInput(input),
      ...extra,
    });
    if (result.error) {
      alert('Ошибка: ' + result.error);
      return;
    }

    // Сохраняем диапазоны квартир
    const ranges = parseRanges(input);
    const rangesResult = await setAptRanges(mode.entrance.id, ranges);
    if (rangesResult.error) {
      alert('Ошибка диапазонов: ' + rangesResult.error);
    }

    const updatedEntrance = {
      ...result.data!,
      ranges: ranges.map((r, idx) => ({
        id: `temp-${idx}`,
        entrance_id: mode.entrance.id,
        apt_from: r.apt_from,
        apt_to: r.apt_to,
        order_index: r.order_index,
      })),
    };

    setEntrances(entrances.map((e) => (e.id === mode.entrance.id ? updatedEntrance : e)));
    setMode({ type: 'editing', entrance: updatedEntrance });
    router.refresh();
  };

  const handleDelete = async () => {
    if (mode.type !== 'editing') return;
    if (!confirm('Удалить этот подъезд? Все точки подхода тоже будут удалены.')) return;
    const result = await deleteEntrance(mode.entrance.id);
    if (result.error) {
      alert('Ошибка: ' + result.error);
      return;
    }
    setEntrances(entrances.filter((e) => e.id !== mode.entrance.id));
    setApproaches(approaches.filter((a) => a.entrance_id !== mode.entrance.id));
    handleClose();
    router.refresh();
  };

  const handleAttachToNearestBuilding = async () => {
    if (mode.type !== 'editing') return;
    const me = mode.entrance;

    let nearestId: string | null = null;
    let nearestDist = 30;
    for (const e of entrances) {
      if (e.id === me.id || !e.mapbox_building_id) continue;
      const d = haversineMetersAdmin(
        { lat: me.lat, lng: me.lng },
        { lat: e.lat, lng: e.lng }
      );
      if (d < nearestDist) {
        nearestDist = d;
        nearestId = e.mapbox_building_id;
      }
    }

    if (!nearestId) {
      if (map.current) {
        const px = map.current.project([me.lng, me.lat]);
        const bid = queryBuildingIdAt(px);
        if (bid) nearestId = bid;
      }
    }

    if (!nearestId) {
      alert(
        'Не получилось привязать к дому. Увеличь масштаб карты так, чтобы было видно контур здания, и попробуй снова.'
      );
      return;
    }

    const result = await updateEntrance(me.id, { mapbox_building_id: nearestId });
    if (result.error) {
      alert('Ошибка: ' + result.error);
      return;
    }
    setEntrances(entrances.map((e) => (e.id === me.id ? result.data! : e)));
    setMode({ type: 'editing', entrance: result.data! });
    router.refresh();
  };

  const handleToggleComplete = async () => {
    if (mode.type !== 'editing') return;
    const buildingId = mode.entrance.mapbox_building_id;
    if (!buildingId) {
      alert('Здание не определено в Mapbox.');
      return;
    }

    const isComplete = completedIds.has(buildingId);
    const result = isComplete
      ? await unmarkBuildingComplete(buildingId)
      : await markBuildingComplete(buildingId);

    if (result.error) {
      alert('Ошибка: ' + result.error);
      return;
    }

    setCompletedIds((prev) => {
      const next = new Set(prev);
      if (isComplete) next.delete(buildingId);
      else next.add(buildingId);
      return next;
    });
  };

  const handleAddApproach = async (orderIndex: number) => {
    if (mode.type !== 'editing' || !map.current) return;
    const center = map.current.getCenter();

    const result = await createApproach({
      entrance_id: mode.entrance.id,
      lat: center.lat,
      lng: center.lng,
      order_index: orderIndex,
    });

    if (result.error) {
      alert('Ошибка: ' + result.error);
      return;
    }
    setApproaches((prev) => [...prev, result.data!]);

    if (window.innerWidth < MOBILE_BREAKPOINT) {
      map.current.easeTo({
        center: [result.data!.lng, result.data!.lat],
        offset: [0, -120],
        duration: 350,
      });
    }
  };

  const handleDeleteApproach = async (approachId: string) => {
    if (!confirm('Удалить эту точку подхода?')) return;
    const result = await deleteApproach(approachId);
    if (result.error) {
      alert('Ошибка: ' + result.error);
      return;
    }
    setApproaches((prev) => prev.filter((a) => a.id !== approachId));
  };

  const flyToEntrance = (entrance: Entrance) => {
    map.current?.flyTo({ center: [entrance.lng, entrance.lat], zoom: 18 });
    setMode({ type: 'editing', entrance });
    setShowMobileList(false);
  };

  const flyToGroup = (entrance: Entrance) => {
    map.current?.flyTo({ center: [entrance.lng, entrance.lat], zoom: 18 });
    setShowMobileList(false);
    if (window.innerWidth < MOBILE_BREAKPOINT) {
      setMode({ type: 'editing', entrance });
    }
  };

  const isCurrentBuildingComplete =
    mode.type === 'editing' &&
    !!mode.entrance.mapbox_building_id &&
    completedIds.has(mode.entrance.mapbox_building_id);

  const currentApproaches = useMemo(() => {
    if (mode.type !== 'editing') return [];
    return approaches
      .filter((a) => a.entrance_id === mode.entrance.id)
      .sort((a, b) => a.order_index - b.order_index);
  }, [mode, approaches]);


  // ============== MOBILE LAYOUT ==============
  if (isMobile) {
    return (
      <div className="fixed inset-0 bg-white">
        <div ref={mapContainer} className="absolute inset-0" />

        {mode.type === 'idle' && (
          <div className="absolute top-3 left-3 right-3 flex justify-between items-center pointer-events-none z-10">
            <button
              onClick={() => setShowMobileList(true)}
              className="w-10 h-10 bg-white rounded-full shadow-md flex items-center justify-center pointer-events-auto"
            >
              <List size={18} className="text-slate-700" />
            </button>
            <div className="bg-white rounded-full px-3 py-1.5 text-xs font-medium text-slate-700 shadow-md pointer-events-auto">
              {entrances.length} подъездов
            </div>
          </div>
        )}

        {mode.type === 'idle' && (
          <div className="absolute top-1/2 left-1/2 pointer-events-none z-10" style={{ transform: 'translate(-50%, -100%)' }}>
            <svg width="40" height="56" viewBox="0 0 40 56">
              <path
                d="M 9 40 L 9 14 Q 9 5 16 5 L 24 5 Q 31 5 31 14 L 31 40 Z"
                fill="white"
                stroke="#2DB8A8"
                strokeWidth="3"
                strokeLinejoin="round"
              />
              <circle cx="24" cy="24" r="2.5" fill="#2DB8A8" />
              <line x1="20" y1="40" x2="20" y2="52" stroke="#2DB8A8" strokeWidth="2" strokeDasharray="3,2" />
            </svg>
          </div>
        )}

        {mode.type === 'idle' && (
          <div className="absolute bottom-4 left-4 right-4 z-10">
            <button
              onClick={handleMobileAddHere}
              className="w-full bg-teal-600 hover:bg-teal-700 text-white py-3.5 rounded-xl font-medium text-sm shadow-lg flex items-center justify-center gap-2"
            >
              <Plus size={18} />
              Добавить здесь
            </button>
          </div>
        )}

        {(mode.type === 'creating' || mode.type === 'editing') && (
          <div
            className={`absolute bottom-0 left-0 right-0 bg-white rounded-t-2xl shadow-2xl z-20 overflow-y-auto transition-[max-height] duration-300 ${
              sheetExpanded ? 'max-h-[85vh]' : 'max-h-[42vh]'
            }`}
          >
            <button
              type="button"
              onClick={() => setSheetExpanded((v) => !v)}
              className="w-full pt-2 pb-1 flex flex-col items-center justify-center cursor-pointer hover:bg-slate-50"
              aria-label={sheetExpanded ? 'Свернуть' : 'Развернуть'}
            >
              <div className="w-12 h-1 bg-slate-300 rounded-full" />
              <span className="text-[10px] text-slate-400 mt-1">
                {sheetExpanded ? '▼ свернуть' : '▲ потянуть вверх'}
              </span>
            </button>
            {mode.type === 'creating' && (
              <FormPanel
                title="Новый подъезд"
                initial={{
                  number: '',
                  korpus: '',
                  address: '',
                  ranges: [{ from: '', to: '' }],
                }}
                coords={{ lat: mode.lat, lng: mode.lng }}
                buildingStatus={mode.buildingId ? 'detected' : 'not_found'}
                onSave={handleCreate}
                onCancel={handleClose}
                approaches={[]}
                entranceId={null}
                onAddApproach={handleAddApproach}
                onDeleteApproach={handleDeleteApproach}
                compact
              />
            )}
            {mode.type === 'editing' && (
              <FormPanel
                title="Редактировать"
                initial={{
                  number: mode.entrance.entrance_number ?? '',
                  korpus: mode.entrance.korpus ?? '',
                  address: mode.entrance.address ?? '',
                  ranges: (mode.entrance.ranges ?? []).length > 0
                    ? mode.entrance.ranges!
                        .slice()
                        .sort((a, b) => a.order_index - b.order_index)
                        .map((r) => ({ from: String(r.apt_from), to: String(r.apt_to) }))
                    : [
                        mode.entrance.apt_from && mode.entrance.apt_to
                          ? { from: String(mode.entrance.apt_from), to: String(mode.entrance.apt_to) }
                          : { from: '', to: '' }
                      ],
                }}
                coords={{ lat: mode.entrance.lat, lng: mode.entrance.lng }}
                buildingStatus={mode.entrance.mapbox_building_id ? 'detected' : 'not_found'}
                isBuildingComplete={isCurrentBuildingComplete}
                onToggleComplete={handleToggleComplete}
                onAttachBuilding={handleAttachToNearestBuilding}
                onSave={handleUpdate}
                onCancel={handleClose}
                onDelete={handleDelete}
                approaches={currentApproaches}
                entranceId={mode.entrance.id}
                onAddApproach={handleAddApproach}
                onDeleteApproach={handleDeleteApproach}
                compact
              />
            )}
          </div>
        )}

        {showMobileList && (
          <div className="absolute inset-0 bg-white z-30 flex flex-col">
            <MobileListPanel
              search={search}
              onSearchChange={setSearch}
              entrances={entrances}
              completedIds={completedIds}
              verifyStats={verifyStats}
              onlyComplaints={onlyComplaints}
              onToggleOnlyComplaints={() => setOnlyComplaints((v) => !v)}
              onSelectEntrance={flyToEntrance}
              onSelectGroup={flyToGroup}
              onClose={() => setShowMobileList(false)}
            />
          </div>
        )}
      </div>
    );
  }

  // ============== DESKTOP LAYOUT ==============
  return (
    <div className="flex h-[calc(100vh-8rem)] gap-4 relative">
      <div ref={mapContainer} className="flex-1 rounded-2xl overflow-hidden border border-slate-200" />

      {/* Toggle pending suggestions (поверх карты) */}
      <button
        onClick={() => setShowSuggestions((v) => !v)}
        className={`absolute top-3 left-3 z-10 px-3 py-2 rounded-lg shadow-md flex items-center gap-2 text-sm font-medium transition ${
          showSuggestions
            ? 'bg-amber-500 text-white hover:bg-amber-600'
            : 'bg-white text-slate-600 hover:bg-slate-50'
        }`}
        title={showSuggestions ? 'Скрыть предложения' : 'Показать предложения'}
      >
        {showSuggestions ? <Eye size={16} /> : <EyeOff size={16} />}
        <Inbox size={16} />
        {suggestions.length > 0 && (
          <span className="font-bold">{suggestions.length}</span>
        )}
      </button>

      {/* Модалка активного suggestion */}
      {activeSuggestion && (
        <SuggestionPopup
          suggestion={activeSuggestion}
          busy={suggestionBusy}
          onApprove={() => handleApproveSuggestion(activeSuggestion.id)}
          onReject={() => handleRejectSuggestion(activeSuggestion.id)}
          onClose={() => setActiveSuggestion(null)}
        />
      )}

      <div className="w-96 bg-white border border-slate-200 rounded-2xl flex flex-col overflow-hidden">
        {mode.type === 'idle' && (
          <ListPanel
            search={search}
            onSearchChange={setSearch}
            entrances={entrances}
            completedIds={completedIds}
            verifyStats={verifyStats}
            onlyComplaints={onlyComplaints}
            onToggleOnlyComplaints={() => setOnlyComplaints((v) => !v)}
            onSelectEntrance={flyToEntrance}
            onSelectGroup={flyToGroup}
          />
        )}

        {mode.type === 'creating' && (
          <FormPanel
            title="Новый подъезд"
            initial={{
                  address: '',
                  number: '',
                  korpus: '',
                  ranges: [{ from: '', to: '' }],
                }}
            coords={{ lat: mode.lat, lng: mode.lng }}
            buildingStatus={mode.buildingId ? 'detected' : 'not_found'}
            onSave={handleCreate}
            onCancel={handleClose}
            approaches={[]}
            entranceId={null}
            onAddApproach={handleAddApproach}
            onDeleteApproach={handleDeleteApproach}
          />
        )}

        {mode.type === 'editing' && (
          <FormPanel
            title="Редактировать"
            initial={{
                  address: mode.entrance.address ?? '',
                  number: mode.entrance.entrance_number ?? '',
                  korpus: mode.entrance.korpus ?? '',
                  ranges: (mode.entrance.ranges ?? []).length > 0
                    ? mode.entrance.ranges!
                        .slice()
                        .sort((a, b) => a.order_index - b.order_index)
                        .map((r) => ({ from: String(r.apt_from), to: String(r.apt_to) }))
                    : [
                        // Migration: если новых диапазонов нет, но есть legacy — показываем их
                        mode.entrance.apt_from && mode.entrance.apt_to
                          ? { from: String(mode.entrance.apt_from), to: String(mode.entrance.apt_to) }
                          : { from: '', to: '' }
                      ],
                }}
            coords={{ lat: mode.entrance.lat, lng: mode.entrance.lng }}
            buildingStatus={mode.entrance.mapbox_building_id ? 'detected' : 'not_found'}
            isBuildingComplete={isCurrentBuildingComplete}
            onToggleComplete={handleToggleComplete}
            onAttachBuilding={handleAttachToNearestBuilding}
            onSave={handleUpdate}
            onCancel={handleClose}
            onDelete={handleDelete}
            approaches={currentApproaches}
            entranceId={mode.entrance.id}
            onAddApproach={handleAddApproach}
            onDeleteApproach={handleDeleteApproach}
          />
        )}
      </div>
    </div>
  );
}

// === Helpers ===

function SuggestionPopup({
  suggestion,
  busy,
  onApprove,
  onReject,
  onClose,
}: {
  suggestion: Suggestion;
  busy: boolean;
  onApprove: () => void;
  onReject: () => void;
  onClose: () => void;
}) {
  const s = suggestion;
  const rangesText =
    s.ranges && s.ranges.length > 0
      ? s.ranges.map((r) => `${r.apt_from}–${r.apt_to}`).join(', ')
      : s.apt_from && s.apt_to
      ? `${s.apt_from}–${s.apt_to}`
      : '—';
  const extrasText =
    s.apt_extras && s.apt_extras.length > 0 ? s.apt_extras.join(', ') : null;

  return (
    <div className="absolute top-3 right-[26rem] z-20 w-80 bg-white rounded-2xl shadow-2xl border border-amber-200 overflow-hidden">
      <div className="bg-amber-50 px-4 py-3 flex items-center justify-between border-b border-amber-100">
        <div className="flex items-center gap-2">
          <Inbox size={16} className="text-amber-600" />
          <span className="text-sm font-semibold text-amber-800">Предложение курьера</span>
        </div>
        <button
          onClick={onClose}
          className="w-6 h-6 flex items-center justify-center rounded hover:bg-amber-100 text-amber-700"
        >
          <X size={14} />
        </button>
      </div>

      <div className="p-4 space-y-3">
        <div>
          <div className="font-semibold text-slate-800">
            {s.address ?? 'Без адреса'}
            {s.korpus && (
              <span className="ml-1 text-teal-600 font-bold">· корп. {s.korpus}</span>
            )}
          </div>
          <div className="text-sm text-slate-500 mt-0.5">
            Подъезд №{s.entrance_number ?? '—'} · кв. {rangesText}
          </div>
          {extrasText && (
            <div className="text-xs text-slate-400 mt-0.5">+ доп. {extrasText}</div>
          )}
        </div>

        {s.suggester && (
          <div className="text-xs text-slate-500 bg-slate-50 rounded-md px-3 py-2">
            Курьер: <span className="font-medium text-slate-700">{s.suggester.name ?? 'Без имени'}</span>
            <span className="ml-1 font-mono text-slate-400">
              ID {s.suggester.client_number ?? '—'}
            </span>
          </div>
        )}

        <div className="flex gap-2 pt-1">
          <button
            onClick={onApprove}
            disabled={busy}
            className="flex-1 flex items-center justify-center gap-1.5 px-3 py-2 bg-teal-600 hover:bg-teal-700 disabled:bg-slate-300 text-white rounded-lg text-sm font-medium transition"
          >
            <Check size={14} />
            Одобрить
          </button>
          <button
            onClick={onReject}
            disabled={busy}
            className="flex items-center justify-center gap-1.5 px-3 py-2 bg-white border border-rose-200 hover:bg-rose-50 disabled:opacity-50 text-rose-600 rounded-lg text-sm font-medium transition"
          >
            <X size={14} />
            Отклонить
          </button>
        </div>
      </div>
    </div>
  );
}

function formatRange(e: Entrance): string {
  // Если есть массив диапазонов — показываем все через запятую
  if (e.ranges && e.ranges.length > 0) {
    return e.ranges
      .slice()
      .sort((a, b) => a.order_index - b.order_index)
      .map((r) => `${r.apt_from}–${r.apt_to}`)
      .join(', ');
  }
  // Fallback на legacy поля
  if (e.apt_from && e.apt_to) return `${e.apt_from}–${e.apt_to}`;
  if (e.apt_from) return `${e.apt_from}+`;
  return '';
}

function pluralEntrances(n: number): string {
  const mod10 = n % 10;
  const mod100 = n % 100;
  if (mod10 === 1 && mod100 !== 11) return `${n} подъезд`;
  if (mod10 >= 2 && mod10 <= 4 && (mod100 < 10 || mod100 >= 20)) return `${n} подъезда`;
  return `${n} подъездов`;
}

function groupEntrances(entrances: Entrance[], completedIds: Set<string>): Group[] {
  const knownBuildings = new Map<string, { lat: number; lng: number }>();
  for (const e of entrances) {
    if (e.mapbox_building_id && !knownBuildings.has(e.mapbox_building_id)) {
      knownBuildings.set(e.mapbox_building_id, { lat: e.lat, lng: e.lng });
    }
  }

  const groupMap = new Map<string, Group>();
  const ATTACH_RADIUS_M = 30;

  for (const e of entrances) {
    let effectiveBuildingId = e.mapbox_building_id;

    if (!effectiveBuildingId) {
      let nearestId: string | null = null;
      let nearestDist = ATTACH_RADIUS_M;
      for (const [bid, ref] of knownBuildings) {
        const d = haversineMetersAdmin({ lat: e.lat, lng: e.lng }, ref);
        if (d < nearestDist) {
          nearestDist = d;
          nearestId = bid;
        }
      }
      effectiveBuildingId = nearestId;
    }

    const key = effectiveBuildingId ?? e.address ?? `__solo_${e.id}`;
    let group = groupMap.get(key);
    if (!group) {
      group = {
        key,
        address: e.address ?? 'Без адреса',
        buildingId: effectiveBuildingId,
        isComplete: effectiveBuildingId ? completedIds.has(effectiveBuildingId) : false,
        entrances: [],
        facadeCount: 0,
        hasUnattached: false,
        allAddresses: [],
      };
      groupMap.set(key, group);
    }
    group.entrances.push(e);
    if (!e.mapbox_building_id) group.hasUnattached = true;
  }

  const groups = Array.from(groupMap.values());

  for (const g of groups) {
    g.entrances.sort((a, b) =>
      (a.entrance_number ?? '').localeCompare(b.entrance_number ?? '')
    );

    const addressCounts = new Map<string, number>();
    for (const e of g.entrances) {
      if (!e.address) continue;
      addressCounts.set(e.address, (addressCounts.get(e.address) ?? 0) + 1);
    }

    if (addressCounts.size > 0) {
      let mainAddress = g.address;
      let maxCount = 0;
      for (const [addr, count] of addressCounts) {
        if (count > maxCount) {
          maxCount = count;
          mainAddress = addr;
        }
      }
      g.address = mainAddress;
      g.allAddresses = Array.from(addressCounts.keys()).sort();
      g.facadeCount = addressCounts.size;
    }
  }

  groups.sort((a, b) => {
    if (a.isComplete !== b.isComplete) return a.isComplete ? 1 : -1;
    return a.address.localeCompare(b.address);
  });

  return groups;
}

function haversineMetersAdmin(
  a: { lat: number; lng: number },
  b: { lat: number; lng: number }
): number {
  const R = 6371000;
  const toRad = (deg: number) => (deg * Math.PI) / 180;
  const dLat = toRad(b.lat - a.lat);
  const dLng = toRad(b.lng - a.lng);
  const lat1 = toRad(a.lat);
  const lat2 = toRad(b.lat);
  const x =
    Math.sin(dLat / 2) ** 2 + Math.sin(dLng / 2) ** 2 * Math.cos(lat1) * Math.cos(lat2);
  return 2 * R * Math.asin(Math.sqrt(x));
}

// === Sub-components ===

function ListPanel({
  search,
  onSearchChange,
  entrances,
  completedIds,
  verifyStats,
  onlyComplaints,
  onToggleOnlyComplaints,
  onSelectEntrance,
  onSelectGroup,
}: {
  search: string;
  onSearchChange: (s: string) => void;
  entrances: Entrance[];
  completedIds: Set<string>;
  verifyStats: Map<string, VerificationStat>;
  onlyComplaints: boolean;
  onToggleOnlyComplaints: () => void;
  onSelectEntrance: (e: Entrance) => void;
  onSelectGroup: (e: Entrance) => void;
}) {
  const groups = useMemo(() => groupEntrances(entrances, completedIds), [entrances, completedIds]);
  const [expandedKeys, setExpandedKeys] = useState<Set<string>>(new Set());

  const visibleGroups = useMemo(() => {
    let result = groups;

    // Фильтр "только проблемные"
    if (onlyComplaints) {
      result = result
        .map((g) => ({
          ...g,
          entrances: g.entrances.filter((e) => {
            const stat = verifyStats.get(e.id);
            return stat && stat.incorrect_count >= VERIFICATION_BAD_THRESHOLD;
          }),
        }))
        .filter((g) => g.entrances.length > 0);
    }

    // Текстовый поиск
    if (search) {
      const q = search.toLowerCase();
      result = result
        .map((g) => ({
          ...g,
          entrances: g.entrances.filter(
            (e) =>
              (e.entrance_number ?? '').toLowerCase().includes(q) ||
              g.address.toLowerCase().includes(q)
          ),
        }))
        .filter((g) => g.entrances.length > 0 || g.address.toLowerCase().includes(q));
    }

    return result;
  }, [groups, search, onlyComplaints, verifyStats]);

  const totalEntrances = entrances.length;
  const completedHouses = groups.filter((g) => g.isComplete).length;

  const toggle = (key: string) => {
    setExpandedKeys((prev) => {
      const next = new Set(prev);
      if (next.has(key)) next.delete(key);
      else next.add(key);
      return next;
    });
  };

  const handleGroupClick = (group: Group) => {
    toggle(group.key);
    if (group.entrances.length > 0) onSelectGroup(group.entrances[0]);
  };

  return (
    <>
      <div className="p-4 border-b border-slate-200">
        <div className="relative">
          <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            placeholder="Поиск по адресу или подъезду..."
            value={search}
            onChange={(e) => onSearchChange(e.target.value)}
            className="w-full pl-9 pr-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-sm focus:outline-none focus:border-teal-500 transition"
          />
        </div>

        <button
          type="button"
          onClick={onToggleOnlyComplaints}
          className={`w-full mt-2 px-3 py-2 rounded-lg text-sm font-medium flex items-center justify-center gap-2 transition ${
            onlyComplaints
              ? 'bg-orange-500 text-white hover:bg-orange-600'
              : 'bg-slate-50 text-slate-700 hover:bg-slate-100 border border-slate-200'
          }`}
        >
          ⚠ {onlyComplaints ? 'Показать все' : 'Только проблемные'}
        </button>

        <div className="text-xs text-slate-400 mt-3">
          Домов: {groups.length} (готовых:{' '}
          <span className="text-emerald-600 font-medium">{completedHouses}</span>) ·
          Подъездов: {totalEntrances}
        </div>
        <div className="text-xs text-slate-400 mt-1">
          Клик по карте — добавить новый подъезд.
        </div>
      </div>

      <div className="flex-1 overflow-y-auto">
        {visibleGroups.length === 0 ? (
          <div className="p-8 text-center text-slate-400 text-sm">
            {search ? 'Ничего не найдено' : 'Пока нет подъездов.'}
          </div>
        ) : (
          visibleGroups.map((group) => {
            const isExpanded = expandedKeys.has(group.key) || !!search;
            return (
              <div key={group.key} className="border-b border-slate-100">
                <button
                  onClick={() => handleGroupClick(group)}
                  className="w-full text-left p-3 hover:bg-slate-50 transition flex gap-3 items-center"
                >
                  {group.isComplete ? (
                    <CheckCircle2 size={18} className="text-emerald-500 flex-shrink-0" />
                  ) : (
                    <Circle size={18} className="text-slate-300 flex-shrink-0" />
                  )}
                  <div className="flex-1 min-w-0">
                    <div
                      className="font-medium text-sm text-slate-800 truncate"
                      title={group.allAddresses.length > 1 ? group.allAddresses.join(' · ') : undefined}
                    >
                      {group.address}
                    </div>
                    <div className="text-xs text-slate-500">
                      {pluralEntrances(group.entrances.length)}
                      {group.facadeCount > 1 && (
                        <span className="text-slate-400"> · {group.facadeCount} фасада</span>
                      )}
                      {group.hasUnattached && (
                        <span className="text-amber-600"> · ⚠ есть несвязанные</span>
                      )}
                      <GroupComplaintBadge group={group} verifyStats={verifyStats} />
                    </div>
                  </div>
                  {isExpanded ? (
                    <ChevronDown size={16} className="text-slate-400 flex-shrink-0" />
                  ) : (
                    <ChevronRight size={16} className="text-slate-400 flex-shrink-0" />
                  )}
                </button>

                {isExpanded && (
                  <div className="bg-slate-50/60">
                    {group.entrances.map((entrance) => (
                      <button
                        key={entrance.id}
                        onClick={(e) => {
                          e.stopPropagation();
                          onSelectEntrance(entrance);
                        }}
                        className="w-full text-left pl-11 pr-3 py-2 hover:bg-slate-100 transition flex gap-2 items-center text-sm border-t border-slate-100"
                      >
                        <MapPin size={14} className="text-teal-600 flex-shrink-0" />
                        <span className="text-slate-700">
                          Подъезд {entrance.entrance_number ?? '—'}
                        </span>
                        <ComplaintBadge stat={verifyStats.get(entrance.id)} />
                        {formatRange(entrance) && (
                          <span className="text-xs text-slate-500 ml-auto">
                            {formatRange(entrance)}
                          </span>
                        )}
                      </button>
                    ))}
                  </div>
                )}
              </div>
            );
          })
        )}
      </div>
    </>
  );
}

function MobileListPanel({
  search,
  onSearchChange,
  entrances,
  completedIds,
  verifyStats,
  onlyComplaints,
  onToggleOnlyComplaints,
  onSelectEntrance,
  onSelectGroup,
  onClose,
}: {
  search: string;
  onSearchChange: (s: string) => void;
  entrances: Entrance[];
  completedIds: Set<string>;
  verifyStats: Map<string, VerificationStat>;
  onlyComplaints: boolean;
  onToggleOnlyComplaints: () => void;
  onSelectEntrance: (e: Entrance) => void;
  onSelectGroup: (e: Entrance) => void;
  onClose: () => void;
}) {
  const groups = useMemo(() => groupEntrances(entrances, completedIds), [entrances, completedIds]);

  const visibleGroups = useMemo(() => {
    let result = groups;

    if (onlyComplaints) {
      result = result
        .map((g) => ({
          ...g,
          entrances: g.entrances.filter((e) => {
            const stat = verifyStats.get(e.id);
            return stat && stat.incorrect_count >= VERIFICATION_BAD_THRESHOLD;
          }),
        }))
        .filter((g) => g.entrances.length > 0);
    }

    if (search) {
      const q = search.toLowerCase();
      result = result
        .map((g) => ({
          ...g,
          entrances: g.entrances.filter(
            (e) =>
              (e.entrance_number ?? '').toLowerCase().includes(q) ||
              g.address.toLowerCase().includes(q)
          ),
        }))
        .filter((g) => g.entrances.length > 0 || g.address.toLowerCase().includes(q));
    }

    return result;
  }, [groups, search, onlyComplaints, verifyStats]);

  const [expandedKey, setExpandedKey] = useState<string | null>(null);

  return (
    <>
      <div className="p-3 border-b border-slate-200 flex items-center gap-2">
        <button
          onClick={onClose}
          className="w-9 h-9 flex items-center justify-center rounded-lg hover:bg-slate-100"
        >
          <ChevronLeft size={20} className="text-slate-600" />
        </button>
        <div className="font-semibold text-slate-800">Все подъезды</div>
      </div>

      <div className="p-3 border-b border-slate-100">
        <div className="relative">
          <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            placeholder="Поиск..."
            value={search}
            onChange={(e) => onSearchChange(e.target.value)}
            className="w-full pl-9 pr-3 py-2.5 bg-slate-50 border border-slate-200 rounded-full text-sm focus:outline-none focus:border-teal-500"
          />
        </div>
        <button
          type="button"
          onClick={onToggleOnlyComplaints}
          className={`w-full mt-2 px-3 py-2.5 rounded-full text-sm font-medium flex items-center justify-center gap-2 transition ${
            onlyComplaints
              ? 'bg-orange-500 text-white'
              : 'bg-slate-50 text-slate-700 border border-slate-200'
          }`}
        >
          ⚠ {onlyComplaints ? 'Показать все' : 'Только проблемные'}
        </button>
      </div>

      <div className="flex-1 overflow-y-auto">
        {visibleGroups.length === 0 ? (
          <div className="p-8 text-center text-slate-400 text-sm">
            {search ? 'Ничего не найдено' : 'Пока пусто'}
          </div>
        ) : (
          visibleGroups.map((group) => {
            const isExpanded = expandedKey === group.key || !!search;
            return (
              <div key={group.key} className="border-b border-slate-100">
                <button
                  onClick={() => {
                    setExpandedKey(isExpanded ? null : group.key);
                    if (group.entrances.length > 0) onSelectGroup(group.entrances[0]);
                  }}
                  className="w-full text-left p-4 active:bg-slate-100 flex gap-3 items-center"
                >
                  {group.isComplete ? (
                    <CheckCircle2 size={18} className="text-emerald-500 flex-shrink-0" />
                  ) : (
                    <Circle size={18} className="text-slate-300 flex-shrink-0" />
                  )}
                  <div className="flex-1 min-w-0">
                    <div className="font-medium text-sm text-slate-800 truncate">
                      {group.address}
                    </div>
                    <div className="text-xs text-slate-500">
                      {pluralEntrances(group.entrances.length)}
                      {group.facadeCount > 1 && (
                        <span className="text-slate-400"> · {group.facadeCount} фасада</span>
                      )}
                      {group.isComplete && ' · готов'}
                      {group.hasUnattached && (
                        <span className="text-amber-600"> · ⚠</span>
                      )}
                    </div>
                  </div>
                  {isExpanded ? (
                    <ChevronDown size={16} className="text-slate-400 flex-shrink-0" />
                  ) : (
                    <ChevronRight size={16} className="text-slate-400 flex-shrink-0" />
                  )}
                </button>

                {isExpanded && (
                  <div className="bg-slate-50/60">
                    {group.entrances.map((entrance) => (
                      <button
                        key={entrance.id}
                        onClick={(e) => {
                          e.stopPropagation();
                          onSelectEntrance(entrance);
                        }}
                        className="w-full text-left pl-12 pr-4 py-3 active:bg-slate-100 flex gap-2 items-center text-sm border-t border-slate-100"
                      >
                        <MapPin size={14} className="text-teal-600 flex-shrink-0" />
                        <span className="text-slate-700">
                          Подъезд {entrance.entrance_number ?? '—'}
                        </span>
                        <ComplaintBadge stat={verifyStats.get(entrance.id)} />
                        {formatRange(entrance) && (
                          <span className="text-xs text-slate-500 ml-auto">
                            {formatRange(entrance)}
                          </span>
                        )}
                      </button>
                    ))}
                  </div>
                )}
              </div>
            );
          })
        )}
      </div>
    </>
  );
}

function FormPanel({
  title,
  initial,
  coords,
  buildingStatus,
  isBuildingComplete,
  onToggleComplete,
  onAttachBuilding,
  onSave,
  onCancel,
  onDelete,
  compact,
  approaches,
  entranceId,
  onAddApproach,
  onDeleteApproach,
}: {
  title: string;
  initial: FormValues;
  coords: { lat: number; lng: number };
  buildingStatus: 'detected' | 'not_found';
  isBuildingComplete?: boolean;
  onToggleComplete?: () => void;
  onAttachBuilding?: () => void;
  onSave: (input: FormValues) => void;
  onCancel: () => void;
  onDelete?: () => void;
  compact?: boolean;
  approaches: Approach[];
  entranceId: string | null;
  onAddApproach: (orderIndex: number) => void;
  onDeleteApproach: (approachId: string) => void;
}) {
  const [number, setNumber] = useState(initial.number);
  const [korpus, setKorpus] = useState(initial.korpus);
  const [address, setAddress] = useState(initial.address ?? '');
  const [ranges, setRanges] = useState(initial.ranges);
  const [saving, setSaving] = useState(false);

  const MAX_RANGES = 6;

  const updateRange = (idx: number, field: 'from' | 'to', value: string) => {
    setRanges((prev) =>
      prev.map((r, i) => (i === idx ? { ...r, [field]: value } : r))
    );
  };

  const addRange = () => {
    if (ranges.length >= MAX_RANGES) return;
    setRanges((prev) => [...prev, { from: '', to: '' }]);
  };

  const removeRange = (idx: number) => {
    if (ranges.length === 1) {
      // Не удаляем последний, просто очищаем значения
      setRanges([{ from: '', to: '' }]);
      return;
    }
    setRanges((prev) => prev.filter((_, i) => i !== idx));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!number.trim()) {
      alert('Введи номер подъезда');
      return;
    }

    // Валидация диапазонов

    for (let i = 0; i < ranges.length; i++) {
      const r = ranges[i];
      if (!r.from && !r.to) continue; // пустой ряд — пропускаем
      const from = parseInt(r.from);
      const to = parseInt(r.to);
      if (!from || !to || isNaN(from) || isNaN(to)) {
        alert(`Диапазон ${i + 1}: укажите оба числа от/до`);
        return;
      }
      if (from > to) {
        alert(`Диапазон ${i + 1}: число "от" должно быть меньше или равно "до"`);
        return;
      }
    }
    setSaving(true);
    await onSave({
      number: number.trim(),
      korpus: korpus.trim(),
      address: address.trim(),
      ranges,
    });
    setSaving(false);
  };

  return (
    <form onSubmit={handleSubmit} className="flex flex-col h-full overflow-y-auto">
      <div className="p-4 border-b border-slate-200 flex items-center justify-between sticky top-0 bg-white z-10">
        <h2 className="font-semibold text-slate-800">{title}</h2>
        <button
          type="button"
          onClick={onCancel}
          className="w-8 h-8 flex items-center justify-center rounded-lg hover:bg-slate-100 text-slate-500"
        >
          <X size={18} />
        </button>
      </div>

      <div className="p-4 space-y-3">
        <div>
          <span className="block text-xs font-medium text-slate-600 mb-1.5">
            Адрес
            <span className="text-slate-400 font-normal ml-1">— можно отредактировать</span>
          </span>
          <input
            type="text"
            value={address}
            onChange={(e) => setAddress(e.target.value)}
            placeholder="ul. Marszałkowska 20"
            className="w-full px-3 py-2.5 bg-white border border-slate-200 rounded-lg text-sm focus:outline-none focus:border-teal-500 transition"
          />
        </div>

        <div>
          <span className="block text-xs font-medium text-slate-600 mb-1.5">Номер подъезда *</span>
          <input
            type="text"
            value={number}
            onChange={(e) => setNumber(e.target.value)}
            placeholder="A"
            required
            className="w-full px-3 py-3 bg-white border border-slate-200 rounded-lg text-base focus:outline-none focus:border-teal-500"
          />
        </div>

        <div>
          <span className="block text-xs font-medium text-slate-600 mb-1.5">
            Диапазоны квартир
            <span className="text-slate-400 font-normal ml-1">— до 6 шт.</span>
          </span>
          <div className="space-y-2">
            {ranges.map((r, idx) => (
              <div key={idx} className="flex items-center gap-2">
                <span className="text-xs text-slate-400 w-4 text-center">{idx + 1}</span>
                <input
                  type="number"
                  min="1"
                  value={r.from}
                  onChange={(e) => updateRange(idx, 'from', e.target.value)}
                  placeholder="101"
                  className="flex-1 px-3 py-2.5 bg-white border border-slate-200 rounded-lg text-sm focus:outline-none focus:border-teal-500"
                />
                <span className="text-slate-400">—</span>
                <input
                  type="number"
                  min="1"
                  value={r.to}
                  onChange={(e) => updateRange(idx, 'to', e.target.value)}
                  placeholder="103"
                  className="flex-1 px-3 py-2.5 bg-white border border-slate-200 rounded-lg text-sm focus:outline-none focus:border-teal-500"
                />
                <button
                  type="button"
                  onClick={() => removeRange(idx)}
                  className="w-8 h-8 flex items-center justify-center rounded text-red-500 hover:bg-red-50 flex-shrink-0"
                  title="Удалить диапазон"
                >
                  <X size={16} />
                </button>
              </div>
            ))}
          </div>
          {ranges.length < MAX_RANGES && (
            <button
              type="button"
              onClick={addRange}
              className="w-full mt-2 px-3 py-2 border-2 border-dashed border-slate-300 hover:border-teal-400 rounded-lg text-sm text-slate-600 hover:text-teal-700 flex items-center justify-center gap-2"
            >
              <Plus size={14} />
              Добавить диапазон
            </button>
          )}
          <p className="text-xs text-slate-400 mt-2 leading-relaxed">
            Например: 101-103, 201-203, 301-303 (по этажам).
          </p>
        </div>

        <div>
          <span className="block text-xs font-medium text-slate-600 mb-1.5">
            Корпус (klatka)
            <span className="text-slate-400 font-normal ml-1">— опционально</span>
          </span>
          <input
            type="text"
            value={korpus}
            onChange={(e) => setKorpus(e.target.value)}
            placeholder="A, B, C..."
            maxLength={5}
            className="w-full px-3 py-3 bg-white border border-slate-200 rounded-lg text-base focus:outline-none focus:border-teal-500"
          />
          <p className="text-xs text-slate-400 mt-1 leading-relaxed">
            Заполнить если в комплексе несколько корпусов с одинаковым адресом
            (например ul. Marszałkowska 181 — корпуса A, B, C...).
          </p>
        </div>

        {/* === Точки подхода === */}
        <div className="pt-1">
          <span className="block text-xs font-medium text-slate-600 mb-1.5">
            Точки подхода
          </span>

          {!entranceId ? (
            <div className="text-xs text-slate-500 bg-slate-50 border border-slate-200 rounded-lg px-3 py-2">
              Сохраните подъезд, чтобы добавить точки подхода.
            </div>
          ) : (
            <>
              <div className="space-y-2">
                {[1, 2, 3].map((idx) => {
                  const ap = approaches.find((a) => a.order_index === idx);
                  if (ap) {
                    return (
                      <div
                        key={idx}
                        className="flex items-center gap-2 px-3 py-2 bg-teal-50 border border-teal-200 rounded-lg"
                      >
                        <div className="w-6 h-6 bg-teal-600 text-white rounded-full text-xs font-bold flex items-center justify-center flex-shrink-0">
                          {idx}
                        </div>
                        <span className="flex-1 text-sm text-teal-800 truncate">
                          Перетащите на карте
                        </span>
                        <button
                          type="button"
                          onClick={() => onDeleteApproach(ap.id)}
                          className="w-7 h-7 flex items-center justify-center rounded text-red-500 hover:bg-red-50 flex-shrink-0"
                          title="Удалить точку"
                        >
                          <X size={16} />
                        </button>
                      </div>
                    );
                  }
                  return (
                    <button
                      key={idx}
                      type="button"
                      onClick={() => onAddApproach(idx)}
                      className="w-full flex items-center gap-2 px-3 py-2 border-2 border-dashed border-slate-300 hover:border-teal-400 rounded-lg text-sm text-slate-600 hover:text-teal-700 transition"
                    >
                      <Plus size={14} />
                      Добавить точку {idx}
                    </button>
                  );
                })}
              </div>
              <p className="text-xs text-slate-400 mt-2 leading-relaxed">
                Маршрут пойдёт от точки 1 → 2 → 3 → к двери. Можно ставить 1–3 точки.
              </p>
            </>
          )}
        </div>

        {onToggleComplete && (
          <div className="pt-2">
            {buildingStatus === 'detected' ? (
              <button
                type="button"
                onClick={onToggleComplete}
                disabled={saving}
                className={`w-full px-3 py-2.5 text-sm font-medium rounded-lg flex items-center justify-center gap-2 disabled:opacity-50 ${
                  isBuildingComplete
                    ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                    : 'bg-slate-50 text-slate-700 border border-slate-200'
                }`}
              >
                {isBuildingComplete ? (
                  <>
                    <CheckCircle2 size={16} />
                    Помечен как готовый
                  </>
                ) : (
                  <>
                    <Circle size={16} />
                    Пометить дом готовым
                  </>
                )}
              </button>
            ) : (
              <div className="space-y-2">
                <div className="text-xs text-amber-700 bg-amber-50 border border-amber-200 rounded-lg px-3 py-2">
                  ⚠ Подъезд не привязан к зданию. Группировка по адресу.
                </div>
                {onAttachBuilding && (
                  <button
                    type="button"
                    onClick={onAttachBuilding}
                    className="w-full px-3 py-2.5 text-sm font-medium rounded-lg bg-amber-100 hover:bg-amber-200 text-amber-800 border border-amber-300"
                  >
                    🔍 Привязать к ближайшему дому
                  </button>
                )}
              </div>
            )}
          </div>
        )}

        {!compact && (
          <div className="text-xs text-slate-400">
            Координаты: {coords.lat.toFixed(5)}, {coords.lng.toFixed(5)}
          </div>
        )}
      </div>

      <div className="p-4 border-t border-slate-200 flex gap-2">
        <button
          type="submit"
          disabled={saving}
          className="flex-1 px-4 py-3 bg-teal-600 hover:bg-teal-700 disabled:opacity-50 text-white text-sm font-medium rounded-lg flex items-center justify-center gap-2"
        >
          <Save size={16} />
          {saving ? 'Сохранение...' : 'Сохранить'}
        </button>
        {onDelete && (
          <button
            type="button"
            onClick={onDelete}
            disabled={saving}
            className="px-4 py-3 bg-red-50 hover:bg-red-100 text-red-600 rounded-lg"
            title="Удалить"
          >
            <Trash2 size={16} />
          </button>
        )}
      </div>
    </form>
  );
}
// === Бейдж жалоб ===

function ComplaintBadge({ stat }: { stat?: VerificationStat }) {
  if (!stat) return null;
  if (stat.incorrect_count < VERIFICATION_BAD_THRESHOLD) return null;
  return (
    <span
      className="ml-1 inline-flex items-center gap-1 px-1.5 py-0.5 rounded text-[10px] font-semibold bg-orange-100 text-orange-700 border border-orange-200"
      title={`${stat.incorrect_count} жалоб «не верно», ${stat.correct_count} «верно»`}
    >
      ⚠ {stat.incorrect_count}
    </span>
  );
}

function GroupComplaintBadge({
  group,
  verifyStats,
}: {
  group: Group;
  verifyStats: Map<string, VerificationStat>;
}) {
  let totalBad = 0;
  for (const e of group.entrances) {
    const stat = verifyStats.get(e.id);
    if (stat && stat.incorrect_count >= VERIFICATION_BAD_THRESHOLD) {
      totalBad += stat.incorrect_count;
    }
  }
  if (totalBad === 0) return null;
  return (
    <span className="text-orange-600"> · ⚠ {totalBad} жалоб</span>
  );
}