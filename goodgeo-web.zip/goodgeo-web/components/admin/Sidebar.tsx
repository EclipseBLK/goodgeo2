'use client';

import Link from 'next/link';
import Image from 'next/image';
import { usePathname } from 'next/navigation';
import { LayoutDashboard, MapPin, Users, CreditCard, BarChart3, Inbox } from 'lucide-react';

const NAV = [
  { href: '/admin', label: 'Дашборд', icon: LayoutDashboard, exact: true },
  { href: '/admin/entrances', label: 'Подъезды', icon: MapPin },
  { href: '/admin/suggestions', label: 'Предложения', icon: Inbox },
  { href: '/admin/users', label: 'Пользователи', icon: Users },
  { href: '/admin/subscriptions', label: 'Подписки', icon: CreditCard },
  { href: '/admin/analytics', label: 'Аналитика', icon: BarChart3 },
];

export default function Sidebar() {
  const pathname = usePathname();

  return (
    <aside className="hidden md:flex flex-col w-60 bg-white border-r border-slate-200 fixed inset-y-0 left-0">
      {/* Logo */}
      <div className="h-16 flex items-center gap-2 px-5 border-b border-slate-200">
        <Image src="/logo.png" alt="GoodGeo" width={32} height={32} />
        <span className="font-bold text-slate-800">GoodGeo</span>
        <span className="text-xs px-2 py-0.5 bg-teal-50 text-teal-700 rounded-md font-medium">
          Admin
        </span>
      </div>

      {/* Navigation */}
      <nav className="flex-1 px-3 py-4 space-y-1">
        {NAV.map((item) => {
          const active = item.exact
            ? pathname === item.href
            : pathname.startsWith(item.href);
          const Icon = item.icon;

          return (
            <Link
              key={item.href}
              href={item.href}
              className={`flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition ${
                active
                  ? 'bg-teal-50 text-teal-700'
                  : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900'
              }`}
            >
              <Icon size={18} />
              <span>{item.label}</span>
            </Link>
          );
        })}
      </nav>

      {/* Footer */}
      <div className="px-5 py-4 border-t border-slate-200 text-xs text-slate-400">
        v1.0.0
      </div>
    </aside>
  );
}