import { createClient } from '@/lib/supabase/server';
import { LogOut } from 'lucide-react';

export default async function Topbar() {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();

  let name = 'Админ';
  if (user) {
    const { data: profile } = await supabase
      .from('profiles')
      .select('email, name')
      .eq('id', user.id)
      .single();
    name = profile?.name || profile?.email || 'Админ';
  }

  return (
    <header className="h-16 bg-white border-b border-slate-200 flex items-center justify-between px-6 sticky top-0 z-30">
      <div className="text-slate-800 font-semibold">Панель управления</div>

      <div className="flex items-center gap-3">
        <div className="text-right hidden sm:block">
          <div className="text-sm font-medium text-slate-800">{name}</div>
          <div className="text-xs text-slate-400">Администратор</div>
        </div>
        <div className="w-9 h-9 rounded-full bg-teal-100 text-teal-700 flex items-center justify-center font-semibold uppercase">
          {name[0] ?? '?'}
        </div>
        <form action="/admin/logout" method="post">
          <button
            type="submit"
            title="Выйти"
            className="w-9 h-9 flex items-center justify-center rounded-lg text-slate-500 hover:bg-red-50 hover:text-red-600 transition"
          >
            <LogOut size={18} />
          </button>
        </form>
      </div>
    </header>
  );
}