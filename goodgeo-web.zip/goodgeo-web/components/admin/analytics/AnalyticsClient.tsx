'use client';

import { Calendar, Users, AlertTriangle, CreditCard, Activity } from 'lucide-react';
import type {
  RegistrationStats,
  PaymentStats,
  DuplicateDeviceAlert,
  HeatmapPoint,
  ActivityStats,
} from '@/lib/admin/analytics';
import HeatmapMap from './HeatmapMap';

export default function AnalyticsClient({
  registrations,
  payments,
  alerts,
  heatmapPoints,
  activity,
}: {
  registrations: RegistrationStats;
  payments: PaymentStats;
  alerts: DuplicateDeviceAlert[];
  heatmapPoints: HeatmapPoint[];
  activity: ActivityStats;
}) {
  return (
    <div className="space-y-8">
      {/* === Регистрации === */}
      <Section title="Регистрации" icon={<Calendar size={16} />}>
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          <RegCard label="За 24 часа" value={registrations.day1} accent="blue" />
          <RegCard label="За 7 дней" value={registrations.day7} accent="teal" />
          <RegCard label="За 30 дней" value={registrations.day30} accent="amber" />
          <RegCard label="За 365 дней" value={registrations.day365} accent="purple" />
        </div>
      </Section>

      {/* === Активность === */}
      <Section title="Активность" icon={<Activity size={16} />}>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          <RegCard label="Онлайн сейчас" value={activity.activeNow} accent="teal" />
          <RegCard label="Активных за 24 часа" value={activity.active24h} accent="blue" />
        </div>
      </Section>
      
      {/* === Платные / Бесплатные === */}
      <Section title="Подписки" icon={<CreditCard size={16} />}>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 mb-4">
          <PaymentCard
            label="Платные"
            value={payments.paid}
            percent={payments.paidPercent}
            color="bg-teal-500"
            textColor="text-teal-700"
            bg="bg-teal-50"
          />
          <PaymentCard
            label="Бесплатные"
            value={payments.free}
            percent={payments.freePercent}
            color="bg-slate-400"
            textColor="text-slate-700"
            bg="bg-slate-50"
          />
        </div>

        {/* Stacked bar */}
        {payments.total > 0 && (
          <div className="bg-white border border-slate-200 rounded-2xl p-4">
            <div className="flex h-8 rounded-lg overflow-hidden">
              <div
                className="bg-teal-500 flex items-center justify-center text-white text-xs font-medium transition-all"
                style={{ width: `${payments.paidPercent}%` }}
              >
                {payments.paidPercent > 5 && `${payments.paidPercent}%`}
              </div>
              <div
                className="bg-slate-300 flex items-center justify-center text-slate-700 text-xs font-medium transition-all"
                style={{ width: `${payments.freePercent}%` }}
              >
                {payments.freePercent > 5 && `${payments.freePercent}%`}
              </div>
            </div>
            <div className="flex justify-between mt-2 text-xs text-slate-500">
              <span>Всего: {payments.total} пользователей</span>
              <span>
                {payments.paid} платных · {payments.free} бесплатных
              </span>
            </div>
          </div>
        )}
      </Section>

      {/* === Алерты о повторных регистрациях === */}
      <Section
        title={`Подозрительные регистрации (${alerts.length})`}
        icon={<AlertTriangle size={16} />}
      >
        <div className="bg-white border border-slate-200 rounded-2xl overflow-hidden">
          {alerts.length === 0 ? (
            <div className="p-8 text-center text-slate-400 text-sm">
              ✓ Нет попыток повторной регистрации с одного устройства
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="bg-amber-50 text-amber-800 text-xs uppercase">
                  <tr>
                    <th className="text-left px-5 py-3 font-medium">Подозрительный аккаунт</th>
                    <th className="text-left px-5 py-3 font-medium">Первичный аккаунт</th>
                    <th className="text-right px-5 py-3 font-medium">Когда</th>
                  </tr>
                </thead>
                <tbody>
                  {alerts.map((alert) => (
                    <tr
                      key={alert.suspicious_id}
                      className="border-t border-slate-100 hover:bg-slate-50/60"
                    >
                      <td className="px-5 py-3">
                        <div className="font-medium text-slate-800 flex items-center gap-2">
                          <AlertTriangle size={14} className="text-amber-500" />
                          {alert.suspicious_email}
                        </div>
                      </td>
                      <td className="px-5 py-3 text-slate-600">
                        {alert.primary_email ?? <span className="text-slate-400">—</span>}
                      </td>
                      <td className="px-5 py-3 text-right text-slate-500 text-xs">
                        {formatRelative(alert.suspicious_created_at)}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </Section>

      {/* === Heatmap === */}
      <Section
        title={`Тепловая карта (${heatmapPoints.length} помеченных подъездов)`}
        icon={<Users size={16} />}
      >
        <div className="bg-white border border-slate-200 rounded-2xl overflow-hidden">
          <HeatmapMap points={heatmapPoints} />
        </div>
        <p className="text-xs text-slate-400 mt-2">
          Чем «теплее» (красный) — тем больше готовых домов в этом районе. Камера ограничена границами Варшавы.
        </p>
      </Section>
    </div>
  );
}

function Section({
  title,
  icon,
  children,
}: {
  title: string;
  icon: React.ReactNode;
  children: React.ReactNode;
}) {
  return (
    <div>
      <h2 className="text-sm font-semibold text-slate-500 uppercase mb-3 flex items-center gap-2">
        {icon}
        {title}
      </h2>
      {children}
    </div>
  );
}

function RegCard({
  label,
  value,
  accent,
}: {
  label: string;
  value: number;
  accent: 'blue' | 'teal' | 'amber' | 'purple';
}) {
  const colors = {
    blue: 'text-blue-600 bg-blue-50',
    teal: 'text-teal-600 bg-teal-50',
    amber: 'text-amber-600 bg-amber-50',
    purple: 'text-purple-600 bg-purple-50',
  };
  return (
    <div className="bg-white border border-slate-200 rounded-2xl p-4">
      <div className={`inline-block px-2 py-1 rounded-md text-xs font-medium ${colors[accent]}`}>
        {label}
      </div>
      <div className="text-3xl font-bold text-slate-800 mt-2">{value}</div>
    </div>
  );
}

function PaymentCard({
  label,
  value,
  percent,
  color,
  textColor,
  bg,
}: {
  label: string;
  value: number;
  percent: number;
  color: string;
  textColor: string;
  bg: string;
}) {
  return (
    <div className={`border border-slate-200 rounded-2xl p-4 ${bg}`}>
      <div className="flex items-center justify-between">
        <div>
          <div className={`text-xs font-medium ${textColor}`}>{label}</div>
          <div className="text-3xl font-bold text-slate-800 mt-1">{value}</div>
        </div>
        <div className={`text-2xl font-bold ${textColor}`}>{percent}%</div>
      </div>
      <div className="mt-3 h-1.5 bg-white rounded-full overflow-hidden">
        <div className={`h-full ${color}`} style={{ width: `${percent}%` }} />
      </div>
    </div>
  );
}

function formatRelative(iso: string): string {
  const d = new Date(iso);
  const now = new Date();
  const diffMs = now.getTime() - d.getTime();
  const diffMin = Math.floor(diffMs / 60000);
  const diffH = Math.floor(diffMs / 3600000);
  const diffD = Math.floor(diffMs / 86400000);

  if (diffMin < 1) return 'только что';
  if (diffMin < 60) return `${diffMin} мин назад`;
  if (diffH < 24) return `${diffH} ч назад`;
  if (diffD < 7) return `${diffD} д назад`;
  return d.toLocaleDateString('ru-RU', { day: '2-digit', month: 'short' });
}