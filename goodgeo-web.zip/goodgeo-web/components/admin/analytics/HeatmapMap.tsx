'use client';

import { useEffect, useRef } from 'react';
import mapboxgl from 'mapbox-gl';
import 'mapbox-gl/dist/mapbox-gl.css';
import type { HeatmapPoint } from '@/lib/admin/analytics';

mapboxgl.accessToken = process.env.NEXT_PUBLIC_MAPBOX_TOKEN!;

// Bbox Варшавы (юго-западная и северо-восточная точки)
const WARSAW_BOUNDS: [[number, number], [number, number]] = [
  [20.85, 52.10], // SW
  [21.27, 52.37], // NE
];

const WARSAW_CENTER: [number, number] = [21.0122, 52.2297];

export default function HeatmapMap({ points }: { points: HeatmapPoint[] }) {
  const mapContainer = useRef<HTMLDivElement>(null);
  const map = useRef<mapboxgl.Map | null>(null);

  useEffect(() => {
    if (!mapContainer.current || map.current) return;

    map.current = new mapboxgl.Map({
      container: mapContainer.current,
      style: 'mapbox://styles/mapbox/light-v11',
      center: WARSAW_CENTER,
      zoom: 10,
      maxBounds: WARSAW_BOUNDS,
    });

    map.current.addControl(new mapboxgl.NavigationControl({ showCompass: false }), 'top-right');

    map.current.on('load', () => {
      if (!map.current) return;

      map.current.addSource('heatmap-source', {
        type: 'geojson',
        data: {
          type: 'FeatureCollection',
          features: points.map((p) => ({
            type: 'Feature',
            geometry: { type: 'Point', coordinates: p },
            properties: {},
          })),
        },
      });

      map.current.addLayer({
        id: 'heatmap-layer',
        type: 'heatmap',
        source: 'heatmap-source',
        paint: {
          'heatmap-weight': 1,
          'heatmap-intensity': [
            'interpolate', ['linear'], ['zoom'],
            10, 1,
            15, 3,
          ],
          'heatmap-color': [
            'interpolate', ['linear'], ['heatmap-density'],
            0, 'rgba(16, 185, 129, 0)',
            0.2, 'rgba(16, 185, 129, 0.4)',
            0.4, 'rgba(250, 204, 21, 0.6)',
            0.6, 'rgba(249, 115, 22, 0.7)',
            0.8, 'rgba(239, 68, 68, 0.8)',
            1, 'rgba(220, 38, 38, 0.9)',
          ],
          'heatmap-radius': [
            'interpolate', ['linear'], ['zoom'],
            10, 8,
            15, 30,
            18, 60,
          ],
          'heatmap-opacity': [
            'interpolate', ['linear'], ['zoom'],
            10, 0.8,
            17, 0.5,
          ],
        },
      });

      // На большом zoom показываем точки поверх heatmap
      map.current.addLayer({
        id: 'heatmap-points',
        type: 'circle',
        source: 'heatmap-source',
        minzoom: 15,
        paint: {
          'circle-radius': 4,
          'circle-color': '#10b981',
          'circle-stroke-color': '#059669',
          'circle-stroke-width': 1,
          'circle-opacity': [
            'interpolate', ['linear'], ['zoom'],
            14, 0,
            16, 1,
          ],
        },
      });
    });

    return () => {
      map.current?.remove();
      map.current = null;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Обновлять данные при изменении points
  useEffect(() => {
    if (!map.current) return;
    const source = map.current.getSource('heatmap-source') as mapboxgl.GeoJSONSource | undefined;
    if (!source) return;

    source.setData({
      type: 'FeatureCollection',
      features: points.map((p) => ({
        type: 'Feature',
        geometry: { type: 'Point', coordinates: p },
        properties: {},
      })),
    });
  }, [points]);

  return <div ref={mapContainer} className="h-[500px] w-full" />;
}