'use client';

import { useMemo, useState } from 'react';
import { Search, CreditCard, Lock } from 'lucide-react';
import type { User } from '@/lib/admin/types';

type StatusFilter = 'all' | 'active' | 'expired' | 'cancelled';

const FILTERS: { key: StatusFilter; label: string }[] = [
  { key: 'all', label: 'Все' },
  { key: 'active', label: 'Активные' },
  { key: 'expired', label: 'Истёкшие' },
  { key: 'cancelled', label: 'Отменённые' },
];

export default function SubscriptionsClient({
  initialSubscriptions,
}: {
  initialSubscriptions: User[];
}) {
  const [search, setSearch] = useState('');
  const [filter, setFilter] = useState<StatusFilter>('all');

  const counts = useMemo(() => {
    const result: Record<string, number> = { all: initialSubscriptions.length };
    for (const u of initialSubscriptions) {
      result[u.subscription_status] = (result[u.subscription_status] ?? 0) + 1;
    }
    return result;
  }, [initialSubscriptions]);

  const filtered = useMemo(() => {
    return initialSubscriptions.filter((u) => {
      if (filter !== 'all' && u.subscription_status !== filter) return false;

      if (search) {
        const q = search.toLowerCase();
        const matchEmail = u.email.toLowerCase().includes(q);
        const matchName = (u.name ?? '').toLowerCase().includes(q);
        if (!matchEmail && !matchName) return false;
      }

      return true;
    });
  }, [initialSubscriptions, filter, search]);

  return (
    <div className="space-y-4">
      {/* Filters */}
      <div className="flex flex-wrap gap-2">
        {FILTERS.map((f) => (
          <button
            key={f.key}
            onClick={() => setFilter(f.key)}
            className={`px-3 py-1.5 text-sm rounded-lg border transition ${
              filter === f.key
                ? 'bg-teal-600 text-white border-teal-600'
                : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
            }`}
          >
            {f.label}
            <span
              className={`ml-1.5 text-xs ${filter === f.key ? 'opacity-80' : 'text-slate-400'}`}
            >
              {counts[f.key] ?? 0}
            </span>
          </button>
        ))}
      </div>

      {/* Search */}
      <div className="relative max-w-md">
        <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
        <input
          type="text"
          placeholder="Поиск по email или имени..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="w-full pl-9 pr-3 py-2 bg-white border border-slate-200 rounded-lg text-sm focus:outline-none focus:border-teal-500"
        />
      </div>

      {/* Table */}
      <div className="bg-white border border-slate-200 rounded-2xl overflow-hidden">
        {filtered.length === 0 ? (
          <div className="p-12 text-center text-slate-400 text-sm">
            <CreditCard size={32} className="mx-auto mb-3 text-slate-300" />
            {search || filter !== 'all'
              ? 'Ничего не найдено'
              : 'Пока нет подписок. Когда юзеры начнут оплачивать (или ты активируешь вручную) — появятся здесь.'}
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-slate-50 text-slate-500 text-xs uppercase">
                <tr>
                  <th className="text-left px-5 py-3 font-medium">Пользователь</th>
                  <th className="text-left px-5 py-3 font-medium">Источник</th>
                  <th className="text-left px-5 py-3 font-medium">Статус</th>
                  <th className="text-left px-5 py-3 font-medium">Действует до</th>
                  <th className="text-left px-5 py-3 font-medium">ID транзакции</th>
                </tr>
              </thead>
              <tbody>
                {filtered.map((user) => (
                  <tr
                    key={user.id}
                    className="border-t border-slate-100 hover:bg-slate-50/60"
                  >
                    <td className="px-5 py-3">
                      <div className="flex items-center gap-2">
                        <div className="font-medium text-slate-800">{user.name ?? '—'}</div>
                        {user.is_blocked && (
                          <Lock size={14} className="text-red-600" aria-label="Blocked" />
                        )}
                      </div>
                      <div className="text-xs text-slate-400">{user.email}</div>
                    </td>
                    <td className="px-5 py-3">
                      <SourceBadge source={user.subscription_source} />
                    </td>
                    <td className="px-5 py-3">
                      <StatusBadge
                        status={user.subscription_status}
                        blocked={user.is_blocked}
                      />
                    </td>
                    <td className="px-5 py-3 text-slate-600 text-xs">
                      {user.subscription_ends_at ? (
                        <>
                          <div>{formatFull(user.subscription_ends_at)}</div>
                          <div className="text-slate-400">
                            {relativeFromNow(user.subscription_ends_at)}
                          </div>
                        </>
                      ) : (
                        '—'
                      )}
                    </td>
                    <td className="px-5 py-3 text-slate-500 text-xs font-mono">
                      {user.platform_transaction_id ? (
                        <span title={user.platform_transaction_id}>
                          {truncate(user.platform_transaction_id, 16)}
                        </span>
                      ) : (
                        <span className="text-slate-300">—</span>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}

function StatusBadge({ status, blocked }: { status: string; blocked: boolean }) {
  if (blocked) {
    return (
      <span className="inline-block px-2 py-1 rounded-md text-xs font-medium bg-red-50 text-red-700">
        Заблокирован
      </span>
    );
  }
  const styles: Record<string, string> = {
    trial: 'bg-amber-50 text-amber-700',
    active: 'bg-teal-50 text-teal-700',
    expired: 'bg-red-50 text-red-700',
    cancelled: 'bg-slate-100 text-slate-600',
  };
  const labels: Record<string, string> = {
    trial: 'Триал',
    active: 'Активна',
    expired: 'Истекла',
    cancelled: 'Отменена',
  };
  return (
    <span
      className={`inline-block px-2 py-1 rounded-md text-xs font-medium ${
        styles[status] ?? 'bg-slate-100 text-slate-600'
      }`}
    >
      {labels[status] ?? status}
    </span>
  );
}

function SourceBadge({ source }: { source: string }) {
  const styles: Record<string, string> = {
    manual: 'bg-purple-50 text-purple-700',
    google_play: 'bg-green-50 text-green-700',
    app_store: 'bg-blue-50 text-blue-700',
  };
  const labels: Record<string, string> = {
    manual: 'Вручную',
    google_play: 'Google Play',
    app_store: 'App Store',
  };
  return (
    <span
      className={`inline-block px-2 py-1 rounded-md text-xs font-medium ${
        styles[source] ?? 'bg-slate-100 text-slate-600'
      }`}
    >
      {labels[source] ?? source}
    </span>
  );
}

function formatFull(iso: string): string {
  return new Date(iso).toLocaleDateString('ru-RU', {
    day: '2-digit',
    month: 'short',
    year: 'numeric',
  });
}

function relativeFromNow(iso: string): string {
  const d = new Date(iso);
  const now = new Date();
  const diffDays = Math.floor((d.getTime() - now.getTime()) / 86400000);

  if (diffDays < 0) return `истекло ${-diffDays} д назад`;
  if (diffDays === 0) return 'сегодня';
  if (diffDays === 1) return 'завтра';
  if (diffDays < 30) return `через ${diffDays} д`;
  const months = Math.floor(diffDays / 30);
  return `через ${months} мес`;
}

function truncate(s: string, max: number): string {
  if (s.length <= max) return s;
  return s.slice(0, max - 1) + '…';
}