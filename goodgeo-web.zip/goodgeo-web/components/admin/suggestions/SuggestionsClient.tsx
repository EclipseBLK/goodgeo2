'use client';

import { useState, useTransition } from 'react';
import { useRouter } from 'next/navigation';
import {
  Check,
  X,
  MapPin,
  Clock,
  User as UserIcon,
  ExternalLink,
  Loader2,
  Inbox,
} from 'lucide-react';
import {
  approveSuggestion,
  rejectSuggestion,
  listSuggestions,
  type Suggestion,
  type SuggestionStatus,
} from '@/app/admin/entrances/creator-actions';

type FilterStatus = SuggestionStatus | 'all';

const FILTERS: { key: FilterStatus; label: string; color: string }[] = [
  { key: 'pending', label: 'На проверке', color: 'amber' },
  { key: 'approved', label: 'Одобрено', color: 'teal' },
  { key: 'rejected', label: 'Отклонено', color: 'rose' },
  { key: 'all', label: 'Все', color: 'slate' },
];

export default function SuggestionsClient({
  initialSuggestions,
}: {
  initialSuggestions: Suggestion[];
}) {
  const router = useRouter();
  const [filter, setFilter] = useState<FilterStatus>('pending');
  const [items, setItems] = useState<Suggestion[]>(initialSuggestions);
  const [busyId, setBusyId] = useState<string | null>(null);
  const [isPending, startTransition] = useTransition();
  const [rejectingId, setRejectingId] = useState<string | null>(null);
  const [rejectReason, setRejectReason] = useState('');

  async function handleFilterChange(newFilter: FilterStatus) {
    setFilter(newFilter);
    startTransition(async () => {
      const fresh = await listSuggestions({ status: newFilter });
      setItems(fresh);
    });
  }

  async function handleApprove(id: string) {
    if (!confirm('Одобрить это предложение?')) return;
    setBusyId(id);
    const res = await approveSuggestion(id);
    if (res.error) {
      alert('Ошибка: ' + res.error);
    } else {
      if (filter === 'pending') {
        setItems((prev) => prev.filter((s) => s.id !== id));
      } else {
        const fresh = await listSuggestions({ status: filter });
        setItems(fresh);
      }
      router.refresh();
    }
    setBusyId(null);
  }

  async function handleReject(id: string) {
    setBusyId(id);
    const res = await rejectSuggestion(id, rejectReason || undefined);
    if (res.error) {
      alert('Ошибка: ' + res.error);
    } else {
      if (filter === 'pending') {
        setItems((prev) => prev.filter((s) => s.id !== id));
      } else {
        const fresh = await listSuggestions({ status: filter });
        setItems(fresh);
      }
      router.refresh();
    }
    setRejectingId(null);
    setRejectReason('');
    setBusyId(null);
  }

  return (
    <div>
      {/* Фильтры */}
      <div className="flex flex-wrap gap-2 mb-6">
        {FILTERS.map((f) => (
          <button
            key={f.key}
            onClick={() => handleFilterChange(f.key)}
            className={`px-4 py-2 rounded-lg text-sm font-medium transition ${
              filter === f.key
                ? 'bg-teal-600 text-white'
                : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-50'
            }`}
          >
            {f.label}
          </button>
        ))}
      </div>

      {/* Состояние загрузки */}
      {isPending && (
        <div className="flex items-center justify-center py-8 text-slate-400">
          <Loader2 className="animate-spin" size={20} />
        </div>
      )}

      {/* Пустое состояние */}
      {!isPending && items.length === 0 && (
        <div className="bg-white border border-slate-200 rounded-2xl p-12 text-center">
          <Inbox className="mx-auto text-slate-300 mb-3" size={48} />
          <div className="text-slate-500 font-medium mb-1">
            {filter === 'pending' ? 'Нет предложений на проверке' : 'Ничего не найдено'}
          </div>
          <div className="text-sm text-slate-400">
            {filter === 'pending'
              ? 'Все предложения курьеров обработаны'
              : 'Попробуйте другой фильтр'}
          </div>
        </div>
      )}

      {/* Список */}
      {!isPending && items.length > 0 && (
        <div className="space-y-3">
          {items.map((s) => (
            <SuggestionCard
              key={s.id}
              suggestion={s}
              busy={busyId === s.id}
              rejectingNow={rejectingId === s.id}
              rejectReason={rejectReason}
              onSetRejectReason={setRejectReason}
              onApprove={() => handleApprove(s.id)}
              onStartReject={() => {
                setRejectingId(s.id);
                setRejectReason('');
              }}
              onCancelReject={() => {
                setRejectingId(null);
                setRejectReason('');
              }}
              onConfirmReject={() => handleReject(s.id)}
            />
          ))}
        </div>
      )}
    </div>
  );
}

// =====================================================
// === КАРТОЧКА ОДНОГО ПРЕДЛОЖЕНИЯ ===
// =====================================================

type CardProps = {
  suggestion: Suggestion;
  busy: boolean;
  rejectingNow: boolean;
  rejectReason: string;
  onSetRejectReason: (v: string) => void;
  onApprove: () => void;
  onStartReject: () => void;
  onCancelReject: () => void;
  onConfirmReject: () => void;
};

function SuggestionCard({
  suggestion,
  busy,
  rejectingNow,
  rejectReason,
  onSetRejectReason,
  onApprove,
  onStartReject,
  onCancelReject,
  onConfirmReject,
}: CardProps) {
  const s = suggestion;
  const adminMapUrl = `/admin/entrances?lat=${s.lat}&lng=${s.lng}&zoom=18`;

  // Mapbox Static Image — спутниковое превью места
  const token = process.env.NEXT_PUBLIC_MAPBOX_TOKEN;
  const previewUrl = token
    ? `https://api.mapbox.com/styles/v1/mapbox/satellite-streets-v12/static/` +
      `pin-l+f59e0b(${s.lng},${s.lat})/` +
      `${s.lng},${s.lat},18,0/` +
      `400x240@2x?access_token=${token}`
    : null;

  // Форматируем диапазоны квартир
  const rangesText =
    s.ranges && s.ranges.length > 0
      ? s.ranges.map((r) => `${r.apt_from}–${r.apt_to}`).join(', ')
      : s.apt_from && s.apt_to
      ? `${s.apt_from}–${s.apt_to}`
      : '—';

  // Форматируем доп.квартиры
  const extrasText =
    s.apt_extras && s.apt_extras.length > 0 ? s.apt_extras.join(', ') : null;

  // Время до истечения (для pending)
  const timeRemaining = getTimeRemaining(s.expires_at);
  const isExpired = new Date(s.expires_at).getTime() < Date.now();

  return (
    <div
      className={`bg-white border rounded-2xl overflow-hidden ${
        s.status === 'pending'
          ? 'border-amber-200'
          : s.status === 'approved'
          ? 'border-teal-200'
          : 'border-slate-200'
      }`}
    >
      <div className="flex flex-col md:flex-row">
        {/* Превью карты */}
        {previewUrl && (
          <a
            href={adminMapUrl}
            className="block flex-shrink-0 md:w-64 md:h-auto h-48 relative bg-slate-100 group"
            title="Открыть в Google Maps"
          >
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img
              src={previewUrl}
              alt={`Карта: ${s.address ?? 'Подъезд'}`}
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-slate-900/0 group-hover:bg-slate-900/20 transition-colors flex items-center justify-center opacity-0 group-hover:opacity-100">
              <span className="bg-white/90 text-slate-700 text-xs font-medium px-2 py-1 rounded-md">
                Открыть в Maps →
              </span>
            </div>
          </a>
        )}

        {/* Контент карточки */}
        <div className="flex-1 p-5">
          {/* Заголовок */}
          <div className="flex items-start justify-between mb-4">
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2 mb-1">
                <h3 className="font-semibold text-slate-800 truncate">
                  {s.address ?? 'Без адреса'}
                  {s.korpus && (
                    <span className="ml-1 text-teal-600 font-bold">
                      · корп. {s.korpus}
                    </span>
                  )}
                </h3>
                <StatusBadge status={s.status} />
              </div>
              <div className="text-sm text-slate-500">
                Подъезд №{s.entrance_number ?? '—'} · кв. {rangesText}
                {extrasText && (
                  <span className="text-slate-400"> + доп. {extrasText}</span>
                )}
              </div>
            </div>

            {/* Действия */}
            {s.status === 'pending' && !rejectingNow && (
              <div className="flex gap-2 flex-shrink-0">
                <button
                  onClick={onApprove}
                  disabled={busy}
                  className="flex items-center gap-1.5 px-3 py-2 bg-teal-600 hover:bg-teal-700 disabled:bg-slate-300 text-white rounded-lg text-sm font-medium transition"
                >
                  {busy ? (
                    <Loader2 className="animate-spin" size={16} />
                  ) : (
                    <Check size={16} />
                  )}
                  Одобрить
                </button>
                <button
                  onClick={onStartReject}
                  disabled={busy}
                  className="flex items-center gap-1.5 px-3 py-2 bg-white border border-rose-200 hover:bg-rose-50 disabled:opacity-50 text-rose-600 rounded-lg text-sm font-medium transition"
                >
                  <X size={16} />
                  Отклонить
                </button>
              </div>
            )}
          </div>

          {/* Форма отклонения */}
          {rejectingNow && (
            <div className="mb-4 p-3 bg-rose-50 border border-rose-100 rounded-lg">
              <label className="block text-xs font-medium text-rose-700 mb-1">
                Причина отклонения (необязательно):
              </label>
              <input
                type="text"
                value={rejectReason}
                onChange={(e) => onSetRejectReason(e.target.value)}
                placeholder="Например: дубликат, неточные координаты..."
                className="w-full px-3 py-2 text-sm border border-rose-200 rounded-md focus:outline-none focus:ring-2 focus:ring-rose-200"
                autoFocus
              />
              <div className="flex gap-2 mt-2">
                <button
                  onClick={onConfirmReject}
                  disabled={busy}
                  className="px-3 py-1.5 bg-rose-600 hover:bg-rose-700 text-white rounded-md text-sm font-medium disabled:bg-slate-300"
                >
                  {busy ? 'Отклоняем...' : 'Подтвердить'}
                </button>
                <button
                  onClick={onCancelReject}
                  disabled={busy}
                  className="px-3 py-1.5 bg-white border border-slate-200 text-slate-600 rounded-md text-sm hover:bg-slate-50"
                >
                  Отмена
                </button>
              </div>
            </div>
          )}

          {/* Метаинформация */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-sm">
            {/* Курьер */}
            <div className="flex items-start gap-2">
              <UserIcon size={16} className="text-slate-400 flex-shrink-0 mt-0.5" />
              <div className="min-w-0">
                <div className="text-slate-500 text-xs">Курьер</div>
                {s.suggester ? (
                  <div>
                    <div className="font-medium text-slate-700">
                      {s.suggester.name ?? 'Без имени'}
                    </div>
                    <div className="text-xs text-slate-400 font-mono">
                      ID {s.suggester.client_number ?? '—'}
                    </div>
                  </div>
                ) : (
                  <div className="text-slate-400">Удалённый юзер</div>
                )}
              </div>
            </div>

            {/* Координаты */}
            <div className="flex items-start gap-2">
              <MapPin size={16} className="text-slate-400 flex-shrink-0 mt-0.5" />
              <div className="min-w-0">
                <div className="text-slate-500 text-xs">Координаты</div>
                <a
                  href={adminMapUrl}
                  className="text-teal-600 hover:underline text-xs flex items-center gap-1"
                >
                  {s.lat.toFixed(5)}, {s.lng.toFixed(5)}
                  <ExternalLink size={11} />
                </a>
              </div>
            </div>

            {/* Время */}
            <div className="flex items-start gap-2">
              <Clock size={16} className="text-slate-400 flex-shrink-0 mt-0.5" />
              <div className="min-w-0">
                <div className="text-slate-500 text-xs">
                  {s.status === 'pending' ? 'Истекает' : 'Создано'}
                </div>
                {s.status === 'pending' ? (
                  <div
                    className={`text-xs font-medium ${
                      isExpired
                        ? 'text-rose-600'
                        : timeRemaining.includes('ч')
                        ? 'text-amber-600'
                        : 'text-slate-600'
                    }`}
                  >
                    {isExpired ? 'Истекло' : `через ${timeRemaining}`}
                  </div>
                ) : (
                  <div className="text-slate-600 text-xs">
                    {formatDate(s.created_at)}
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Причина отклонения */}
          {s.status === 'rejected' && s.rejection_reason && (
            <div className="mt-3 px-3 py-2 bg-rose-50 border border-rose-100 rounded-md text-sm text-rose-700">
              <span className="font-medium">Причина:</span> {s.rejection_reason}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

function StatusBadge({ status }: { status: SuggestionStatus }) {
  const config = {
    pending: { label: 'На проверке', cls: 'bg-amber-50 text-amber-700' },
    approved: { label: 'Одобрено', cls: 'bg-teal-50 text-teal-700' },
    rejected: { label: 'Отклонено', cls: 'bg-rose-50 text-rose-700' },
    expired: { label: 'Истекло', cls: 'bg-slate-100 text-slate-500' },
  }[status];

  return (
    <span
      className={`inline-block px-2 py-0.5 rounded-md text-xs font-medium ${config.cls}`}
    >
      {config.label}
    </span>
  );
}

function getTimeRemaining(expiresAt: string): string {
  const ms = new Date(expiresAt).getTime() - Date.now();
  if (ms <= 0) return '0 мин';
  const mins = Math.floor(ms / 60000);
  const hours = Math.floor(mins / 60);
  if (hours >= 1) return `${hours} ч ${mins % 60} мин`;
  return `${mins} мин`;
}

function formatDate(iso: string): string {
  const d = new Date(iso);
  return d.toLocaleDateString('ru-RU', {
    day: '2-digit',
    month: 'short',
    hour: '2-digit',
    minute: '2-digit',
  });
}