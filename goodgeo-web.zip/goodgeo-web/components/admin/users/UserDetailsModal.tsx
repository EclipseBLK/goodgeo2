'use client';

import { useEffect, useState } from 'react';
import { X, Lock, Unlock, Calendar, CreditCard, Mail, Clock } from 'lucide-react';
import type { User } from '@/lib/admin/types';
import {
  getUserDetails,
  extendTrial,
  activateSubscriptionManually,
  toggleBlockUser,
} from '@/app/admin/users/actions';

type Details = {
  user: User;
  history: { id: string; address: string; visited_at: string }[];
};

export default function UserDetailsModal({
  userId,
  onClose,
  onUpdate,
}: {
  userId: string;
  onClose: () => void;
  onUpdate: (user: User) => void;
}) {
  const [details, setDetails] = useState<Details | null>(null);
  const [loading, setLoading] = useState(true);
  const [acting, setActing] = useState(false);

  useEffect(() => {
    getUserDetails(userId).then((d) => {
      setDetails(d as Details | null);
      setLoading(false);
    });
  }, [userId]);

  const refresh = async () => {
    const d = (await getUserDetails(userId)) as Details | null;
    setDetails(d);
    if (d?.user) onUpdate(d.user);
  };

  const handleExtendTrial = async () => {
    if (!confirm('Продлить триал на 7 дней?')) return;
    setActing(true);
    const result = await extendTrial(userId, 7);
    setActing(false);
    if (result.error) return alert('Ошибка: ' + result.error);
    await refresh();
  };

  const handleActivate = async () => {
    if (!confirm('Активировать подписку на 1 месяц вручную?\n\nВажно: при подключении Apple/Google IAP реальный платёж может перезаписать ручную активацию.')) return;
    setActing(true);
    const result = await activateSubscriptionManually(userId, 1);
    setActing(false);
    if (result.error) return alert('Ошибка: ' + result.error);
    await refresh();
  };

  const handleToggleBlock = async () => {
    if (!details) return;
    const isBlocking = !details.user.is_blocked;
    const msg = isBlocking
      ? 'Заблокировать пользователя?\nДоступ будет закрыт даже при активной подписке.'
      : 'Разблокировать пользователя?';
    if (!confirm(msg)) return;
    setActing(true);
    const result = await toggleBlockUser(userId, isBlocking);
    setActing(false);
    if (result.error) return alert('Ошибка: ' + result.error);
    await refresh();
  };

  return (
    <div
      className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4"
      onClick={onClose}
    >
      <div
        className="bg-white rounded-2xl w-full max-w-2xl max-h-[90vh] overflow-hidden flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="px-5 py-4 border-b border-slate-200 flex items-center justify-between">
          <h2 className="font-semibold text-slate-800">Детали пользователя</h2>
          <button
            onClick={onClose}
            className="w-8 h-8 flex items-center justify-center rounded-lg hover:bg-slate-100 text-slate-500"
          >
            <X size={18} />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto p-5">
          {loading ? (
            <div className="text-slate-400 text-sm">Загрузка...</div>
          ) : !details ? (
            <div className="text-slate-400 text-sm">Пользователь не найден</div>
          ) : (
            <div className="space-y-5">
              <Section title="Профиль">
                <Row icon={<Mail size={14} />} label="Email" value={details.user.email} />
                <Row label="Имя" value={details.user.name ?? '—'} />
                <Row
                  label="Роль"
                  value={details.user.role === 'admin' ? 'Администратор' : 'Пользователь'}
                />
                <Row
                  icon={<Clock size={14} />}
                  label="Зарегистрирован"
                  value={formatFull(details.user.created_at)}
                />
                <Row
                  label="Последний онлайн"
                  value={
                    details.user.last_seen_at ? formatFull(details.user.last_seen_at) : '—'
                  }
                />
              </Section>

              <Section title="Подписка">
                <Row
                  icon={<CreditCard size={14} />}
                  label="Статус"
                  value={statusLabel(details.user.subscription_status, details.user.is_blocked)}
                />
                <Row label="Источник" value={sourceLabel(details.user.subscription_source)} />
                <Row
                  icon={<Calendar size={14} />}
                  label="Триал до"
                  value={
                    details.user.trial_ends_at ? formatFull(details.user.trial_ends_at) : '—'
                  }
                />
                <Row
                  icon={<Calendar size={14} />}
                  label="Подписка до"
                  value={
                    details.user.subscription_ends_at
                      ? formatFull(details.user.subscription_ends_at)
                      : '—'
                  }
                />
                {details.user.platform_transaction_id && (
                  <Row
                    label="ID транзакции"
                    value={details.user.platform_transaction_id}
                  />
                )}
              </Section>

              <Section title={`История посещений (${details.history.length})`}>
                {details.history.length === 0 ? (
                  <div className="text-xs text-slate-400">Пусто</div>
                ) : (
                  <div className="space-y-1.5">
                    {details.history.map((h) => (
                      <div key={h.id} className="text-xs flex justify-between text-slate-600">
                        <span className="truncate">{h.address}</span>
                        <span className="text-slate-400 ml-2 flex-shrink-0">
                          {formatRelative(h.visited_at)}
                        </span>
                      </div>
                    ))}
                  </div>
                )}
              </Section>
            </div>
          )}
        </div>

        {!loading && details && (
          <div className="border-t border-slate-200 p-4 flex flex-wrap gap-2 bg-slate-50">
            <button
              onClick={handleExtendTrial}
              disabled={acting}
              className="px-3 py-2 bg-amber-50 hover:bg-amber-100 text-amber-700 border border-amber-200 rounded-lg text-sm font-medium flex items-center gap-2 disabled:opacity-50"
            >
              <Calendar size={14} /> +7 дней триала
            </button>
            <button
              onClick={handleActivate}
              disabled={acting}
              className="px-3 py-2 bg-teal-50 hover:bg-teal-100 text-teal-700 border border-teal-200 rounded-lg text-sm font-medium flex items-center gap-2 disabled:opacity-50"
            >
              <CreditCard size={14} /> Активировать (+1 мес)
            </button>
            <button
              onClick={handleToggleBlock}
              disabled={acting}
              className={`px-3 py-2 border rounded-lg text-sm font-medium flex items-center gap-2 disabled:opacity-50 ml-auto ${
                details.user.is_blocked
                  ? 'bg-emerald-50 hover:bg-emerald-100 text-emerald-700 border-emerald-200'
                  : 'bg-red-50 hover:bg-red-100 text-red-700 border-red-200'
              }`}
            >
              {details.user.is_blocked ? (
                <>
                  <Unlock size={14} /> Разблокировать
                </>
              ) : (
                <>
                  <Lock size={14} /> Заблокировать
                </>
              )}
            </button>
          </div>
        )}
      </div>
    </div>
  );
}

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div>
      <h3 className="text-xs font-semibold text-slate-500 uppercase mb-2">{title}</h3>
      <div className="bg-slate-50 rounded-lg p-3 space-y-1.5">{children}</div>
    </div>
  );
}

function Row({
  icon,
  label,
  value,
}: {
  icon?: React.ReactNode;
  label: string;
  value: string;
}) {
  return (
    <div className="flex justify-between text-xs gap-2">
      <span className="text-slate-500 flex items-center gap-1.5 flex-shrink-0">
        {icon}
        {label}
      </span>
      <span className="text-slate-800 font-medium text-right break-all">{value}</span>
    </div>
  );
}

function statusLabel(status: string, blocked: boolean): string {
  if (blocked) return 'Заблокирован';
  switch (status) {
    case 'trial': return 'Триал';
    case 'active': return 'Активна';
    case 'expired': return 'Истекла';
    case 'cancelled': return 'Отменена';
    default: return status;
  }
}

function sourceLabel(source: string): string {
  switch (source) {
    case 'trial': return 'Триал';
    case 'manual': return 'Вручную (админ)';
    case 'google_play': return 'Google Play';
    case 'app_store': return 'App Store';
    default: return source;
  }
}

function formatFull(iso: string): string {
  return new Date(iso).toLocaleString('ru-RU', {
    day: '2-digit',
    month: '2-digit',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  });
}

function formatRelative(iso: string): string {
  const d = new Date(iso);
  const now = new Date();
  const diffMs = now.getTime() - d.getTime();
  const diffMin = Math.floor(diffMs / 60000);
  const diffH = Math.floor(diffMs / 3600000);
  const diffD = Math.floor(diffMs / 86400000);

  if (diffMin < 1) return 'только что';
  if (diffMin < 60) return `${diffMin} мин`;
  if (diffH < 24) return `${diffH} ч`;
  if (diffD < 7) return `${diffD} д`;
  return d.toLocaleDateString('ru-RU', { day: '2-digit', month: 'short' });
}