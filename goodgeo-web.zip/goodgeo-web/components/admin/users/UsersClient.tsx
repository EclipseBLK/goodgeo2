'use client';

import { useMemo, useState, useTransition } from 'react';
import {
  Search,
  Eye,
  Lock,
  ShieldCheck,
  Inbox,
  Loader2,
  Sparkles,
} from 'lucide-react';
import type { User } from '@/lib/admin/types';
import UserDetailsModal from './UserDetailsModal';
import { changeUserRole } from '@/app/admin/users/actions';

type StatusFilter =
  | 'all'
  | 'trial'
  | 'active'
  | 'expired'
  | 'cancelled'
  | 'blocked'
  | 'creator_applied'
  | 'creators';

const FILTERS: { key: StatusFilter; label: string }[] = [
  { key: 'all', label: 'Все' },
  { key: 'creator_applied', label: '🔔 Заявки на creator' },
  { key: 'creators', label: 'Creators' },
  { key: 'trial', label: 'Триал' },
  { key: 'active', label: 'Активные' },
  { key: 'expired', label: 'Истёкшие' },
  { key: 'cancelled', label: 'Отменённые' },
  { key: 'blocked', label: 'Заблокированные' },
];

export default function UsersClient({ initialUsers }: { initialUsers: User[] }) {
  const [users, setUsers] = useState<User[]>(initialUsers);
  const [search, setSearch] = useState('');
  const [filter, setFilter] = useState<StatusFilter>('all');
  const [selectedUserId, setSelectedUserId] = useState<string | null>(null);
  const [roleBusyId, setRoleBusyId] = useState<string | null>(null);
  const [, startTransition] = useTransition();

  const counts = useMemo(() => {
    const result: Record<string, number> = { all: users.length };
    let blocked = 0;
    let creatorApplied = 0;
    let creators = 0;
    for (const u of users) {
      if (u.is_blocked) blocked++;
      if (u.is_creator_applied && u.role === 'user') creatorApplied++;
      if (u.role === 'creator' || u.role === 'admin') creators++;
      result[u.subscription_status] = (result[u.subscription_status] ?? 0) + 1;
    }
    result.blocked = blocked;
    result.creator_applied = creatorApplied;
    result.creators = creators;
    return result;
  }, [users]);

  const filtered = useMemo(() => {
    return users.filter((u) => {
      if (filter === 'blocked' && !u.is_blocked) return false;
      if (filter === 'creator_applied') {
        if (!u.is_creator_applied || u.role !== 'user') return false;
      } else if (filter === 'creators') {
        if (u.role !== 'creator' && u.role !== 'admin') return false;
      } else if (filter !== 'all' && filter !== 'blocked') {
        if (u.subscription_status !== filter) return false;
      }

      if (search) {
        const q = search.toLowerCase();
        const matchEmail = u.email.toLowerCase().includes(q);
        const matchName = (u.name ?? '').toLowerCase().includes(q);
        const matchClientNum = (u.client_number ?? '').toLowerCase().includes(q);
        if (!matchEmail && !matchName && !matchClientNum) return false;
      }

      return true;
    });
  }, [users, filter, search]);

  const handleUpdate = (updated: User) => {
    setUsers((prev) => prev.map((u) => (u.id === updated.id ? updated : u)));
  };

  const handleRoleChange = (userId: string, newRole: 'user' | 'creator' | 'admin') => {
    setRoleBusyId(userId);
    startTransition(async () => {
      const res = await changeUserRole(userId, newRole);
      if (res.error) {
        alert('Ошибка: ' + res.error);
        setRoleBusyId(null);
        return;
      }
      // Локально обновляем список
      setUsers((prev) =>
        prev.map((u) =>
          u.id === userId
            ? {
                ...u,
                role: newRole,
                is_creator_applied: newRole === 'creator' ? false : u.is_creator_applied,
              }
            : u
        )
      );
      setRoleBusyId(null);
    });
  };

  return (
    <div className="space-y-4">
      {/* Filters */}
      <div className="flex flex-wrap gap-2">
        {FILTERS.map((f) => (
          <button
            key={f.key}
            onClick={() => setFilter(f.key)}
            className={`px-3 py-1.5 text-sm rounded-lg border transition ${
              filter === f.key
                ? 'bg-teal-600 text-white border-teal-600'
                : f.key === 'creator_applied' && (counts[f.key] ?? 0) > 0
                ? 'bg-amber-50 text-amber-700 border-amber-200 hover:bg-amber-100'
                : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
            }`}
          >
            {f.label}
            <span
              className={`ml-1.5 text-xs ${
                filter === f.key ? 'opacity-80' : 'text-slate-400'
              }`}
            >
              {counts[f.key] ?? 0}
            </span>
          </button>
        ))}
      </div>

      {/* Search */}
      <div className="relative max-w-md">
        <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
        <input
          type="text"
          placeholder="Поиск по email, имени или ID..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="w-full pl-9 pr-3 py-2 bg-white border border-slate-200 rounded-lg text-sm focus:outline-none focus:border-teal-500"
        />
      </div>

      {/* Table */}
      <div className="bg-white border border-slate-200 rounded-2xl overflow-hidden">
        {filtered.length === 0 ? (
          <div className="p-8 text-center text-slate-400 text-sm">
            {search || filter !== 'all' ? 'Ничего не найдено' : 'Пока нет пользователей'}
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-slate-50 text-slate-500 text-xs uppercase">
                <tr>
                  <th className="text-left px-5 py-3 font-medium">Пользователь</th>
                  <th className="text-left px-4 py-3 font-medium">ID</th>
                  <th className="text-left px-4 py-3 font-medium">Роль</th>
                  <th className="text-left px-4 py-3 font-medium">Принято</th>
                  <th className="text-left px-4 py-3 font-medium">Статус</th>
                  <th className="text-left px-4 py-3 font-medium">До</th>
                  <th className="text-left px-4 py-3 font-medium">Онлайн</th>
                  <th className="text-right px-4 py-3 font-medium">Действия</th>
                </tr>
              </thead>
              <tbody>
                {filtered.map((user) => (
                  <tr
                    key={user.id}
                    className="border-t border-slate-100 hover:bg-slate-50/60"
                  >
                    {/* Пользователь */}
                    <td className="px-5 py-3 min-w-[200px]">
                      <div className="flex items-center gap-2">
                        <div className="font-medium text-slate-800 truncate">
                          {user.name ?? '—'}
                        </div>
                        {user.role === 'admin' && (
                          <ShieldCheck
                            size={14}
                            className="text-teal-600 flex-shrink-0"
                            aria-label="Admin"
                          />
                        )}
                        {user.role === 'creator' && (
                          <Sparkles
                            size={14}
                            className="text-amber-500 flex-shrink-0"
                            aria-label="Creator"
                          />
                        )}
                        {user.is_blocked && (
                          <Lock
                            size={14}
                            className="text-red-600 flex-shrink-0"
                            aria-label="Blocked"
                          />
                        )}
                        {user.is_creator_applied && user.role === 'user' && (
                          <span
                            className="inline-flex items-center gap-1 px-1.5 py-0.5 bg-amber-50 border border-amber-200 rounded text-[10px] font-medium text-amber-700"
                            title="Подал заявку на роль creator"
                          >
                            <Inbox size={10} />
                            заявка
                          </span>
                        )}
                      </div>
                      <div className="text-xs text-slate-400 truncate">{user.email}</div>
                    </td>

                    {/* Client ID */}
                    <td className="px-4 py-3">
                      <span className="font-mono text-xs text-slate-500">
                        {user.client_number ?? '—'}
                      </span>
                    </td>

                    {/* Роль */}
                    <td className="px-4 py-3">
                      <RoleSelector
                        userId={user.id}
                        currentRole={user.role}
                        busy={roleBusyId === user.id}
                        onChange={(newRole) => handleRoleChange(user.id, newRole)}
                      />
                    </td>

                    {/* Принято подъездов */}
                    <td className="px-4 py-3">
                      {user.suggestions_approved_count > 0 ? (
                        <div className="text-xs">
                          <span className="font-semibold text-slate-700">
                            {user.suggestions_approved_count}
                          </span>
                          <span className="text-slate-400 ml-1">
                            / {user.suggestions_total_count}
                          </span>
                          {user.bonus_days_earned > 0 && (
                            <div className="text-[10px] text-teal-600 mt-0.5">
                              +{user.bonus_days_earned}д бонуса
                            </div>
                          )}
                        </div>
                      ) : (
                        <span className="text-slate-300 text-xs">—</span>
                      )}
                    </td>

                    {/* Статус подписки */}
                    <td className="px-4 py-3">
                      <StatusBadge
                        status={user.subscription_status}
                        blocked={user.is_blocked}
                      />
                    </td>

                    {/* Действует до */}
                    <td className="px-4 py-3 text-slate-600 text-xs whitespace-nowrap">
                      {endDate(user)}
                    </td>

                    {/* Онлайн */}
                    <td className="px-4 py-3 text-slate-500 text-xs whitespace-nowrap">
                      {user.last_seen_at ? formatRelative(user.last_seen_at) : '—'}
                    </td>

                    {/* Действия */}
                    <td className="px-4 py-3 text-right">
                      <button
                        onClick={() => setSelectedUserId(user.id)}
                        className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-xs font-medium inline-flex items-center gap-1.5"
                      >
                        <Eye size={14} />
                        Открыть
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {selectedUserId && (
        <UserDetailsModal
          userId={selectedUserId}
          onClose={() => setSelectedUserId(null)}
          onUpdate={handleUpdate}
        />
      )}
    </div>
  );
}

// =====================================================
// === Селектор роли (inline dropdown в таблице) ===
// =====================================================

function RoleSelector({
  userId,
  currentRole,
  busy,
  onChange,
}: {
  userId: string;
  currentRole: 'user' | 'creator' | 'admin';
  busy: boolean;
  onChange: (newRole: 'user' | 'creator' | 'admin') => void;
}) {
  const styles: Record<string, string> = {
    user: 'bg-slate-100 text-slate-700 border-slate-200',
    creator: 'bg-amber-50 text-amber-700 border-amber-200',
    admin: 'bg-teal-50 text-teal-700 border-teal-200',
  };

  return (
    <div className="relative">
      <select
        value={currentRole}
        disabled={busy}
        onChange={(e) =>
          onChange(e.target.value as 'user' | 'creator' | 'admin')
        }
        className={`appearance-none cursor-pointer pl-2.5 pr-7 py-1 text-xs font-medium rounded-md border ${
          styles[currentRole]
        } disabled:opacity-50`}
      >
        <option value="user">user</option>
        <option value="creator">creator</option>
        <option value="admin">admin</option>
      </select>
      {busy ? (
        <Loader2
          size={11}
          className="absolute right-1.5 top-1/2 -translate-y-1/2 animate-spin pointer-events-none"
        />
      ) : (
        <svg
          className="absolute right-1.5 top-1/2 -translate-y-1/2 pointer-events-none"
          width="10"
          height="10"
          viewBox="0 0 12 12"
          fill="none"
        >
          <path
            d="M3 4.5L6 7.5L9 4.5"
            stroke="currentColor"
            strokeWidth="1.5"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
        </svg>
      )}
    </div>
  );
}

// =====================================================
// === Существующие хелперы ===
// =====================================================

function StatusBadge({ status, blocked }: { status: string; blocked: boolean }) {
  if (blocked) {
    return (
      <span className="inline-block px-2 py-1 rounded-md text-xs font-medium bg-red-50 text-red-700">
        Заблокирован
      </span>
    );
  }
  const styles: Record<string, string> = {
    trial: 'bg-amber-50 text-amber-700',
    active: 'bg-teal-50 text-teal-700',
    expired: 'bg-red-50 text-red-700',
    cancelled: 'bg-slate-100 text-slate-600',
  };
  const labels: Record<string, string> = {
    trial: 'Триал',
    active: 'Активна',
    expired: 'Истекла',
    cancelled: 'Отменена',
  };
  return (
    <span
      className={`inline-block px-2 py-1 rounded-md text-xs font-medium ${
        styles[status] ?? 'bg-slate-100 text-slate-600'
      }`}
    >
      {labels[status] ?? status}
    </span>
  );
}

function endDate(user: User): string {
  const date =
    user.subscription_status === 'trial' ? user.trial_ends_at : user.subscription_ends_at;
  if (!date) return '—';

  const d = new Date(date);
  const now = new Date();
  const diffDays = Math.floor((d.getTime() - now.getTime()) / 86400000);

  if (diffDays < 0) return 'истекло';
  if (diffDays === 0) return 'сегодня';
  if (diffDays === 1) return 'завтра';
  return `через ${diffDays} д`;
}

function formatRelative(iso: string): string {
  const d = new Date(iso);
  const now = new Date();
  const diffMs = now.getTime() - d.getTime();
  const diffMin = Math.floor(diffMs / 60000);
  const diffH = Math.floor(diffMs / 3600000);
  const diffD = Math.floor(diffMs / 86400000);

  if (diffMin < 1) return 'только что';
  if (diffMin < 60) return `${diffMin} мин назад`;
  if (diffH < 24) return `${diffH} ч назад`;
  if (diffD < 7) return `${diffD} д назад`;
  return d.toLocaleDateString('ru-RU', { day: '2-digit', month: 'short' });
}