import { createClient } from '@/lib/supabase/server';

// === Типы ===

export type RegistrationStats = {
  day1: number;
  day7: number;
  day30: number;
  day365: number;
};

export type PaymentStats = {
  paid: number;
  free: number;
  total: number;
  paidPercent: number;
  freePercent: number;
};

export type DuplicateDeviceAlert = {
  suspicious_id: string;
  suspicious_email: string;
  suspicious_created_at: string;
  primary_id: string | null;
  primary_email: string | null;
};

export type HeatmapPoint = [number, number]; // [lng, lat]

// === Регистрации по периодам ===

export async function getRegistrationsStats(): Promise<RegistrationStats> {
  const supabase = await createClient();
  const now = new Date();
  const day1 = new Date(now.getTime() - 1 * 86400000).toISOString();
  const day7 = new Date(now.getTime() - 7 * 86400000).toISOString();
  const day30 = new Date(now.getTime() - 30 * 86400000).toISOString();
  const day365 = new Date(now.getTime() - 365 * 86400000).toISOString();

  const [r1, r7, r30, r365] = await Promise.all([
    supabase.from('profiles').select('*', { count: 'exact', head: true }).gte('created_at', day1),
    supabase.from('profiles').select('*', { count: 'exact', head: true }).gte('created_at', day7),
    supabase.from('profiles').select('*', { count: 'exact', head: true }).gte('created_at', day30),
    supabase.from('profiles').select('*', { count: 'exact', head: true }).gte('created_at', day365),
  ]);

  return {
    day1: r1.count ?? 0,
    day7: r7.count ?? 0,
    day30: r30.count ?? 0,
    day365: r365.count ?? 0,
  };
}

// === Распределение платных/бесплатных ===

export async function getPaymentStats(): Promise<PaymentStats> {
  const supabase = await createClient();
  const [{ count: total }, { count: paid }] = await Promise.all([
    supabase.from('profiles').select('*', { count: 'exact', head: true }),
    supabase
      .from('profiles')
      .select('*', { count: 'exact', head: true })
      .eq('subscription_status', 'active'),
  ]);

  const totalCount = total ?? 0;
  const paidCount = paid ?? 0;
  const freeCount = totalCount - paidCount;

  return {
    paid: paidCount,
    free: freeCount,
    total: totalCount,
    paidPercent: totalCount > 0 ? Math.round((paidCount / totalCount) * 100) : 0,
    freePercent: totalCount > 0 ? Math.round((freeCount / totalCount) * 100) : 0,
  };
}

// === Алерты о повторных регистрациях ===

export async function getDuplicateDeviceAlerts(): Promise<DuplicateDeviceAlert[]> {
  const supabase = await createClient();

  // Берём всех юзеров у которых есть device_id
  const { data: profiles } = await supabase
    .from('profiles')
    .select('id, email, device_id, created_at')
    .not('device_id', 'is', null);

  if (!profiles || profiles.length === 0) return [];

  // Берём used_devices
  const deviceIds = profiles.map((p) => p.device_id).filter((x): x is string => !!x);
  const { data: usedDevices } = await supabase
    .from('used_devices')
    .select('device_id, first_user_id')
    .in('device_id', deviceIds);

  if (!usedDevices) return [];

  const firstUserMap = new Map<string, string | null>();
  for (const ud of usedDevices) {
    firstUserMap.set(ud.device_id, ud.first_user_id);
  }

  // Подозрительные = у кого device_id уже зарегистрирован под другим юзером
  const suspicious = profiles.filter((p) => {
    const firstUserId = firstUserMap.get(p.device_id!);
    return firstUserId && firstUserId !== p.id;
  });

  if (suspicious.length === 0) return [];

  // Подгружаем email первичных юзеров
  const primaryIds = suspicious
    .map((p) => firstUserMap.get(p.device_id!))
    .filter((x): x is string => !!x);

  const { data: primaries } = await supabase
    .from('profiles')
    .select('id, email')
    .in('id', primaryIds);

  const primaryMap = new Map<string, string>();
  for (const p of primaries ?? []) {
    primaryMap.set(p.id, p.email);
  }

  return suspicious
    .map((p) => {
      const primaryId = firstUserMap.get(p.device_id!) ?? null;
      return {
        suspicious_id: p.id,
        suspicious_email: p.email,
        suspicious_created_at: p.created_at,
        primary_id: primaryId,
        primary_email: primaryId ? primaryMap.get(primaryId) ?? null : null,
      };
    })
    .sort(
      (a, b) =>
        new Date(b.suspicious_created_at).getTime() -
        new Date(a.suspicious_created_at).getTime()
    );
}

// === Координаты готовых домов для heatmap ===

export async function getCompletedBuildingsHeatmap(): Promise<HeatmapPoint[]> {
  const supabase = await createClient();

  const { data: completed } = await supabase
    .from('completed_buildings')
    .select('mapbox_building_id');

  if (!completed || completed.length === 0) return [];

  const buildingIds = completed.map((c) => c.mapbox_building_id);

  const { data: entrances } = await supabase
    .from('entrances')
    .select('lat, lng, mapbox_building_id')
    .in('mapbox_building_id', buildingIds);

  if (!entrances) return [];

  return entrances.map((e) => [e.lng, e.lat] as HeatmapPoint);
}
// === Активность пользователей ===

export type ActivityStats = {
  activeNow: number;
  active24h: number;
};

export async function getActivityStats(): Promise<ActivityStats> {
  const supabase = await createClient();
  const fiveMinutesAgo = new Date(Date.now() - 5 * 60 * 1000).toISOString();
  const day1 = new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString();

  const [{ count: activeNow }, { count: active24h }] = await Promise.all([
    supabase
      .from('profiles')
      .select('*', { count: 'exact', head: true })
      .gte('last_seen_at', fiveMinutesAgo),
    supabase
      .from('profiles')
      .select('*', { count: 'exact', head: true })
      .gte('last_seen_at', day1),
  ]);

  return {
    activeNow: activeNow ?? 0,
    active24h: active24h ?? 0,
  };
}