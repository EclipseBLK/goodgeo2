/**
 * Загружает SVG из public-папки и конвертирует в ImageBitmap для Mapbox.
 * Используется через map.addImage().
 */
export async function loadSvgAsImage(url: string, size = 60): Promise<ImageBitmap> {
  const response = await fetch(url);
  const svgText = await response.text();

  const svgBlob = new Blob([svgText], { type: 'image/svg+xml' });
  const objectUrl = URL.createObjectURL(svgBlob);

  const img = new Image();
  img.crossOrigin = 'anonymous';

  await new Promise<void>((resolve, reject) => {
    img.onload = () => resolve();
    img.onerror = (e) => reject(e);
    img.src = objectUrl;
  });

  // Рисуем на canvas с увеличенным размером для качества
  const canvas = document.createElement('canvas');
  const scale = 2; // ретина-качество
  canvas.width = size * scale;
  canvas.height = size * (100 / 60) * scale; // соотношение 60x100
  const ctx = canvas.getContext('2d')!;
  ctx.drawImage(img, 0, 0, canvas.width, canvas.height);

  URL.revokeObjectURL(objectUrl);

  return await createImageBitmap(canvas);
}