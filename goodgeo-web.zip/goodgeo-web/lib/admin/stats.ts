import { createClient } from '@/lib/supabase/server';

export type DashboardStats = {
  totalUsers: number;
  activeSubscriptions: number;
  onTrial: number;
  onlineNow: number;
  totalHouses: number;
};

export type RecentUser = {
  id: string;
  email: string;
  name: string | null;
  subscription_status: string;
  created_at: string;
};

export type RecentEntrance = {
  id: string;
  entrance_number: string | null;
  apt_from: number | null;
  apt_to: number | null;
  created_at: string;
  created_by: string | null;
  creator_email: string | null;
};

export async function getDashboardStats(): Promise<DashboardStats> {
  const supabase = await createClient();

  const fiveMinutesAgo = new Date(Date.now() - 5 * 60 * 1000).toISOString();

  const [
    { count: totalUsers },
    { count: activeSubscriptions },
    { count: onTrial },
    { count: onlineNow },
    { data: entrancesForGrouping },
  ] = await Promise.all([
    supabase.from('profiles').select('*', { count: 'exact', head: true }),
    supabase.from('profiles').select('*', { count: 'exact', head: true }).eq('subscription_status', 'active'),
    supabase.from('profiles').select('*', { count: 'exact', head: true }).eq('subscription_status', 'trial'),
    supabase.from('profiles').select('*', { count: 'exact', head: true }).gte('last_seen_at', fiveMinutesAgo),
    supabase.from('entrances').select('id, mapbox_building_id, address'),
  ]);

  // Считаем уникальные дома: по building_id, иначе по address, иначе каждый подъезд = свой "дом"
  const uniqueHouses = new Set(
    (entrancesForGrouping ?? []).map(
      (e) => e.mapbox_building_id ?? e.address ?? `__solo_${e.id}`
    )
  );

  return {
    totalUsers: totalUsers ?? 0,
    activeSubscriptions: activeSubscriptions ?? 0,
    onTrial: onTrial ?? 0,
    onlineNow: onlineNow ?? 0,
    totalHouses: uniqueHouses.size,
  };
}

export async function getRecentUsers(limit = 5): Promise<RecentUser[]> {
  const supabase = await createClient();

  const { data } = await supabase
    .from('profiles')
    .select('id, email, name, subscription_status, created_at')
    .order('created_at', { ascending: false })
    .limit(limit);

  return (data ?? []) as RecentUser[];
}

export async function getRecentEntrances(limit = 5): Promise<RecentEntrance[]> {
  const supabase = await createClient();

  const { data: entrances } = await supabase
    .from('entrances')
    .select('id, entrance_number, apt_from, apt_to, created_at, created_by')
    .order('created_at', { ascending: false })
    .limit(limit);

  if (!entrances || entrances.length === 0) return [];

  const creatorIds = entrances
    .map((e) => e.created_by)
    .filter((id): id is string => !!id);

  let emailsById: Record<string, string> = {};
  if (creatorIds.length > 0) {
    const { data: profiles } = await supabase
      .from('profiles')
      .select('id, email')
      .in('id', creatorIds);

    emailsById = Object.fromEntries((profiles ?? []).map((p) => [p.id, p.email]));
  }

  return entrances.map((e) => ({
    ...e,
    creator_email: e.created_by ? emailsById[e.created_by] ?? null : null,
  }));
}