import type { AptRange } from '@/app/admin/entrances/actions';

export type Entrance = {
  id: string;
  entrance_number: string | null;
  apt_from: number | null;
  apt_to: number | null;
  apt_extras: string[];
  lat: number;
  lng: number;
  mapbox_building_id: string | null;
  address: string | null;
  korpus: string | null;
  ranges?: AptRange[];
  verified_count: number;
  negative_count: number;
  is_flagged: boolean;
  created_at: string;
};

export type CompletedBuilding = {
  mapbox_building_id: string;
  completed_at: string;
};

export type User = {
  id: string;
  email: string;
  name: string | null;
  avatar_url: string | null;
  subscription_status: 'trial' | 'active' | 'expired' | 'cancelled';
  subscription_source: 'trial' | 'manual' | 'google_play' | 'app_store';
  subscription_ends_at: string | null;
  trial_ends_at: string | null;
  platform_transaction_id: string | null;
  is_blocked: boolean;
  role: 'user' | 'creator' | 'admin';
  last_seen_at: string | null;
  created_at: string;
  // Creator-фича
  client_number: string | null;
  suggestions_total_count: number;
  suggestions_approved_count: number;
  bonus_days_earned: number;
  is_creator_applied: boolean;
  creator_applied_at: string | null;
};