import createIntlMiddleware from 'next-intl/middleware';
import { type NextRequest } from 'next/server';
import { routing } from './i18n/routing';
import { updateSession } from './lib/supabase/middleware';

const intlMiddleware = createIntlMiddleware(routing);

export async function middleware(request: NextRequest) {
  // /admin/* → только Supabase auth
  if (request.nextUrl.pathname.startsWith('/admin')) {
    return await updateSession(request);
  }

  // Остальные → next-intl с локалями
  return intlMiddleware(request);
}

export const config = {
  matcher: [
    // Применяется ко всему кроме статики и API
    '/((?!api|_next|_vercel|.*\\..*).*)',
  ],
};