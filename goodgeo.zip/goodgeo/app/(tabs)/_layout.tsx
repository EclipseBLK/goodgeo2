import { Tabs } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { useTranslation } from 'react-i18next';
import { useSettings } from '../../lib/settings';
import { useIsNavigating } from '../../lib/navState';

export default function TabsLayout() {
  const { t } = useTranslation();
  const { colors } = useSettings();
  const isNavigating = useIsNavigating();

  if (isNavigating) {
    // Полностью убираем таб-бар из дерева во время навигации
    return (
      <Tabs
        screenOptions={{
          tabBarStyle: { display: 'none', height: 0, opacity: 0 },
          tabBarShowLabel: false,
          headerShown: false,
        }}
      >
        <Tabs.Screen name="index" options={{ tabBarButton: () => null }} />
        <Tabs.Screen name="search" options={{ tabBarButton: () => null }} />
        <Tabs.Screen name="profile" options={{ tabBarButton: () => null }} />
      </Tabs>
    );
  }

  return (
    <Tabs
      screenOptions={{
        tabBarStyle: { backgroundColor: colors.surface, borderTopColor: colors.border },
        tabBarActiveTintColor: colors.accent,
        tabBarInactiveTintColor: colors.textMuted,
        headerShown: false,
      }}
    >
      <Tabs.Screen
        name="index"
        options={{
          title: t('tabs.map'),
          tabBarIcon: ({ color, size }) => <Ionicons name="map" color={color} size={size} />,
        }}
      />
      <Tabs.Screen
        name="search"
        options={{
          title: t('tabs.history'),
          tabBarIcon: ({ color, size }) => <Ionicons name="time-outline" color={color} size={size} />,
        }}
      />
      <Tabs.Screen
        name="profile"
        options={{
          title: t('tabs.profile'),
          tabBarIcon: ({ color, size }) => <Ionicons name="person" color={color} size={size} />,
        }}
      />
    </Tabs>
  );
}