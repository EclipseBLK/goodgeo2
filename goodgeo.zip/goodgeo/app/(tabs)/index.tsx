import { useEffect, useMemo, useRef, useState } from 'react';
import { View, StyleSheet, Pressable, Alert, Text } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import Mapbox, { MapView, Camera, ShapeSource, SymbolLayer, LineLayer, UserLocation, Images } from '@rnmapbox/maps';
import * as Location from 'expo-location';
import { useSettings } from '../../lib/settings';
import { isNightAt } from '../../lib/sun';
import {
  useEntrancesData, findEntranceByAptNumber,
  getApproachesForEntrance, getRouteTarget, Entrance, Approach,
} from '../../lib/entrances';
import { addHistoryEntry } from '../../lib/history';
import { RouteData, TransportType, fetchRoute, findCurrentStep, snapToRoute, Step } from '../../lib/directions';
import { useTranslation } from 'react-i18next';
import { useLocalSearchParams, useRouter } from 'expo-router';
import SearchOverlay, { SearchResult } from '../../components/SearchOverlay';
import RouteSheet, { RouteSheetHandle } from '../../components/RouteSheet';
import NavigationOverlay from '../../components/NavigationOverlay';
import AddEntranceMode from '../../components/AddEntranceMode';
import { setNavigatingState } from '../../lib/navState';
import { useProfile, isCreator } from '../../lib/profile';
import { hasVerifiedEntrance, submitVerification, isCreatorEntrance } from '../../lib/verifications';
import VerificationCard from '../../components/VerificationCard';

const doorMarker = require('../../assets/door-marker.png');
const doorMarkerDim = require('../../assets/door-marker-dim.png');
const doorMarkerTarget = require('../../assets/door-marker-target.png');
const userPuck = require('../../assets/user-puck.png');

Mapbox.setAccessToken(process.env.EXPO_PUBLIC_MAPBOX_TOKEN!);

const WARSAW_CENTER: [number, number] = [21.0122, 52.2297];
const SNAP_THRESHOLD_M = 40;
const OFF_ROUTE_THRESHOLD_M = 35;
const OFF_ROUTE_GRACE_MS = 2000;
const REROUTE_DEBOUNCE_MS = 4000;
const SMOOTH_ANIMATION_MS = 1000;

export default function MapScreen() {
  const { colors, settings, setMapStyle } = useSettings();
  const styles = makeStyles(colors);

  const camera = useRef<Camera>(null);
  const sheet = useRef<RouteSheetHandle>(null);
  const mapRef = useRef<MapView>(null);

  // Профиль для роли creator
  const { profile } = useProfile();
  const userIsCreator = isCreator(profile);

  // Режим добавления подъезда (отдельно от mode чтобы не ломать существующую логику)
  const [addingEntrance, setAddingEntrance] = useState(false);

  const { t, i18n } = useTranslation();
  const [search, setSearch] = useState('');
  const { entrances, approaches } = useEntrancesData();

  const [userLoc, setUserLoc] = useState<{ lat: number; lng: number; speed: number; heading: number } | null>(null);

  type Mode =
    | { type: 'idle' }
    | {
        type: 'route_preview';
        from: { lat: number; lng: number };
        to: { lat: number; lng: number };
        title: string;
        previewRoute: RouteData | null;
        targetEntranceId: string | null;
        buildingKey: string | null;
        previewTransport: TransportType;
      }
    | {
        type: 'navigating';
        route: RouteData;
        transport: TransportType;
        destination: { lat: number; lng: number };
        targetEntranceId: string | null;
        buildingKey: string | null;
      };

  const [mode, setMode] = useState<Mode>({ type: 'idle' });
  const [navProgress, setNavProgress] = useState({ remainingM: 0, remainingS: 0, arrived: false });
 const [navClosestIdx, setNavClosestIdx] = useState(0);
  const arrivedAnnouncedRef = useRef(false);
  const [currentStep, setCurrentStep] = useState<{ step: Step; distanceToManeuver: number } | null>(null);
  const [followingUser, setFollowingUser] = useState(true);
  const [verificationDone, setVerificationDone] = useState(false);

const [layersMenuOpen, setLayersMenuOpen] = useState(false);

  // Определяем стиль карты:
  // - если autoNightMode включен и есть GPS → используем солнце
  // - иначе используем выбранный стиль
  const effectiveMapStyle = useMemo(() => {
    if (settings.autoNightMode && userLoc) {
      return isNightAt(userLoc.lat, userLoc.lng, new Date()) ? 'night' : 'day';
    }
    return settings.mapStyle;
  }, [settings.autoNightMode, settings.mapStyle, userLoc]);

  // Проверяем солнце каждые 5 минут когда autoNightMode включен
  useEffect(() => {
    if (!settings.autoNightMode) return;
    const interval = setInterval(() => {
      // useMemo пересчитает effectiveMapStyle так как Date() поменяется через зависимость
      // но мы явно дёргаем перерисовку через small state hack
      setLayersMenuOpen((s) => s); // no-op для триггера
    }, 5 * 60 * 1000); // 5 минут
    return () => clearInterval(interval);
  }, [settings.autoNightMode]);

  // Маппинг наших значений в Mapbox styleURL
  const mapStyleUrl =
    effectiveMapStyle === 'night' ? 'mapbox://styles/mapbox/dark-v11' :
    effectiveMapStyle === 'satellite' ? 'mapbox://styles/mapbox/satellite-streets-v12' :
    'mapbox://styles/mapbox/streets-v12';

  const params = useLocalSearchParams<{
    rerouteAddress?: string;
    rerouteLat?: string;
    rerouteLng?: string;
  }>();
  const router = useRouter();

  const offRouteSinceRef = useRef<number | null>(null);
  const lastRerouteAtRef = useRef<number>(0);
  const isReroutingRef = useRef(false);
  const explicitStopRef = useRef(false);

  // === Геолокация ===
  useEffect(() => {
    let watcher: Location.LocationSubscription | null = null;
    (async () => {
      const { status } = await Location.requestForegroundPermissionsAsync();
      if (status !== 'granted') return;
      watcher = await Location.watchPositionAsync(
        { accuracy: Location.Accuracy.High, distanceInterval: 5, timeInterval: 2000 },
        (pos) => {
          setUserLoc({
            lat: pos.coords.latitude,
            lng: pos.coords.longitude,
            speed: pos.coords.speed ?? 0,
            heading: pos.coords.heading ?? 0,
          });
        }
      );
    })();
    return () => { watcher?.remove(); };
  }, []);

  // === Выбор адреса из поиска ===
  const handleSelectAddress = async (result: SearchResult) => {
    if (!userLoc) {
      Alert.alert('Не удалось определить ваше положение', 'Включите геолокацию.');
      return;
    }

    let toLat = result.lat;
    let toLng = result.lng;
    let title = result.placeName;
    let targetEntranceId: string | null = null;
    let buildingKey: string | null = null;

    if (result.aptNumber) {
      const dbAddress = `${result.street} ${result.house ?? ''}`.trim();
      const entrance = findEntranceByAptNumber(
        entrances,
        dbAddress,
        result.aptNumber,
        { lat: result.lat, lng: result.lng },
        (result as any).korpus ?? null
      );
      if (entrance) {
        const entApproaches = getApproachesForEntrance(approaches, entrance.id);
        const target = getRouteTarget(entrance, entApproaches);
        toLat = target.lat;
        toLng = target.lng;
        title = `${dbAddress} · кв. ${result.aptNumber} · подъезд ${entrance.entrance_number ?? '?'}`;
        targetEntranceId = entrance.id;
        buildingKey = entrance.mapbox_building_id ?? entrance.address ?? null;
      } else {
        title = `${dbAddress} · кв. ${result.aptNumber} (подъезд не найден)`;
      }
    } else {
      const matchedEntrance = entrances.find((e) => {
        if (!e.address) return false;
        const dbAddr = e.address.toLowerCase().trim();
        const queryAddr = `${result.street} ${result.house ?? ''}`.toLowerCase().trim();
        return dbAddr === queryAddr;
      });
      if (matchedEntrance) {
        buildingKey = matchedEntrance.mapbox_building_id ?? matchedEntrance.address ?? null;
      }
    }

    // Сохраняем в историю поездок (без await — не ждём, чтобы не тормозить UX)
    addHistoryEntry({
      address: title,
      lat: toLat,
      lng: toLng,
    });

    const preview = await fetchRoute(
      { lat: userLoc.lat, lng: userLoc.lng },
      { lat: toLat, lng: toLng },
      'car',
      i18n.language
    );

    setMode({
      type: 'route_preview',
      from: { lat: userLoc.lat, lng: userLoc.lng },
      to: { lat: toLat, lng: toLng },
      title,
      previewRoute: preview,
      targetEntranceId,
      buildingKey,
      previewTransport: 'car',
    });

    sheet.current?.open(
      { lat: userLoc.lat, lng: userLoc.lng },
      { lat: toLat, lng: toLng },
      title
    );

    if (preview && camera.current) {
      const coords = preview.geometry.coordinates;
      const lngs = coords.map((c) => c[0]);
      const lats = coords.map((c) => c[1]);
      const minLng = Math.min(...lngs);
      const maxLng = Math.max(...lngs);
      const minLat = Math.min(...lats);
      const maxLat = Math.max(...lats);
      camera.current.fitBounds([minLng, minLat], [maxLng, maxLat], 80, 800);
    }
  };

  // === Перестроение из истории — ищем подъезд рядом и подсвечиваем его ===
  const rerouteFromHistory = (lat: number, lng: number, originalTitle: string) => {
    let nearestEntrance: Entrance | null = null;
    let nearestDist = 10;

    for (const e of entrances) {
      const d = haversine({ lat, lng }, { lat: e.lat, lng: e.lng });
      if (d < nearestDist) {
        nearestDist = d;
        nearestEntrance = e;
      }
    }

    if (!nearestEntrance) {
      for (const a of approaches) {
        const d = haversine({ lat, lng }, { lat: a.lat, lng: a.lng });
        if (d < 10) {
          nearestEntrance = entrances.find((e) => e.id === a.entrance_id) ?? null;
          break;
        }
      }
    }

    if (nearestEntrance && nearestEntrance.address) {
      const aptMatch = originalTitle.match(/кв\.\s*(\d+)/i);
      const apt = aptMatch ? parseInt(aptMatch[1], 10) : null;

      handleSelectAddress({
        id: `history-${Date.now()}`,
        placeName: originalTitle,
        lat: nearestEntrance.lat,
        lng: nearestEntrance.lng,
        street: nearestEntrance.address.split(' ').slice(0, -1).join(' '),
        korpus: null,
        house: nearestEntrance.address.split(' ').pop() ?? null,
        aptNumber: apt,
      });
    } else {
      handleSelectAddress({
        id: `history-${Date.now()}`,
        placeName: originalTitle,
        lat,
        lng,
        street: '',
        korpus: null,
        house: null,
        aptNumber: null,
      });
    }
  };

  // Если пришли с вкладки История — сразу строим маршрут
  useEffect(() => {
    if (!params.rerouteAddress || !params.rerouteLat || !params.rerouteLng) return;
    if (!userLoc) return;
    if (entrances.length === 0) return; // ждём загрузку подъездов

    const lat = parseFloat(params.rerouteLat);
    const lng = parseFloat(params.rerouteLng);
    if (isNaN(lat) || isNaN(lng)) return;

    // Делаем rerouteFromHistory в try/catch чтобы краш не убил приложение
    try {
      rerouteFromHistory(lat, lng, params.rerouteAddress);
    } catch (err: any) {
      console.error('rerouteFromHistory error:', err);
      Alert.alert('Ошибка', String(err?.message ?? err));
    }

    // Сбрасываем params — НЕ через router.setParams (он крашит с undefined),
    // а через router.replace на ту же страницу без параметров
    try {
      router.replace('/(tabs)');
    } catch {
      // ignore
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [params.rerouteAddress, params.rerouteLat, params.rerouteLng, userLoc, entrances, approaches]);

  useEffect(() => {
    setNavigatingState(mode.type === 'navigating');
    return () => setNavigatingState(false);
  }, [mode.type]);

  // Сбрасываем флаг "уже оповестили о прибытии" при выходе из навигации
  useEffect(() => {
    if (mode.type !== 'navigating') {
      arrivedAnnouncedRef.current = false;
    }
  }, [mode.type]);

  // === Оповещение "Вы прибыли" ===
  useEffect(() => {
    if (!navProgress.arrived) return;
    if (arrivedAnnouncedRef.current) return;
    arrivedAnnouncedRef.current = true;

    (async () => {
      try {
        const Haptics = await import('expo-haptics');
        await Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      } catch (e) {
        console.warn('Haptics failed:', e);
      }

      try {
        const { Audio } = await import('expo-av');
        await Audio.setAudioModeAsync({
          playsInSilentModeIOS: true,
          shouldDuckAndroid: true,
        });
        const { sound } = await Audio.Sound.createAsync(
          require('../../assets/arrived.mp3'),
          { shouldPlay: true, volume: 1.0 }
        );
        setTimeout(() => sound.unloadAsync().catch(() => {}), 3000);
      } catch (e) {
        console.warn('Audio failed:', e);
      }

      })();
  }, [navProgress.arrived]);

  // === Верификация: показываем карточку только для креаторских подъездов и если юзер ещё не голосовал ===
  useEffect(() => {
    if (mode.type !== 'navigating') {
      setVerificationDone(false);
      return;
    }
    if (!mode.targetEntranceId) {
      setVerificationDone(true);
      return;
    }
    const userId = profile?.id;
    if (!userId) {
      setVerificationDone(true);
      return;
    }
    setVerificationDone(false);

    // Параллельно: креаторский ли подъезд + голосовал ли уже юзер
    Promise.all([
      isCreatorEntrance(mode.targetEntranceId),
      hasVerifiedEntrance(mode.targetEntranceId, userId),
    ]).then(([isCreator, alreadyVoted]) => {
      if (!isCreator || alreadyVoted) {
        setVerificationDone(true);
      }
    });
  }, [mode.type, mode.type === 'navigating' ? mode.targetEntranceId : null, profile?.id]);

  // Не давать экрану гаснуть во время навигации
  useEffect(() => {
    if (mode.type !== 'navigating') return;

    let active = false;
    (async () => {
      const { activateKeepAwakeAsync } = await import('expo-keep-awake');
      await activateKeepAwakeAsync('goodgeo-navigation');
      active = true;
    })();

    return () => {
      if (active) {
        import('expo-keep-awake').then(({ deactivateKeepAwake }) => {
          deactivateKeepAwake('goodgeo-navigation');
        });
      }
    };
  }, [mode.type]);

  // Сбрасываем off-route трекер при выходе из навигации
  useEffect(() => {
    if (mode.type !== 'navigating') {
      offRouteSinceRef.current = null;
      isReroutingRef.current = false;
    }
  }, [mode.type]);

  // === Snap to route + off-route detection ===
  const snappedUserLoc = useMemo(() => {
    if (!userLoc) return null;
    if (mode.type !== 'navigating') return userLoc;

    const snapped = snapToRoute(userLoc, mode.route.geometry.coordinates);
    if (!snapped) return userLoc;

    if (snapped.distanceFromRoute < SNAP_THRESHOLD_M) {
      offRouteSinceRef.current = null;
      return {
        lat: snapped.lat,
        lng: snapped.lng,
        speed: userLoc.speed,
        heading: userLoc.heading,
      };
    }

    if (snapped.distanceFromRoute > OFF_ROUTE_THRESHOLD_M) {
      if (offRouteSinceRef.current === null) {
        offRouteSinceRef.current = Date.now();
      }
    }

    return userLoc;
  }, [userLoc, mode]);

  // === Плавная интерполяция позиции маячка ===
  const [smoothLoc, setSmoothLoc] = useState<{ lat: number; lng: number; heading: number } | null>(null);
  const smoothLocRef = useRef<{ lat: number; lng: number; heading: number } | null>(null);
  const animationRef = useRef<number | null>(null);

  useEffect(() => {
    if (!snappedUserLoc) return;

    const target = {
      lat: snappedUserLoc.lat,
      lng: snappedUserLoc.lng,
      heading: snappedUserLoc.heading || 0,
    };

    if (!smoothLocRef.current) {
      smoothLocRef.current = target;
      setSmoothLoc(target);
      return;
    }

    const start = smoothLocRef.current;
    const startTime = Date.now();
    // 2200мс = чуть больше интервала между GPS-апдейтами (2000мс).
    // Анимация не успевает закончиться — следующая точка приходит и плавно подхватывает.
    const duration = 2200;

    let headingDelta = target.heading - start.heading;
    if (headingDelta > 180) headingDelta -= 360;
    if (headingDelta < -180) headingDelta += 360;

    // Игнорируем мелкие шевеления heading (<8°) — это GPS-шум, а не реальный поворот.
    // Иначе стрелка постоянно подкручивается на 1-2 градуса.
    if (Math.abs(headingDelta) < 8) headingDelta = 0;

    if (animationRef.current !== null) {
      cancelAnimationFrame(animationRef.current);
    }

    const step = () => {
      const elapsed = Date.now() - startTime;
      const t = Math.min(1, elapsed / duration);
      // Линейный easing — равномерная скорость на всём пути.
      // Старый "1 - (1-t)²" замедлялся к концу, и стрелка казалась "припарковывающейся".
      const eased = t;

      const next = {
        lat: start.lat + (target.lat - start.lat) * eased,
        lng: start.lng + (target.lng - start.lng) * eased,
        heading: (start.heading + headingDelta * eased + 360) % 360,
      };

      smoothLocRef.current = next;
      setSmoothLoc(next);

      if (t < 1) {
        animationRef.current = requestAnimationFrame(step);
      } else {
        animationRef.current = null;
      }
    };

    animationRef.current = requestAnimationFrame(step);

    return () => {
      if (animationRef.current !== null) {
        cancelAnimationFrame(animationRef.current);
        animationRef.current = null;
      }
    };
  }, [snappedUserLoc]);

  // === Off-route reroute ===
  useEffect(() => {
    if (mode.type !== 'navigating') return;
    if (!userLoc) return;
    if (offRouteSinceRef.current === null) return;
    if (isReroutingRef.current) return;

    const now = Date.now();
    const offRouteFor = now - offRouteSinceRef.current;
    const sinceLastReroute = now - lastRerouteAtRef.current;

    if (offRouteFor < OFF_ROUTE_GRACE_MS) return;
    if (sinceLastReroute < REROUTE_DEBOUNCE_MS) return;

    isReroutingRef.current = true;
    lastRerouteAtRef.current = now;
    offRouteSinceRef.current = null;

    const transport = mode.transport;
    const destination = mode.destination;

    fetchRoute(
      { lat: userLoc.lat, lng: userLoc.lng },
      destination,
      transport,
      i18n.language
    ).then((newRoute) => {
      isReroutingRef.current = false;
      if (!newRoute) return;
      setMode((prev) => {
        if (prev.type !== 'navigating') return prev;
        return { ...prev, route: newRoute };
      });
    }).catch(() => {
      isReroutingRef.current = false;
    });
  }, [userLoc, mode, i18n.language]);

  const handleStart = (route: RouteData, transport: TransportType) => {
    if (mode.type !== 'route_preview') return;

    setMode({
      type: 'navigating',
      route,
      transport,
      destination: mode.to,
      targetEntranceId: mode.targetEntranceId,
      buildingKey: mode.buildingKey,
    });
    explicitStopRef.current = true;
    sheet.current?.close();

    setFollowingUser(true);
    setCurrentStep(null);

    if (userLoc && camera.current) {
      camera.current.setCamera({
        centerCoordinate: [userLoc.lng, userLoc.lat],
        zoomLevel: 18,
        pitch: 60,
        heading: userLoc.heading || 0,
        animationDuration: 1500,
      });
    }
  };

  const handleCancelOrStop = () => {
    explicitStopRef.current = true;
    sheet.current?.close();
    setMode({ type: 'idle' });
    setSearch('');
    setCurrentStep(null);
    setFollowingUser(true);
  };

  const handleSheetClose = () => {
    if (explicitStopRef.current) {
      explicitStopRef.current = false;
      return;
    }
    setMode((prev) => prev.type === 'route_preview' ? { type: 'idle' } : prev);
  };

  // === Прогресс по маршруту + плавная камера ===
  useEffect(() => {
    if (mode.type !== 'navigating') return;
    if (!snappedUserLoc) return;

    const speedKmh = snappedUserLoc.speed * 3.6;
    const distToTarget = haversine(snappedUserLoc, mode.destination);

    const coords = mode.route.geometry.coordinates;
    let closestIdx = 0;
    let closestDist = Infinity;
    for (let i = 0; i < coords.length; i++) {
      const d = haversine(snappedUserLoc, { lat: coords[i][1], lng: coords[i][0] });
      if (d < closestDist) {
        closestDist = d;
        closestIdx = i;
      }
    }

    let remainingM = closestDist;
    for (let i = closestIdx; i < coords.length - 1; i++) {
      remainingM += haversine(
        { lat: coords[i][1], lng: coords[i][0] },
        { lat: coords[i + 1][1], lng: coords[i + 1][0] }
      );
    }

    const totalMeters = mode.route.distanceMeters;
    const totalSeconds = mode.route.durationSeconds;
    const progress = totalMeters > 0 ? 1 - remainingM / totalMeters : 0;
    const remainingS = totalSeconds * Math.max(0, Math.min(1, 1 - progress));

    setNavProgress({
      remainingM,
      remainingS,
      arrived: distToTarget < 30,
    });
    setNavClosestIdx(closestIdx);

    const stepInfo = findCurrentStep(mode.route.steps, snappedUserLoc);
    if (stepInfo) {
      setCurrentStep({ step: stepInfo.step, distanceToManeuver: stepInfo.distanceToManeuver });
    }

    if (!followingUser) return;

    let zoom = 18;
    let pitch = 60;

    // Адаптивный зум по скорости (как было)
    if (distToTarget < 100) { zoom = 19.5; pitch = 0; }
else if (speedKmh < 20) { zoom = 19; pitch = 60; }
else if (speedKmh < 40) { zoom = 18.5; pitch = 60; }
else if (speedKmh < 60) { zoom = 17.5; pitch = 55; }
else if (speedKmh < 90) { zoom = 16.5; pitch = 45; }
else { zoom = 15.5; pitch = 40; }

    // === Приближение перед манёвром ===
    // Если до поворота меньше 150м и это серьёзный манёвр —
    // увеличиваем зум и уменьшаем pitch, чтобы лучше видеть улицы.
    if (currentStep) {
      const isImportantManeuver =
        currentStep.step.maneuverType === 'turn' ||
        currentStep.step.maneuverType === 'fork' ||
        currentStep.step.maneuverType === 'roundabout' ||
        currentStep.step.maneuverType === 'rotary' ||
        currentStep.step.maneuverType === 'roundabout turn' ||
        currentStep.step.maneuverType === 'merge' ||
        currentStep.step.maneuverType === 'end of road';

      if (isImportantManeuver && currentStep.distanceToManeuver < 150) {
        // Чем ближе к повороту — тем сильнее приближаем (плавный переход)
        const t = 1 - currentStep.distanceToManeuver / 150; // 0..1
        zoom = Math.max(zoom, 18 + t * 1.5); // до 19.5 на самом подъезде
        pitch = Math.max(0, pitch - t * 30); // pitch уменьшается до 30 от обычного
      }
    }

    const cameraLoc = smoothLoc ?? snappedUserLoc;
    camera.current?.setCamera({
      centerCoordinate: [cameraLoc.lng, cameraLoc.lat],
      zoomLevel: zoom,
      pitch,
      heading: cameraLoc.heading || 0,
      animationDuration: 200,
    });
  }, [smoothLoc, snappedUserLoc, mode, followingUser]);

  const recenterOnUser = () => {
    if (!userLoc) return;
    setFollowingUser(true);
    camera.current?.setCamera({
      centerCoordinate: [userLoc.lng, userLoc.lat],
      zoomLevel: 17,
      pitch: 0,
      heading: 0,
      animationDuration: 700,
    });
  };

  const handleMapTouchMove = () => {
    if (mode.type === 'navigating' && followingUser) {
      setFollowingUser(false);
    }
  };

  // Long-press на карте → построить маршрут к этой точке (без поиска подъезда)
  const handleMapLongPress = (e: any) => {
    if (mode.type === 'navigating') return; // в навигации игнорируем
    if (!userLoc) return;

    const coords = e?.geometry?.coordinates;
    if (!coords || coords.length < 2) return;
    const [lng, lat] = coords;

    handleSelectAddress({
  id: `longpress-${Date.now()}`,
  placeName: 'Точка на карте',
  lat,
  lng,
  street: '',
  house: null,
  aptNumber: null,  // нет квартиры — подъезд не ищем
  korpus: null,
});
  };


  // === Подсветка целевого подъезда ===
  const targetEntranceId =
    mode.type === 'navigating' ? mode.targetEntranceId :
    mode.type === 'route_preview' ? mode.targetEntranceId :
    null;
  const buildingKey =
    mode.type === 'navigating' ? mode.buildingKey :
    mode.type === 'route_preview' ? mode.buildingKey :
    null;

  const entranceKey = (e: Entrance) => e.mapbox_building_id ?? e.address ?? null;

  const normalEntrances = entrances.filter((e) => {
    if (!buildingKey) return true;
    return entranceKey(e) !== buildingKey;
  });

  const dimEntrances = entrances.filter((e) => {
    if (!buildingKey) return false;
    return entranceKey(e) === buildingKey && e.id !== targetEntranceId;
  });

  const targetEntrance = targetEntranceId
    ? entrances.find((e) => e.id === targetEntranceId)
    : null;

  const toFeatures = (list: Entrance[]) =>
    list.map((e) => {
      const num = e.entrance_number ?? '';
      const range = e.apt_from && e.apt_to ? `${e.apt_from}–${e.apt_to}` : (e.apt_from ? `${e.apt_from}+` : '');
      const label = range ? `${num} · ${range}` : num;
      return {
        type: 'Feature' as const,
        geometry: { type: 'Point' as const, coordinates: [e.lng, e.lat] },
        properties: { id: e.id, label },
      };
    });

  const normalGeoJson = { type: 'FeatureCollection' as const, features: toFeatures(normalEntrances) };
  const dimGeoJson = { type: 'FeatureCollection' as const, features: toFeatures(dimEntrances) };
  const targetGeoJson = targetEntrance
    ? { type: 'FeatureCollection' as const, features: toFeatures([targetEntrance]) }
    : { type: 'FeatureCollection' as const, features: [] };

  const previewRouteGeoJson = mode.type === 'route_preview' && mode.previewRoute
    ? { type: 'Feature' as const, geometry: mode.previewRoute.geometry, properties: {} }
    : null;

  const previewDashedToDoor =
    mode.type === 'route_preview' &&
    mode.previewRoute &&
    mode.previewRoute.geometry.coordinates.length > 0 &&
    mode.targetEntranceId
      ? (() => {
          const targetEnt = entrances.find((e) => e.id === mode.targetEntranceId);
          if (!targetEnt) return null;
          const entApproaches = getApproachesForEntrance(approaches, targetEnt.id);
          if (entApproaches.length === 0) return null;
          const lastRouteCoord =
            mode.previewRoute.geometry.coordinates[mode.previewRoute.geometry.coordinates.length - 1];
          const coords: [number, number][] = [lastRouteCoord];
          for (const a of entApproaches) coords.push([a.lng, a.lat]);
          coords.push([targetEnt.lng, targetEnt.lat]);
          return {
            type: 'Feature' as const,
            geometry: { type: 'LineString' as const, coordinates: coords },
            properties: {},
          };
        })()
      : null;

  // Отрезаем пройденную часть маршрута: от текущей позиции маячка до конца
  const navRouteGeoJson = mode.type === 'navigating'
    ? (() => {
        const allCoords = mode.route.geometry.coordinates;
        // Координаты от ближайшей точки до конца
        const remainingCoords = allCoords.slice(navClosestIdx);
        // Если есть позиция маячка — добавляем её первой точкой,
        // чтобы линия начиналась под стрелкой, а не «отставала»
        const startCoord: [number, number] | null =
          smoothLoc ? [smoothLoc.lng, smoothLoc.lat] : null;
        const finalCoords: [number, number][] = startCoord
          ? [startCoord, ...remainingCoords]
          : remainingCoords;

        if (finalCoords.length < 2) return null;

        return {
          type: 'Feature' as const,
          geometry: { type: 'LineString' as const, coordinates: finalCoords },
          properties: {},
        };
      })()
    : null;

  const buildDashedCoords = (): [number, number][] | null => {
    if (mode.type !== 'navigating') return null;
    if (mode.route.geometry.coordinates.length === 0) return null;

    const targetEnt = mode.targetEntranceId
      ? entrances.find((e) => e.id === mode.targetEntranceId)
      : null;

    if (!targetEnt) {
      const lastRouteCoord = mode.route.geometry.coordinates[mode.route.geometry.coordinates.length - 1];
      return [lastRouteCoord, [mode.destination.lng, mode.destination.lat]];
    }

    const entApproaches = getApproachesForEntrance(approaches, targetEnt.id);
    const lastRouteCoord = mode.route.geometry.coordinates[mode.route.geometry.coordinates.length - 1];
    const coords: [number, number][] = [lastRouteCoord];
    for (const a of entApproaches) coords.push([a.lng, a.lat]);
    coords.push([targetEnt.lng, targetEnt.lat]);
    return coords;
  };

  const dashedCoords = buildDashedCoords();
  const dashedToDoor = dashedCoords
    ? {
        type: 'Feature' as const,
        geometry: { type: 'LineString' as const, coordinates: dashedCoords },
        properties: {},
      }
    : null;

  const activeRouteColor = routeColorForTransport(
    mode.type === 'navigating' ? mode.transport :
    mode.type === 'route_preview' ? mode.previewTransport : 'car'
  );

  return (
    <View style={styles.container}>
      <MapView
      ref={mapRef}
        style={styles.map}
        styleURL={mapStyleUrl}
        compassEnabled
        scaleBarEnabled={false}
        onTouchMove={handleMapTouchMove}
        onLongPress={handleMapLongPress}
      >
        <Camera
          ref={camera}
          defaultSettings={{ centerCoordinate: WARSAW_CENTER, zoomLevel: 12 }}
          followUserLocation={false}
        />

        {mode.type !== 'navigating' && (
          <UserLocation visible androidRenderMode="normal" />
        )}

        <Images
          images={{
            door: doorMarker,
            doorDim: doorMarkerDim,
            doorTarget: doorMarkerTarget,
            userPuck: userPuck,
          }}
        />

        <ShapeSource id="entrances-normal" shape={normalGeoJson}>
          <SymbolLayer
            id="entrances-normal-layer"
            minZoomLevel={18}
            style={{
              iconImage: 'door',
              iconSize: 0.18,
              iconAllowOverlap: true,
              iconAnchor: 'bottom',
              textField: ['get', 'label'],
              textSize: 11,
              textColor: '#dc2626',
              textHaloColor: '#fff',
              textHaloWidth: 1.5,
              textAnchor: 'top',
              textOffset: [0, 0.3],
            }}
          />
        </ShapeSource>

        <ShapeSource id="entrances-dim" shape={dimGeoJson}>
          <SymbolLayer
            id="entrances-dim-layer"
            minZoomLevel={18}
            style={{
              iconImage: 'doorDim',
              iconSize: 0.18,
              iconAllowOverlap: true,
              iconAnchor: 'bottom',
              textField: ['get', 'label'],
              textSize: 11,
              textColor: '#dc2626',
              textOpacity: 0.4,
              textHaloColor: '#fff',
              textHaloWidth: 1.5,
              textAnchor: 'top',
              textOffset: [0, 0.3],
            }}
          />
        </ShapeSource>

        {/* Зелёная заливка целевого здания через composite source Mapbox */}
        {buildingKey && (
          <Mapbox.VectorSource
            id="mapbox-streets-v8"
            url="mapbox://mapbox.mapbox-streets-v8"
          >
            <Mapbox.FillLayer
              id="target-building-fill"
              sourceID="mapbox-streets-v8"
              sourceLayerID="building"
              minZoomLevel={14}
              filter={['==', ['id'], buildingKey] as any}
              style={{
                fillColor: '#22c55e',
                fillOpacity: 0.5,
                fillOutlineColor: '#16a34a',
              }}
            />
          </Mapbox.VectorSource>
        )}

        <ShapeSource id="entrances-target" shape={targetGeoJson}>
          <SymbolLayer
            id="entrances-target-layer"
            minZoomLevel={17}
            style={{
              iconImage: 'doorTarget',
              iconSize: 0.22,
              iconAllowOverlap: true,
              iconAnchor: 'bottom',
              textField: ['get', 'label'],
              textSize: 13,
              textColor: '#dc2626',
              textHaloColor: '#fff',
              textHaloWidth: 2,
              textAnchor: 'top',
              textOffset: [0, 0.3],
            }}
          />
        </ShapeSource>

        {previewRouteGeoJson && (
          <ShapeSource id="preview-route-source" shape={previewRouteGeoJson}>
            <LineLayer
              id="preview-route-casing"
              style={{
                lineColor: '#ffffff',
                lineWidth: ['interpolate', ['linear'], ['zoom'], 14, 6, 18, 14, 20, 18] as any,
                lineCap: 'round',
                lineJoin: 'round',
                lineOpacity: 0.85,
              }}
            />
            <LineLayer
              id="preview-route-layer"
              style={{
                lineColor: activeRouteColor,
                lineWidth: ['interpolate', ['linear'], ['zoom'], 14, 4, 18, 10, 20, 14] as any,
                lineCap: 'round',
                lineJoin: 'round',
                lineOpacity: 0.85,
              }}
            />
          </ShapeSource>
        )}

        {navRouteGeoJson && (
          <ShapeSource id="nav-route-source" shape={navRouteGeoJson}>
            <LineLayer
              id="nav-route-casing"
              style={{
                lineColor: '#ffffff',
                lineWidth: ['interpolate', ['linear'], ['zoom'], 14, 6, 18, 14, 20, 18] as any,
                lineCap: 'round',
                lineJoin: 'round',
              }}
            />
            <LineLayer
              id="nav-route-layer"
              style={{
                lineColor: activeRouteColor,
                lineWidth: ['interpolate', ['linear'], ['zoom'], 14, 4, 18, 10, 20, 14] as any,
                lineCap: 'round',
                lineJoin: 'round',
              }}
            />
          </ShapeSource>
        )}

        {dashedToDoor && (
          <ShapeSource id="dashed-source" shape={dashedToDoor}>
            <LineLayer
              id="dashed-layer"
              style={{
                lineColor: '#dc2626',
                lineWidth: 3,
                lineDasharray: [2, 2],
              }}
            />
          </ShapeSource>
        )}

        {previewDashedToDoor && (
          <ShapeSource id="preview-dashed-source" shape={previewDashedToDoor}>
            <LineLayer
              id="preview-dashed-layer"
              style={{
                lineColor: '#dc2626',
                lineWidth: 3,
                lineDasharray: [2, 2],
                lineOpacity: 0.85,
              }}
            />
          </ShapeSource>
        )}

        {mode.type === 'navigating' && smoothLoc && (
          <ShapeSource
            id="user-puck-source"
            shape={{
              type: 'Feature',
              properties: { heading: smoothLoc.heading },
              geometry: {
                type: 'Point',
                coordinates: [smoothLoc.lng, smoothLoc.lat],
              },
            }}
          >
            <SymbolLayer
              id="user-puck-layer"
              style={{
                iconImage: 'userPuck',
                iconSize: 0.35,
                iconAllowOverlap: true,
                iconIgnorePlacement: true,
                iconRotate: ['get', 'heading'],
                iconRotationAlignment: 'map',
                iconPitchAlignment: 'map',
              }}
            />
          </ShapeSource>
        )}
      </MapView>

      {mode.type === 'idle' && (
        <SearchOverlay value={search} onChange={setSearch} onSelect={handleSelectAddress} />
      )}

      {mode.type === 'navigating' && (
        <NavigationOverlay
          remainingMeters={navProgress.remainingM}
          remainingSeconds={navProgress.remainingS}
          totalMeters={mode.route.distanceMeters}
          arrivedAtBuilding={navProgress.arrived}
          maneuverType={currentStep?.step.maneuverType}
          maneuverModifier={currentStep?.step.maneuverModifier}
          maneuverInstruction={currentStep?.step.instruction}
          distanceToManeuver={currentStep?.distanceToManeuver}
          followingUser={followingUser}
          onRecenter={recenterOnUser}
          onStop={handleCancelOrStop}
        />
      )}

      {mode.type === 'navigating' &&
        navProgress.arrived &&
        mode.targetEntranceId &&
        !verificationDone &&
        profile?.id && (
          <View style={styles.verificationWrap} pointerEvents="box-none">
            <VerificationCard
              onVote={async (vote) => {
                const ok = await submitVerification(mode.targetEntranceId!, profile.id, vote);
                setVerificationDone(true);
                if (!ok) {
                  console.warn('Голос не отправлен');
                }
              }}
              onClose={() => setVerificationDone(true)}
            />
          </View>
        )}

      {mode.type !== 'navigating' && (
        <>
          {/* Меню слоёв (если открыто) */}
          {layersMenuOpen ? (
            <View style={styles.layersMenu}>
              <Pressable
                onPress={() => { setMapStyle('day'); setLayersMenuOpen(false); }}
                style={effectiveMapStyle === 'day' ? [styles.layerOption, { backgroundColor: colors.accent }] : styles.layerOption}
              >
                <Ionicons name="sunny" size={20} color={effectiveMapStyle === 'day' ? '#fff' : colors.text} />
                <Text style={{ fontSize: 14, color: effectiveMapStyle === 'day' ? '#fff' : colors.text }}>{t('settings.mapDay')}</Text>
              </Pressable>
              <Pressable
                onPress={() => { setMapStyle('night'); setLayersMenuOpen(false); }}
                style={effectiveMapStyle === 'night' ? [styles.layerOption, { backgroundColor: colors.accent }] : styles.layerOption}
              >
                <Ionicons name="moon" size={20} color={effectiveMapStyle === 'night' ? '#fff' : colors.text} />
                <Text style={{ fontSize: 14, color: effectiveMapStyle === 'night' ? '#fff' : colors.text }}>{t('settings.mapNight')}</Text>
              </Pressable>
              <Pressable
                onPress={() => { setMapStyle('satellite'); setLayersMenuOpen(false); }}
                style={effectiveMapStyle === 'satellite' ? [styles.layerOption, { backgroundColor: colors.accent }] : styles.layerOption}
              >
                <Ionicons name="globe" size={20} color={effectiveMapStyle === 'satellite' ? '#fff' : colors.text} />
                <Text style={{ fontSize: 14, color: effectiveMapStyle === 'satellite' ? '#fff' : colors.text }}>{t('settings.mapSatellite')}</Text>
              </Pressable>
            </View>
          ) : null}

          {/* FAB "Слои" */}
          <Pressable
            onPress={() => setLayersMenuOpen((v) => !v)}
            style={styles.layersButton}
          >
            <Ionicons
              name={layersMenuOpen ? 'close' : 'albums'}
              size={22}
              color={colors.accent}
            />
          </Pressable>

          {/* FAB "Найти меня" */}
          <Pressable onPress={recenterOnUser} style={styles.locateButton}>
            <Ionicons name="locate" size={22} color={colors.accent} />
          </Pressable>

          {/* FAB "Добавить подъезд" — только creator/admin */}
          {userIsCreator && mode.type === 'idle' && !addingEntrance && (
            <Pressable
              onPress={() => setAddingEntrance(true)}
              style={styles.addEntranceFab}
            >
              <Ionicons name="add" size={28} color="#fff" />
            </Pressable>
          )}
        </>
      )}

      {/* Режим добавления подъезда */}
      {addingEntrance && (
        <AddEntranceMode
          getCenterCoords={async () => {
            try {
              const center = await mapRef.current?.getCenter();
              if (!center) return null;
              return { lng: center[0], lat: center[1] };
            } catch {
              return null;
            }
          }}
          onClose={() => setAddingEntrance(false)}
          onSubmitted={() => {
            // Можно перезагрузить подъезды если хочется обновить карту
          }}
        />
      )}

      <RouteSheet
        ref={sheet}
        onStartNavigation={handleStart}
        onClose={handleSheetClose}
        onTransportChange={(transport, route) => {
          setMode((prev) =>
            prev.type === 'route_preview'
              ? { ...prev, previewTransport: transport, previewRoute: route ?? prev.previewRoute }
              : prev
          );
        }}
      />
    </View>
  );
}

function routeColorForTransport(transport: TransportType): string {
  if (transport === 'bicycle') return '#10b981';
  return '#3b82f6';
}

function haversine(a: { lat: number; lng: number }, b: { lat: number; lng: number }): number {
  const R = 6371000;
  const toRad = (deg: number) => (deg * Math.PI) / 180;
  const dLat = toRad(b.lat - a.lat);
  const dLng = toRad(b.lng - a.lng);
  const lat1 = toRad(a.lat);
  const lat2 = toRad(b.lat);
  const x =
    Math.sin(dLat / 2) ** 2 + Math.sin(dLng / 2) ** 2 * Math.cos(lat1) * Math.cos(lat2);
  return 2 * R * Math.asin(Math.sqrt(x));
}


const makeStyles = (colors: any) =>
  StyleSheet.create({
    container: { flex: 1, backgroundColor: colors.background },
    map: { flex: 1 },
    locateButton: {
      position: 'absolute',
      bottom: 100,
      right: 16,
      width: 48,
      height: 48,
      borderRadius: 24,
      backgroundColor: colors.surface,
      justifyContent: 'center',
      alignItems: 'center',
      elevation: 4,
      shadowColor: '#000',
      shadowOpacity: 0.3,
      shadowRadius: 4,
      shadowOffset: { width: 0, height: 2 },
    },
    addEntranceFab: {
      position: 'absolute',
      bottom: 32,
      right: 16,
      width: 56,
      height: 56,
      borderRadius: 28,
      backgroundColor: colors.accent,
      justifyContent: 'center',
      alignItems: 'center',
      elevation: 8,
      shadowColor: '#000',
      shadowOpacity: 0.4,
      shadowRadius: 6,
      shadowOffset: { width: 0, height: 3 },
    },
    layersButton: {
      position: 'absolute',
      bottom: 160, // выше locateButton (100 + 48 + ~12)
      right: 16,
      width: 48,
      height: 48,
      borderRadius: 24,
      backgroundColor: colors.surface,
      justifyContent: 'center',
      alignItems: 'center',
      elevation: 4,
      shadowColor: '#000',
      shadowOpacity: 0.3,
      shadowRadius: 4,
      shadowOffset: { width: 0, height: 2 },
    },
   verificationWrap: {
    position: 'absolute',
    left: 16,
    right: 16,
    bottom: 220, // выше всей панели NavigationOverlay
    zIndex: 100,
  },
    layersMenu: {
      position: 'absolute',
      bottom: 160,
      right: 76, // справа от FAB слоёв
      backgroundColor: colors.surface,
      borderRadius: 12,
      paddingVertical: 6,
      elevation: 6,
      shadowColor: '#000',
      shadowOpacity: 0.3,
      shadowRadius: 6,
      shadowOffset: { width: 0, height: 2 },
      minWidth: 140,
    },
    layerOption: {
      flexDirection: 'row',
      alignItems: 'center',
      gap: 12,
      paddingVertical: 10,
      paddingHorizontal: 14,
      marginVertical: 2,
      marginHorizontal: 4,
      borderRadius: 8,
    },
    layerOptionLabel: {
      fontSize: 14,
      fontWeight: '500',
    },
  });