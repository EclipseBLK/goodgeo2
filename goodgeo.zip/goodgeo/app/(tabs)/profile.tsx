import { useState } from 'react';
import {
  View,
  Text,
  Pressable,
  StyleSheet,
  ScrollView,
  ActivityIndicator,
  Alert,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { router } from 'expo-router';
import { useTranslation } from 'react-i18next';
import { supabase } from '../../lib/supabase';
import { useProfile, getDaysLeft, isCreator, getNextBonusIn } from '../../lib/profile';
import { useStats } from '../../lib/stats';
import { useSettings } from '../../lib/settings';
import { pluralKey } from '../../lib/plural';
import { applyForCreator } from '../../lib/suggestions';

// Цвет цифр в карточках метрик. Бренд-синий, осветлённый для тёмной темы.
const METRIC_BLUE = '#5B8DC9';

export default function ProfileScreen() {
  const { t } = useTranslation();
  const { colors, settings } = useSettings();
  const { profile, loading, refetch } = useProfile();
  const { stats } = useStats(profile?.created_at);
  const styles = makeStyles(colors);
  const [applying, setApplying] = useState(false);

  if (loading) {
    return (
      <View style={[styles.container, styles.center]}>
        <ActivityIndicator size="large" color={colors.accent} />
      </View>
    );
  }

  if (!profile) {
    return (
      <View style={[styles.container, styles.center]}>
        <Text style={{ color: colors.textMuted }}>{t('profile.notLoaded')}</Text>
      </View>
    );
  }

  // Для триала — отсчёт от trial_ends_at (всего 7 дней)
  // Для активной подписки — от subscription_ends_at (месячный цикл = 30 дней)
  const isActive = profile.subscription_status === 'active';
  const endsAt = isActive ? profile.subscription_ends_at : profile.trial_ends_at;
  const daysLeft = getDaysLeft(endsAt);
  const totalDays = isActive ? 30 : 7;
  const showProgress =
    (profile.subscription_status === 'trial' || isActive) && daysLeft > 0;
  const progressPct = Math.max(0, Math.min(100, (daysLeft / totalDays) * 100));

  const userIsCreator = isCreator(profile);

  const handleApplyForCreator = async () => {
    setApplying(true);
    const res = await applyForCreator();
    setApplying(false);

    if (res.error) {
      const errorMsg =
        res.error === 'already_applied'
          ? t('creator.applyAlreadySent', 'Заявка уже отправлена')
          : res.error === 'already_creator'
          ? t('creator.applyAlreadyCreator', 'У вас уже есть права')
          : t('creator.applyError', 'Не удалось отправить заявку');
      Alert.alert('', errorMsg);
      return;
    }

    Alert.alert(
      t('creator.applyDoneTitle', 'Заявка отправлена'),
      t(
        'creator.applyDoneText',
        'Мы рассмотрим её в ближайшее время и сообщим о решении.'
      )
    );
    refetch();
  };

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView contentContainerStyle={{ padding: 16 }}>
        {/* === Шапка: аватар по центру === */}
        <View style={styles.header}>
          <View style={styles.avatar}>
            <Ionicons name="person" size={40} color={colors.text} />
          </View>
          <Text style={styles.name}>{profile.name ?? t('profile.noName')}</Text>
          <Text style={styles.email}>{profile.email}</Text>

          {/* ID курьера */}
          {profile.client_number && (
            <View style={styles.clientIdRow}>
              <Text style={styles.clientIdLabel}>
                {t('profile.clientId', 'ID')}
              </Text>
              <Text style={styles.clientIdValue}>{profile.client_number}</Text>
            </View>
          )}
        </View>

        {/* === 3 метрики в карточках === */}
        <View style={styles.metricsGrid}>
          <View style={styles.metricCard}>
            <Text style={styles.metricNum}>{stats.visitedToday}</Text>
            <Text style={styles.metricLabel}>
              {t('profile.stats.tripsToday', 'Поездок\nза 24 ч.')}
            </Text>
          </View>
          <View style={styles.metricCard}>
            <Text style={styles.metricNum}>{stats.visitedTotal}</Text>
            <Text style={styles.metricLabel}>
              {t('profile.stats.tripsTotal', 'Всего\nпоездок')}
            </Text>
          </View>
          <View style={styles.metricCard}>
            <Text style={styles.metricNum}>{stats.daysInApp}</Text>
            <Text style={styles.metricLabel}>
              {t('profile.stats.daysWithUs', 'Дней\nс нами')}
            </Text>
          </View>
        </View>

        {/* === Creator-секция === */}
        {userIsCreator ? (
          <CreatorStatsBlock profile={profile} colors={colors} styles={styles} t={t} />
        ) : profile.is_creator_applied ? (
          <View style={styles.creatorPendingCard}>
            <Ionicons name="hourglass-outline" size={24} color={colors.accent} />
            <View style={{ flex: 1, marginLeft: 12 }}>
              <Text style={styles.creatorPendingTitle}>
                {t('creator.pendingTitle', 'Заявка на проверке')}
              </Text>
              <Text style={styles.creatorPendingText}>
                {t(
                  'creator.pendingText',
                  'Мы рассмотрим её в ближайшее время.'
                )}
              </Text>
            </View>
          </View>
        ) : (
          <Pressable
            style={styles.creatorApplyCard}
            onPress={handleApplyForCreator}
            disabled={applying}
          >
            <Ionicons name="sparkles" size={24} color={colors.accent} />
            <View style={{ flex: 1, marginLeft: 12 }}>
              <Text style={styles.creatorApplyTitle}>
                {t('creator.applyTitle', 'Стать Creator')}
              </Text>
              <Text style={styles.creatorApplyText}>
                {t(
                  'creator.applyText',
                  'Помогайте дополнять базу подъездов и получайте бонусные дни подписки.'
                )}
              </Text>
            </View>
            {applying ? (
              <ActivityIndicator color={colors.accent} />
            ) : (
              <Ionicons name="chevron-forward" size={22} color={colors.text} />
            )}
          </Pressable>
        )}

        {/* === Подписка === */}
        <Pressable
          style={styles.subscriptionCard}
          onPress={() => router.push('/subscription')}
        >
          <View style={styles.subscriptionRow}>
            <View style={{ flex: 1 }}>
              <Text style={styles.cardTitle}>{t('profile.subscription')}</Text>
              <Text style={styles.cardStatus}>
                {getStatusLabel(profile.subscription_status, daysLeft, settings.language, t)}
              </Text>
            </View>
            <Ionicons name="chevron-forward" size={24} color={colors.text} />
          </View>

          {showProgress && (
            <>
              <View style={styles.subscriptionProgressLabels}>
                <Text style={styles.subscriptionProgressText}>
                  {t('profile.subscription.daysLeftLabel', 'Осталось')}
                </Text>
                <Text style={styles.subscriptionProgressCount}>
                  {daysLeft} / {totalDays} {t(`days.${pluralKey(daysLeft, settings.language)}`)}
                </Text>
              </View>
              <View style={styles.subscriptionProgress}>
                <View
                  style={[styles.subscriptionProgressFill, { width: `${progressPct}%` }]}
                />
              </View>
            </>
          )}
        </Pressable>

        {/* === Меню === */}
        <MenuItem
          icon="trophy-outline"
          title={t('profile.leaderboard', 'Рейтинг')}
          onPress={() => router.push('/leaderboard')}
          colors={colors}
          styles={styles}
        />
        <MenuItem
          icon="settings-outline"
          title={t('profile.settings')}
          onPress={() => router.push('/settings')}
          colors={colors}
          styles={styles}
        />
        <MenuItem
          icon="help-circle-outline"
          title={t('profile.help')}
          onPress={() => {}}
          colors={colors}
          styles={styles}
        />
        <MenuItem
          icon="log-out-outline"
          title={t('profile.logout')}
          onPress={async () => {
            await supabase.auth.signOut();
          }}
          danger
          colors={colors}
          styles={styles}
        />
      </ScrollView>
    </SafeAreaView>
  );
}

// =====================================================
// === БЛОК СТАТИСТИКИ CREATOR ===
// =====================================================

function CreatorStatsBlock({ profile, colors, styles, t }: any) {
  const approved = profile.suggestions_approved_count ?? 0;
  const total = profile.suggestions_total_count ?? 0;
  const bonus = profile.bonus_days_earned ?? 0;
  const progressPct = ((approved % 10) / 10) * 100;

  return (
    <View style={styles.creatorCard}>
      <View style={styles.creatorHeader}>
        <View style={styles.creatorBadge}>
          <Ionicons name="sparkles" size={14} color={colors.accent} />
          <Text style={styles.creatorBadgeText}>
            {profile.role === 'admin' ? 'ADMIN' : 'CREATOR'}
          </Text>
        </View>
      </View>

      <View style={styles.creatorStatsRow}>
        <View style={styles.creatorStatBox}>
          <Text style={styles.creatorStatValue}>{approved}</Text>
          <Text style={styles.creatorStatLabel}>
            {t('creator.statApproved', 'Принято')}
          </Text>
          {total > approved && (
            <Text style={styles.creatorStatSub}>
              {t('creator.statOf', 'из')} {total}
            </Text>
          )}
        </View>

        <View style={styles.creatorStatDivider} />

        <View style={styles.creatorStatBox}>
          <Text style={[styles.creatorStatValue, { color: '#2DB8A8' }]}>
            +{bonus}
          </Text>
          <Text style={styles.creatorStatLabel}>
            {t('creator.statBonus', 'Бонус. дней')}
          </Text>
        </View>
      </View>

      <View style={styles.creatorProgressBlock}>
        <View style={styles.creatorProgressLabels}>
          <Text style={styles.creatorProgressTitle}>
            {t('creator.nextBonus', 'До следующего бонуса')}
          </Text>
          <Text style={styles.creatorProgressCount}>
            {approved % 10} / 10
          </Text>
        </View>
        <View style={styles.creatorProgressTrack}>
          <View
            style={[styles.creatorProgressFill, { width: `${progressPct}%` }]}
          />
        </View>
      </View>
    </View>
  );
}

// =====================================================
// === ВСПОМОГАТЕЛЬНЫЕ КОМПОНЕНТЫ ===
// =====================================================

function getStatusLabel(status: string, daysLeft: number, lang: any, t: any): string {
  switch (status) {
    case 'trial':
      if (daysLeft <= 0) return t('profile.status.trialExpired');
      return t('profile.status.trial', {
        days: daysLeft,
        unit: t(`days.${pluralKey(daysLeft, lang)}`),
      });
    case 'active':
      return t('profile.status.active');
    case 'expired':
      return t('profile.status.expired');
    case 'cancelled':
      return t('profile.status.cancelled');
    default:
      return status;
  }
}

function MenuItem({ icon, title, onPress, danger, colors, styles }: any) {
  return (
    <Pressable style={styles.menuItem} onPress={onPress}>
      <Ionicons name={icon} size={22} color={danger ? colors.error : colors.text} />
      <Text style={[styles.menuText, danger && { color: colors.error }]}>{title}</Text>
      <Ionicons name="chevron-forward" size={20} color={colors.textMuted} />
    </Pressable>
  );
}

// =====================================================
// === СТИЛИ ===
// =====================================================

const makeStyles = (colors: any) =>
  StyleSheet.create({
    container: { flex: 1, backgroundColor: colors.background },
    center: { justifyContent: 'center', alignItems: 'center' },
    header: { alignItems: 'center', marginBottom: 16, marginTop: 16 },
    avatar: {
      width: 80,
      height: 80,
      borderRadius: 40,
      backgroundColor: colors.accent,
      justifyContent: 'center',
      alignItems: 'center',
      marginBottom: 12,
    },
    name: { fontSize: 20, fontWeight: '600', color: colors.text },
    email: { color: colors.textMuted, marginTop: 4 },

    clientIdRow: {
      flexDirection: 'row',
      alignItems: 'center',
      gap: 8,
      marginTop: 10,
      paddingHorizontal: 12,
      paddingVertical: 4,
      backgroundColor: colors.surface,
      borderRadius: 8,
    },
    clientIdLabel: {
      color: colors.textMuted,
      fontSize: 11,
      fontWeight: '500',
    },
    clientIdValue: {
      color: colors.accent,
      fontSize: 14,
      fontWeight: '600',
      fontFamily: 'monospace',
      letterSpacing: 1.5,
    },

    // === Метрики (3 карточки) ===
    metricsGrid: {
      flexDirection: 'row',
      gap: 8,
      marginBottom: 12,
    },
    metricCard: {
      flex: 1,
      backgroundColor: colors.surface,
      borderRadius: 14,
      paddingVertical: 14,
      paddingHorizontal: 8,
      alignItems: 'center',
    },
    metricNum: {
      fontSize: 24,
      fontWeight: '700',
      color: METRIC_BLUE,
      lineHeight: 28,
    },
    metricLabel: {
      color: colors.textMuted,
      fontSize: 11,
      marginTop: 6,
      textAlign: 'center',
      lineHeight: 14,
    },

    // === Creator card ===
    creatorCard: {
      backgroundColor: colors.surface,
      borderRadius: 12,
      padding: 16,
      marginBottom: 12,
      borderWidth: 1,
      borderColor: colors.accent + '40',
    },
    creatorHeader: { marginBottom: 14 },
    creatorBadge: {
      flexDirection: 'row',
      alignItems: 'center',
      alignSelf: 'flex-start',
      gap: 4,
      paddingHorizontal: 8,
      paddingVertical: 3,
      backgroundColor: colors.accent + '20',
      borderRadius: 6,
    },
    creatorBadgeText: {
      color: colors.accent,
      fontSize: 11,
      fontWeight: '700',
      letterSpacing: 0.5,
    },
    creatorStatsRow: {
      flexDirection: 'row',
      alignItems: 'center',
      marginBottom: 14,
    },
    creatorStatBox: { flex: 1, alignItems: 'center' },
    creatorStatValue: {
      color: colors.text,
      fontSize: 24,
      fontWeight: '700',
    },
    creatorStatLabel: {
      color: colors.textMuted,
      fontSize: 11,
      marginTop: 2,
    },
    creatorStatSub: {
      color: colors.textMuted,
      fontSize: 10,
      marginTop: 1,
      opacity: 0.6,
    },
    creatorStatDivider: { width: 1, height: 36, backgroundColor: colors.border },
    creatorProgressBlock: {},
    creatorProgressLabels: {
      flexDirection: 'row',
      justifyContent: 'space-between',
      marginBottom: 6,
    },
    creatorProgressTitle: {
      color: colors.textMuted,
      fontSize: 12,
    },
    creatorProgressCount: {
      color: colors.text,
      fontSize: 12,
      fontWeight: '600',
    },
    creatorProgressTrack: {
      height: 4,
      backgroundColor: colors.border,
      borderRadius: 2,
      overflow: 'hidden',
    },
    creatorProgressFill: {
      height: '100%',
      backgroundColor: '#2DB8A8',
      borderRadius: 2,
    },

    // === Apply card ===
    creatorApplyCard: {
      flexDirection: 'row',
      alignItems: 'center',
      backgroundColor: colors.surface,
      borderRadius: 12,
      padding: 14,
      marginBottom: 12,
      borderWidth: 1,
      borderColor: colors.accent + '60',
      borderStyle: 'dashed',
    },
    creatorApplyTitle: {
      color: colors.text,
      fontSize: 15,
      fontWeight: '600',
      marginBottom: 2,
    },
    creatorApplyText: {
      color: colors.textMuted,
      fontSize: 12,
      lineHeight: 16,
    },

    // === Pending card ===
    creatorPendingCard: {
      flexDirection: 'row',
      alignItems: 'center',
      backgroundColor: colors.surface,
      borderRadius: 12,
      padding: 14,
      marginBottom: 12,
      borderWidth: 1,
      borderColor: colors.border,
    },
    creatorPendingTitle: {
      color: colors.text,
      fontSize: 14,
      fontWeight: '600',
    },
    creatorPendingText: {
      color: colors.textMuted,
      fontSize: 12,
      marginTop: 2,
      lineHeight: 16,
    },

    subscriptionCard: {
      backgroundColor: colors.surface,
      borderRadius: 12,
      padding: 16,
      marginBottom: 16,
      borderWidth: 1,
      borderColor: colors.accent,
    },
    subscriptionRow: {
      flexDirection: 'row',
      justifyContent: 'space-between',
      alignItems: 'center',
    },
    subscriptionProgressLabels: {
      flexDirection: 'row',
      justifyContent: 'space-between',
      alignItems: 'baseline',
      marginTop: 12,
      marginBottom: 6,
    },
    subscriptionProgressText: {
      color: colors.textMuted,
      fontSize: 12,
    },
    subscriptionProgressCount: {
      color: colors.text,
      fontSize: 12,
      fontWeight: '600',
    },
    subscriptionProgress: {
      height: 4,
      backgroundColor: colors.border,
      borderRadius: 2,
      overflow: 'hidden',
    },
    subscriptionProgressFill: {
      height: '100%',
      backgroundColor: colors.accent,
      borderRadius: 2,
    },
    cardTitle: { color: colors.text, fontSize: 16, fontWeight: '600' },
    cardStatus: { color: colors.accent, marginTop: 4 },
    menuItem: {
      flexDirection: 'row',
      alignItems: 'center',
      paddingVertical: 16,
      paddingHorizontal: 12,
      gap: 16,
      borderBottomWidth: 1,
      borderBottomColor: colors.border,
    },
    menuText: { flex: 1, color: colors.text, fontSize: 16 },
  });