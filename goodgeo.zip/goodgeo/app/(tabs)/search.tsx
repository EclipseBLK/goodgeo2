import { useEffect, useCallback } from 'react';
import { View, Text, StyleSheet, FlatList, Pressable, ActivityIndicator } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useFocusEffect, useRouter } from 'expo-router';
import { useTranslation } from 'react-i18next';
import { useState } from 'react';
import { useSettings } from '../../lib/settings';
import { loadHistory, HistoryEntry } from '../../lib/history';

export default function HistoryScreen() {
  const { t, i18n } = useTranslation();
  const { colors } = useSettings();
  const router = useRouter();
  const styles = makeStyles(colors);

  const [items, setItems] = useState<HistoryEntry[]>([]);
  const [loading, setLoading] = useState(true);

  // Перезагружаем при каждом фокусе на вкладку (чтобы видеть новые записи)
  useFocusEffect(
    useCallback(() => {
      let active = true;
      setLoading(true);
      loadHistory().then((data) => {
        if (active) {
          setItems(data);
          setLoading(false);
        }
      });
      return () => { active = false; };
    }, [])
  );

  const handleTap = (entry: HistoryEntry) => {
    // navigate (не push) — переходит на существующую вкладку без создания нового стека
    router.navigate({
      pathname: '/(tabs)/',
      params: {
        rerouteAddress: entry.address,
        rerouteLat: String(entry.lat),
        rerouteLng: String(entry.lng),
      },
    });
  };

  return (
    <SafeAreaView style={styles.container} edges={['top']}>
      <Text style={styles.title}>{t('history.title')}</Text>

      {loading ? (
        <ActivityIndicator color={colors.accent} style={{ marginTop: 40 }} />
      ) : items.length === 0 ? (
        <View style={styles.empty}>
          <Ionicons name="time-outline" size={56} color={colors.textMuted} />
          <Text style={styles.emptyText}>{t('history.empty')}</Text>
        </View>
      ) : (
        <FlatList
          data={items}
          keyExtractor={(it) => it.id}
          renderItem={({ item }) => (
            <Pressable
              style={({ pressed }) => [styles.row, pressed && styles.rowPressed]}
              onPress={() => handleTap(item)}
              android_ripple={{ color: colors.border }}
            >
              <View style={styles.rowIcon}>
                <Ionicons name="location" size={18} color={colors.accent} />
              </View>
              <View style={styles.rowText}>
                <Text style={styles.rowTitle} numberOfLines={2}>{item.address}</Text>
                <Text style={styles.rowDate}>{formatVisitedAt(item.visited_at, i18n.language)}</Text>
              </View>
              <Ionicons name="chevron-forward" size={20} color={colors.textMuted} />
            </Pressable>
          )}
          contentContainerStyle={{ paddingBottom: 80 }}
        />
      )}

      <View style={styles.footer}>
        <Text style={styles.footerText}>{t('history.autoDeleteHint')}</Text>
      </View>
    </SafeAreaView>
  );
}

function formatVisitedAt(iso: string | null, lang: string): string {
  if (!iso) return '';
  const date = new Date(iso);
  const now = new Date();
  const diffMs = now.getTime() - date.getTime();
  const diffMin = Math.floor(diffMs / 60000);
  const diffHr = Math.floor(diffMin / 60);
  const diffDay = Math.floor(diffHr / 24);

  if (diffMin < 1) return 'сейчас';
  if (diffMin < 60) return `${diffMin} мин назад`;
  if (diffHr < 24) return `${diffHr} ч назад`;
  if (diffDay < 7) return `${diffDay} дн назад`;
  // Старше недели — дата
  return date.toLocaleDateString(lang || 'ru', { day: '2-digit', month: 'short' });
}

const makeStyles = (colors: any) =>
  StyleSheet.create({
    container: { flex: 1, backgroundColor: colors.background, paddingHorizontal: 16 },
    title: { fontSize: 28, fontWeight: 'bold', color: colors.text, marginTop: 8, marginBottom: 16 },
    empty: { flex: 1, alignItems: 'center', justifyContent: 'center', gap: 12 },
    emptyText: { color: colors.textMuted, fontSize: 15, textAlign: 'center' },

    row: {
      flexDirection: 'row',
      alignItems: 'center',
      gap: 12,
      paddingVertical: 14,
      paddingHorizontal: 12,
      backgroundColor: colors.surface,
      borderRadius: 12,
      marginBottom: 8,
      borderWidth: 1,
      borderColor: colors.border,
    },
    rowPressed: { opacity: 0.7 },
    rowIcon: {
      width: 36, height: 36, borderRadius: 18,
      backgroundColor: colors.background,
      alignItems: 'center', justifyContent: 'center',
    },
    rowText: { flex: 1 },
    rowTitle: { color: colors.text, fontSize: 15, fontWeight: '500' },
    rowDate: { color: colors.textMuted, fontSize: 12, marginTop: 2 },

    footer: {
      position: 'absolute',
      bottom: 16,
      left: 16,
      right: 16,
      paddingVertical: 10,
      paddingHorizontal: 12,
      backgroundColor: colors.background,
      borderRadius: 8,
    },
    footerText: {
      color: colors.textMuted,
      fontSize: 12,
      textAlign: 'center',
    },
  });