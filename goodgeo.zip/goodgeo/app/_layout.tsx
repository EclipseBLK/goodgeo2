import { Stack, router, useSegments } from 'expo-router';
import { GestureHandlerRootView } from 'react-native-gesture-handler';
import { useEffect } from 'react';
import { View, ActivityIndicator } from 'react-native';
import { useTranslation } from 'react-i18next';
import { AuthProvider, useAuth } from '../lib/auth';
import { SettingsProvider, useSettings } from '../lib/settings';
import '../lib/i18n';
import PresencePing from '../lib/presence';

function RootLayoutNav() {
  const { t } = useTranslation();
  const { session, loading: authLoading } = useAuth();
  const { colors, isDark, loading: settingsLoading } = useSettings();
  const segments = useSegments();

  const loading = authLoading || settingsLoading;

  useEffect(() => {
    if (loading) return;
    const firstSegment = segments[0];
    const isAuthScreen = firstSegment === 'login' || firstSegment === undefined;

    if (session && isAuthScreen) {
      router.replace('/(tabs)');
    } else if (!session && !isAuthScreen) {
      router.replace('/login');
    }
  }, [session, loading, segments]);

  if (loading) {
    return (
      <View style={{ flex: 1, backgroundColor: colors.background, justifyContent: 'center', alignItems: 'center' }}>
        <ActivityIndicator size="large" color={colors.accent} />
      </View>
    );
  }

  return (
    <Stack
      screenOptions={{
        headerStyle: { backgroundColor: colors.background },
        headerTintColor: colors.text,
        headerShadowVisible: false,
        contentStyle: { backgroundColor: colors.background },
        statusBarStyle: isDark ? 'light' : 'dark',
      }}
    >
      <Stack.Screen name="index" options={{ headerShown: false }} />
      <Stack.Screen name="login" options={{ headerShown: false }} />
      <Stack.Screen name="(tabs)" options={{ headerShown: false }} />
      <Stack.Screen name="subscription" options={{ title: t('profile.subscription'), presentation: 'modal' }} />
      <Stack.Screen name="settings" options={{ title: t('profile.settings') }} />
    </Stack>
  );
}

export default function RootLayout() {
  return (
    <GestureHandlerRootView style={{ flex: 1 }}>
      <SettingsProvider>
        <AuthProvider>
          <PresencePing />
          <RootLayoutNav />
        </AuthProvider>
      </SettingsProvider>
    </GestureHandlerRootView>
  );
}