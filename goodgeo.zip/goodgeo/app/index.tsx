import { View, Image, ActivityIndicator, StyleSheet } from 'react-native';
import { useEffect } from 'react';
import { router } from 'expo-router';
import { useSettings } from '../lib/settings';

export default function SplashScreen() {
  const { colors } = useSettings();
  const styles = makeStyles(colors);

  useEffect(() => {
    const timer = setTimeout(() => {
      router.replace('/login');
    }, 1500);
    return () => clearTimeout(timer);
  }, []);

  return (
    <View style={styles.container}>
      <Image
        source={require('../assets/logo.png')}
        style={styles.logo}
        resizeMode="contain"
      />
      <ActivityIndicator size="large" color={colors.accent} style={{ marginTop: 32 }} />
    </View>
  );
}

const makeStyles = (colors: any) =>
  StyleSheet.create({
    container: {
      flex: 1,
      justifyContent: 'center',
      alignItems: 'center',
      backgroundColor: colors.background,
    },
    logo: { width: 220, height: 220 },
  });