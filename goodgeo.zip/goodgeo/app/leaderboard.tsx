import { useEffect, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  ActivityIndicator,
  Pressable,
  RefreshControl,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { router } from 'expo-router';
import { useTranslation } from 'react-i18next';
import { useSettings } from '../lib/settings';
import { useAuth } from '../lib/auth';
import { getLeaderboard, type LeaderboardEntry } from '../lib/suggestions';

export default function LeaderboardScreen() {
  const { t } = useTranslation();
  const { colors } = useSettings();
  const { session } = useAuth();
  const styles = makeStyles(colors);
  const currentUserId = session?.user?.id;

  const [items, setItems] = useState<LeaderboardEntry[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  const load = async () => {
    const data = await getLeaderboard(50);
    setItems(data);
    setLoading(false);
  };

  useEffect(() => {
    load();
  }, []);

  const onRefresh = async () => {
    setRefreshing(true);
    await load();
    setRefreshing(false);
  };

  return (
    <SafeAreaView style={styles.container}>
      {/* Header */}
      <View style={styles.header}>
        <Pressable onPress={() => router.back()} style={styles.backBtn}>
          <Ionicons name="chevron-back" size={28} color={colors.text} />
        </Pressable>
        <Text style={styles.title}>
          {t('leaderboard.title', 'Топ Creators')}
        </Text>
        <View style={styles.backBtn} />
      </View>

      {loading ? (
        <View style={styles.center}>
          <ActivityIndicator size="large" color={colors.accent} />
        </View>
      ) : items.length === 0 ? (
        <View style={styles.center}>
          <Ionicons
            name="trophy-outline"
            size={64}
            color={colors.textMuted}
            style={{ opacity: 0.5 }}
          />
          <Text style={styles.emptyText}>
            {t('leaderboard.empty', 'Рейтинг пока пуст')}
          </Text>
          <Text style={styles.emptyHint}>
            {t(
              'leaderboard.emptyHint',
              'Курьеры ещё не добавляли подъезды'
            )}
          </Text>
        </View>
      ) : (
        <FlatList
          data={items}
          keyExtractor={(item) => item.user_id}
          contentContainerStyle={{ padding: 16 }}
          refreshControl={
            <RefreshControl
              refreshing={refreshing}
              onRefresh={onRefresh}
              tintColor={colors.accent}
            />
          }
          renderItem={({ item }) => (
            <LeaderboardRow
              entry={item}
              isCurrentUser={item.user_id === currentUserId}
              styles={styles}
              colors={colors}
              t={t}
            />
          )}
        />
      )}
    </SafeAreaView>
  );
}

// =====================================================
// === ОДНА СТРОКА РЕЙТИНГА ===
// =====================================================

function LeaderboardRow({
  entry,
  isCurrentUser,
  styles,
  colors,
  t,
}: {
  entry: LeaderboardEntry;
  isCurrentUser: boolean;
  styles: any;
  colors: any;
  t: any;
}) {
  const medal = getMedal(entry.rank);

  return (
    <View
      style={[
        styles.row,
        isCurrentUser && styles.rowMine,
      ]}
    >
      {/* Ранг или медаль */}
      <View style={styles.rankBox}>
        {medal ? (
          <Text style={styles.medalEmoji}>{medal}</Text>
        ) : (
          <Text style={styles.rankNum}>#{entry.rank}</Text>
        )}
      </View>

      {/* Имя и ID */}
      <View style={styles.userInfo}>
        <Text style={styles.userName}>
          {entry.name ?? t('leaderboard.noName', 'Без имени')}
        </Text>
        <Text style={styles.userClientNum}>
          ID {entry.client_number ?? '—'}
        </Text>
      </View>

      {/* Принято */}
      <View style={styles.statsBox}>
        <Text style={styles.statsValue}>{entry.approved_count}</Text>
        <Text style={styles.statsLabel}>
          {t('leaderboard.approved', 'принято')}
        </Text>
      </View>

      {/* Бейдж "Вы" */}
      {isCurrentUser && (
        <View style={styles.youBadge}>
          <Text style={styles.youBadgeText}>{t('leaderboard.you', 'Вы')}</Text>
        </View>
      )}
    </View>
  );
}

function getMedal(rank: number): string | null {
  if (rank === 1) return '🥇';
  if (rank === 2) return '🥈';
  if (rank === 3) return '🥉';
  return null;
}

// =====================================================
// === СТИЛИ ===
// =====================================================

const makeStyles = (colors: any) =>
  StyleSheet.create({
    container: { flex: 1, backgroundColor: colors.background },
    center: { flex: 1, justifyContent: 'center', alignItems: 'center', padding: 24 },

    header: {
      flexDirection: 'row',
      alignItems: 'center',
      justifyContent: 'space-between',
      paddingHorizontal: 12,
      paddingVertical: 12,
      borderBottomWidth: 1,
      borderBottomColor: colors.border,
    },
    backBtn: { width: 40, alignItems: 'center' },
    title: {
      flex: 1,
      textAlign: 'center',
      fontSize: 17,
      fontWeight: '600',
      color: colors.text,
    },

    emptyText: {
      color: colors.text,
      fontSize: 16,
      fontWeight: '500',
      marginTop: 16,
    },
    emptyHint: {
      color: colors.textMuted,
      fontSize: 13,
      marginTop: 6,
      textAlign: 'center',
    },

    row: {
      flexDirection: 'row',
      alignItems: 'center',
      backgroundColor: colors.surface,
      borderRadius: 12,
      padding: 12,
      marginBottom: 8,
    },
    rowMine: {
      borderWidth: 1.5,
      borderColor: colors.accent,
    },

    rankBox: {
      width: 44,
      alignItems: 'center',
      justifyContent: 'center',
    },
    rankNum: {
      color: colors.textMuted,
      fontSize: 14,
      fontWeight: '600',
    },
    medalEmoji: {
      fontSize: 28,
    },

    userInfo: {
      flex: 1,
      marginLeft: 4,
    },
    userName: {
      color: colors.text,
      fontSize: 15,
      fontWeight: '500',
    },
    userClientNum: {
      color: colors.textMuted,
      fontSize: 11,
      fontFamily: 'monospace',
      marginTop: 2,
      letterSpacing: 0.5,
    },

    statsBox: {
      alignItems: 'flex-end',
      marginRight: 4,
    },
    statsValue: {
      color: colors.accent,
      fontSize: 18,
      fontWeight: '700',
    },
    statsLabel: {
      color: colors.textMuted,
      fontSize: 10,
      marginTop: 1,
    },

    youBadge: {
      marginLeft: 8,
      paddingHorizontal: 6,
      paddingVertical: 3,
      backgroundColor: colors.accent,
      borderRadius: 6,
    },
    youBadgeText: {
      color: '#fff',
      fontSize: 10,
      fontWeight: '700',
    },
  });