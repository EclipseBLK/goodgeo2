import { View, Text, TextInput, Pressable, StyleSheet, KeyboardAvoidingView, Platform, Image, Alert } from 'react-native';
import { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { supabase } from '../lib/supabase';
import { useSettings } from '../lib/settings';
import { getDeviceFingerprint } from '../lib/device';

export default function LoginScreen() {
  const { t } = useTranslation();
  const { colors } = useSettings();
  const styles = makeStyles(colors);

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [isSignUp, setIsSignUp] = useState(false);

  const handleAuth = async () => {
    if (!email || !password) {
      Alert.alert(t('common.error'), t('login.errEmptyFields'));
      return;
    }
    if (password.length < 6) {
      Alert.alert(t('common.error'), t('login.errShortPassword'));
      return;
    }

    setLoading(true);

    if (isSignUp) {
      const { data, error } = await supabase.auth.signUp({ email, password });

      if (error) {
        setLoading(false);
        Alert.alert(t('common.error'), error.message);
        return;
      }

      if (data.user) {
        const deviceId = await getDeviceFingerprint();
        const { data: trialResult, error: trialError } = await supabase.rpc('register_device_trial', {
          p_device_id: deviceId,
          p_user_id: data.user.id,
        });

        setLoading(false);

        if (trialError) {
          Alert.alert(t('common.error'), t('login.errDeviceRegister'));
          return;
        }

        if (trialResult === 'expired') {
          Alert.alert(t('login.trialBlocked'), t('login.trialBlockedMsg'));
        }
      } else {
        setLoading(false);
      }
    } else {
      const { error } = await supabase.auth.signInWithPassword({ email, password });
      setLoading(false);
      if (error) Alert.alert(t('common.error'), error.message);
    }
  };

  return (
    <KeyboardAvoidingView
      style={styles.container}
      behavior={Platform.OS === 'ios' ? 'padding' : undefined}
    >
      <Image
        source={require('../assets/logo.png')}
        style={styles.logoImage}
        resizeMode="contain"
      />

      <View style={styles.form}>
        <TextInput
          style={styles.input}
          placeholder={t('login.email')}
          placeholderTextColor={colors.textMuted}
          autoCapitalize="none"
          keyboardType="email-address"
          value={email}
          onChangeText={setEmail}
          editable={!loading}
        />
        <TextInput
          style={styles.input}
          placeholder={t('login.password')}
          placeholderTextColor={colors.textMuted}
          secureTextEntry
          value={password}
          onChangeText={setPassword}
          editable={!loading}
        />

        <Pressable
          style={[styles.button, loading && { opacity: 0.6 }]}
          onPress={handleAuth}
          disabled={loading}
        >
          <Text style={styles.buttonText}>
            {loading ? t('login.wait') : isSignUp ? t('login.signUp') : t('login.signIn')}
          </Text>
        </Pressable>

        <Pressable onPress={() => setIsSignUp(!isSignUp)} disabled={loading}>
          <Text style={styles.link}>
            {isSignUp ? t('login.switchToSignIn') : t('login.switchToSignUp')}
          </Text>
        </Pressable>
      </View>
    </KeyboardAvoidingView>
  );
}

const makeStyles = (colors: any) =>
  StyleSheet.create({
    container: { flex: 1, backgroundColor: colors.background, justifyContent: 'center', padding: 24 },
    logoImage: { width: 180, height: 180, alignSelf: 'center', marginBottom: 32 },
    form: { gap: 12 },
    input: {
      backgroundColor: colors.surface,
      color: colors.text,
      padding: 16,
      borderRadius: 12,
      fontSize: 16,
      borderWidth: 1,
      borderColor: colors.border,
    },
    button: {
      backgroundColor: colors.accent,
      padding: 16,
      borderRadius: 12,
      alignItems: 'center',
      marginTop: 8,
    },
    buttonText: { color: colors.text, fontSize: 16, fontWeight: '600' },
    link: { color: colors.accent, textAlign: 'center', marginTop: 16 },
  });