import { View, Text, Pressable, StyleSheet, ScrollView, Switch, Linking, Alert } from 'react-native';
import Constants from 'expo-constants';
import { Ionicons } from '@expo/vector-icons';
import { useTranslation } from 'react-i18next';
import { useSettings, Language, ThemeMode } from '../lib/settings';
import { useTranslation as useT } from 'react-i18next';

const LANGUAGES: { code: Language; label: string; flag: string }[] = [
  { code: 'pl', label: 'Polski', flag: '🇵🇱' },
  { code: 'ru', label: 'Русский', flag: '🇷🇺' },
  { code: 'en', label: 'English', flag: '🇬🇧' },
  { code: 'uk', label: 'Українська', flag: '🇺🇦' },
];

export default function SettingsScreen() {
  const { t } = useTranslation();
  const { settings, colors, setLanguage, setTheme, setPushEnabled, setAutoNightMode } = useSettings();
  const version = Constants.expoConfig?.version ?? '1.0.0';
  const styles = makeStyles(colors);

  const THEMES: { code: ThemeMode; label: string; icon: keyof typeof Ionicons.glyphMap }[] = [
    { code: 'dark', label: t('settings.themeDark'), icon: 'moon' },
    { code: 'light', label: t('settings.themeLight'), icon: 'sunny' },
    { code: 'auto', label: t('settings.themeAuto'), icon: 'phone-portrait' },
  ];

  const openUrl = async (url: string) => {
    const can = await Linking.canOpenURL(url);
    if (can) Linking.openURL(url);
    else Alert.alert(t('common.error'), t('settings.openLinkError'));
  };

  return (
    <ScrollView style={styles.container} contentContainerStyle={{ paddingBottom: 32 }}>
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>{t('settings.language')}</Text>
        <View style={styles.card}>
          {LANGUAGES.map((lang, idx) => (
            <Pressable
              key={lang.code}
              style={[styles.row, idx < LANGUAGES.length - 1 && styles.rowBorder]}
              onPress={() => setLanguage(lang.code)}
            >
              <Text style={styles.flag}>{lang.flag}</Text>
              <Text style={styles.rowLabel}>{lang.label}</Text>
              {settings.language === lang.code && (
                <Ionicons name="checkmark" size={22} color={colors.accent} />
              )}
            </Pressable>
          ))}
        </View>
      </View>

      <View style={styles.section}>
        <Text style={styles.sectionTitle}>{t('settings.theme')}</Text>
        <View style={styles.card}>
          {THEMES.map((th, idx) => (
            <Pressable
              key={th.code}
              style={[styles.row, idx < THEMES.length - 1 && styles.rowBorder]}
              onPress={() => setTheme(th.code)}
            >
              <Ionicons name={th.icon} size={22} color={colors.text} />
              <Text style={styles.rowLabel}>{th.label}</Text>
              {settings.theme === th.code && (
                <Ionicons name="checkmark" size={22} color={colors.accent} />
              )}
            </Pressable>
          ))}
        </View>
      </View>

<View style={styles.section}>
        <Text style={styles.sectionTitle}>{t('settings.map')}</Text>
        <View style={styles.card}>
          <View style={styles.row}>
            <Ionicons name="contrast" size={22} color={colors.text} />
            <View style={{ flex: 1 }}>
              <Text style={styles.rowLabel}>{t('settings.autoNightMode')}</Text>
              <Text style={styles.rowSub}>{t('settings.autoNightModeHint')}</Text>
            </View>
            <Switch
              value={settings.autoNightMode}
              onValueChange={setAutoNightMode}
              trackColor={{ false: colors.border, true: colors.accent }}
              thumbColor="#fff"
            />
          </View>
        </View>
      </View>

      <View style={styles.section}>
        <Text style={styles.sectionTitle}>{t('settings.notifications')}</Text>
        <View style={styles.card}>
          <View style={styles.row}>
            <Ionicons name="notifications" size={22} color={colors.text} />
            <Text style={styles.rowLabel}>{t('settings.push')}</Text>
            <Switch
              value={settings.pushEnabled}
              onValueChange={setPushEnabled}
              trackColor={{ false: colors.border, true: colors.accent }}
              thumbColor="#fff"
            />
          </View>
        </View>
      </View>

      <View style={styles.section}>
        <Text style={styles.sectionTitle}>{t('settings.about')}</Text>
        <View style={styles.card}>
          <View style={[styles.row, styles.rowBorder]}>
            <Ionicons name="information-circle" size={22} color={colors.text} />
            <Text style={styles.rowLabel}>{t('settings.version')}</Text>
            <Text style={styles.rowValue}>{version}</Text>
          </View>
          <Pressable
            style={[styles.row, styles.rowBorder]}
            onPress={() => openUrl('https://goodgeo.app/privacy')}
          >
            <Ionicons name="shield-checkmark" size={22} color={colors.text} />
            <Text style={styles.rowLabel}>{t('settings.privacy')}</Text>
            <Ionicons name="open-outline" size={20} color={colors.textMuted} />
          </Pressable>
          <Pressable
            style={styles.row}
            onPress={() => openUrl('https://goodgeo.app/terms')}
          >
            <Ionicons name="document-text" size={22} color={colors.text} />
            <Text style={styles.rowLabel}>{t('settings.terms')}</Text>
            <Ionicons name="open-outline" size={20} color={colors.textMuted} />
          </Pressable>
        </View>
      </View>
    </ScrollView>
  );
}

const makeStyles = (colors: any) =>
  StyleSheet.create({
    container: { flex: 1, backgroundColor: colors.background },
    section: { marginTop: 24, paddingHorizontal: 16 },
    sectionTitle: {
      color: colors.textMuted,
      fontSize: 13,
      textTransform: 'uppercase',
      marginBottom: 8,
      letterSpacing: 1,
    },
    card: { backgroundColor: colors.surface, borderRadius: 12, overflow: 'hidden' },
    row: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: 16, paddingVertical: 14, gap: 14 },
    rowBorder: { borderBottomWidth: 1, borderBottomColor: colors.border },
    rowLabel: { color: colors.text, fontSize: 16, flex: 1 },
    rowValue: { color: colors.textMuted, fontSize: 14 },
    rowSub: { color: colors.textMuted, fontSize: 12, marginTop: 2 },
    flag: { fontSize: 22, width: 28, textAlign: 'center' },
  });