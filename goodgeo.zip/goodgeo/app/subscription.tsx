import { View, Text, Pressable, StyleSheet } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useTranslation } from 'react-i18next';
import { useSettings } from '../lib/settings';

export default function SubscriptionScreen() {
  const { t } = useTranslation();
  const { colors } = useSettings();
  const styles = makeStyles(colors);

  return (
    <View style={styles.container}>
      <View style={styles.card}>
        <Text style={styles.title}>{t('subscription.title')}</Text>
        <Text style={styles.price}>{t('subscription.price')}</Text>
        <Text style={styles.trial}>{t('subscription.trial')}</Text>

        <View style={styles.features}>
          <Feature text={t('subscription.features.search')} colors={colors} />
          <Feature text={t('subscription.features.navigation')} colors={colors} />
          <Feature text={t('subscription.features.offline')} colors={colors} />
          <Feature text={t('subscription.features.history')} colors={colors} />
        </View>

        <Pressable style={styles.button}>
          <Text style={styles.buttonText}>{t('subscription.startTrial')}</Text>
        </Pressable>
      </View>
    </View>
  );
}

function Feature({ text, colors }: { text: string; colors: any }) {
  return (
    <View style={{ flexDirection: 'row', alignItems: 'center', gap: 12 }}>
      <Ionicons name="checkmark-circle" size={20} color={colors.accent} />
      <Text style={{ color: colors.text, fontSize: 15, flex: 1 }}>{text}</Text>
    </View>
  );
}

const makeStyles = (colors: any) =>
  StyleSheet.create({
    container: { flex: 1, backgroundColor: colors.background, padding: 16, justifyContent: 'center' },
    card: {
      backgroundColor: colors.surface,
      borderRadius: 16,
      padding: 24,
      borderWidth: 1,
      borderColor: colors.accent,
    },
    title: { fontSize: 24, fontWeight: 'bold', color: colors.text, textAlign: 'center' },
    price: { fontSize: 36, fontWeight: 'bold', color: colors.accent, textAlign: 'center', marginTop: 8 },
    trial: { color: colors.textMuted, textAlign: 'center', marginBottom: 24 },
    features: { gap: 12, marginBottom: 24 },
    button: {
      backgroundColor: colors.accent,
      padding: 16,
      borderRadius: 12,
      alignItems: 'center',
    },
    buttonText: { color: colors.text, fontSize: 16, fontWeight: '600' },
  });