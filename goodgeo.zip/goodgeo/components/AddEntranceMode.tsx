import React, { useState } from 'react';
import {
  View,
  Text,
  Pressable,
  StyleSheet,
  TextInput,
  ScrollView,
  ActivityIndicator,
  Alert,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useTranslation } from 'react-i18next';
import { useSettings } from '../lib/settings';
import { submitSuggestion } from '../lib/suggestions';

type Coords = { lat: number; lng: number };

type Step = 'placing' | 'form';

type Range = { from: string; to: string };

type Props = {
  /** Функция получения координат центра карты (вызывается при нажатии "Здесь") */
  getCenterCoords: () => Promise<Coords | null> | Coords | null;
  /** Закрытие режима */
  onClose: () => void;
  /** Успешно отправлено */
  onSubmitted?: () => void;
};

export default function AddEntranceMode({
  getCenterCoords,
  onClose,
  onSubmitted,
}: Props) {
  const { t } = useTranslation();
  const { colors } = useSettings();
  const styles = makeStyles(colors);

  const [step, setStep] = useState<Step>('placing');
  const [coords, setCoords] = useState<Coords | null>(null);

  // Поля формы
  const [number, setNumber] = useState('');
  const [korpus, setKorpus] = useState('');
  const [ranges, setRanges] = useState<Range[]>([{ from: '', to: '' }]);
  const [extras, setExtras] = useState('');
  const [submitting, setSubmitting] = useState(false);

  const MAX_RANGES = 6;

  const handleConfirmLocation = async () => {
    const c = await getCenterCoords();
    if (!c) {
      Alert.alert(
        t('addEntrance.errorTitle', 'Ошибка'),
        t('addEntrance.errorNoCoords', 'Не удалось определить координаты')
      );
      return;
    }
    setCoords(c);
    setStep('form');
  };

  const updateRange = (idx: number, field: 'from' | 'to', value: string) => {
    setRanges((prev) =>
      prev.map((r, i) => (i === idx ? { ...r, [field]: value } : r))
    );
  };

  const addRange = () => {
    if (ranges.length >= MAX_RANGES) return;
    setRanges((prev) => [...prev, { from: '', to: '' }]);
  };

  const removeRange = (idx: number) => {
    if (ranges.length === 1) {
      setRanges([{ from: '', to: '' }]);
      return;
    }
    setRanges((prev) => prev.filter((_, i) => i !== idx));
  };

  const handleSubmit = async () => {
    if (!coords) return;
    if (!number.trim()) {
      Alert.alert(
        t('addEntrance.errorTitle', 'Ошибка'),
        t('addEntrance.errorNumber', 'Укажите номер подъезда')
      );
      return;
    }

    // Валидация диапазонов
    const validRanges = [];
    for (let i = 0; i < ranges.length; i++) {
      const r = ranges[i];
      if (!r.from && !r.to) continue;
      const from = parseInt(r.from);
      const to = parseInt(r.to);
      if (!from || !to || isNaN(from) || isNaN(to)) {
        Alert.alert(
          t('addEntrance.errorTitle', 'Ошибка'),
          t('addEntrance.errorRange', 'Диапазон {{n}}: укажите оба числа', { n: i + 1 })
        );
        return;
      }
      if (from > to) {
        Alert.alert(
          t('addEntrance.errorTitle', 'Ошибка'),
          t('addEntrance.errorRangeOrder', 'Диапазон {{n}}: "от" должно быть меньше "до"', {
            n: i + 1,
          })
        );
        return;
      }
      validRanges.push({
        apt_from: from,
        apt_to: to,
        order_index: i + 1,
      });
    }

    // Парсим extras (через запятую)
    const aptExtras = extras
      .split(',')
      .map((s) => s.trim())
      .filter(Boolean);

    setSubmitting(true);
    const res = await submitSuggestion({
      entrance_number: number.trim(),
      korpus: korpus.trim() || null,
      lat: coords.lat,
      lng: coords.lng,
      ranges: validRanges,
      apt_extras: aptExtras,
    });
    setSubmitting(false);

    if (res.error) {
      const errMsg =
        res.error === 'not_creator'
          ? t('addEntrance.errNotCreator', 'У вас нет прав creator')
          : res.error === 'building_completed'
          ? t(
              'addEntrance.errBuildingCompleted',
              'Этот дом уже отмечен как готовый и не нуждается в дополнениях'
            )
          : res.error === 'duplicate_exact'
          ? t(
              'addEntrance.errDuplicateExact',
              'Такой подъезд уже существует поблизости'
            )
          : res.error === 'duplicate_nearby'
          ? t('addEntrance.errDuplicate', 'Подъезд уже есть в этой точке')
          : res.error === 'pending_nearby'
          ? t('addEntrance.errPending', 'В этом месте уже есть предложение на проверке')
          : t('addEntrance.errGeneric', 'Не удалось отправить: {{e}}', { e: res.error });
      Alert.alert(t('addEntrance.errorTitle', 'Ошибка'), errMsg);
      return;
    }

    Alert.alert(
      t('addEntrance.successTitle', 'Спасибо!'),
      t(
        'addEntrance.successText',
        'Ваше предложение отправлено на проверку. Мы рассмотрим его в ближайшее время.'
      ),
      [
        {
          text: 'OK',
          onPress: () => {
            onSubmitted?.();
            onClose();
          },
        },
      ]
    );
  };

  // ========== ШАГ 1: РАЗМЕЩЕНИЕ МЕТКИ ==========
  if (step === 'placing') {
    return (
      <>
        {/* Фиксированный pin в центре экрана */}
        <View style={styles.centerPin} pointerEvents="none">
          <View style={styles.pinShadow} />
          <Ionicons name="location" size={48} color={colors.accent} />
        </View>

        {/* Топ-бар с инструкцией */}
        <View style={styles.topBar}>
          <Pressable onPress={onClose} style={styles.closeBtn}>
            <Ionicons name="close" size={22} color={colors.text} />
          </Pressable>
          <View style={{ flex: 1 }}>
            <Text style={styles.topBarTitle}>
              {t('addEntrance.placingTitle', 'Добавить подъезд')}
            </Text>
            <Text style={styles.topBarHint}>
              {t('addEntrance.placingHint', 'Наведите карту на дверь подъезда')}
            </Text>
          </View>
        </View>

        {/* Кнопка "Здесь" */}
        <Pressable onPress={handleConfirmLocation} style={styles.confirmBtn}>
          <Ionicons name="checkmark-circle" size={20} color="#fff" />
          <Text style={styles.confirmBtnText}>
            {t('addEntrance.placeHere', 'Здесь')}
          </Text>
        </Pressable>
      </>
    );
  }

  // ========== ШАГ 2: ФОРМА ==========
  return (
    <View style={styles.formOverlay}>
      <View style={styles.formSheet}>
        {/* Шапка */}
        <View style={styles.formHeader}>
          <Pressable
            onPress={() => setStep('placing')}
            style={styles.closeBtn}
            disabled={submitting}
          >
            <Ionicons name="chevron-back" size={22} color={colors.text} />
          </Pressable>
          <Text style={styles.formTitle}>
            {t('addEntrance.formTitle', 'Данные подъезда')}
          </Text>
          <Pressable onPress={onClose} style={styles.closeBtn} disabled={submitting}>
            <Ionicons name="close" size={22} color={colors.textMuted} />
          </Pressable>
        </View>

        <ScrollView
          contentContainerStyle={{ padding: 16 }}
          keyboardShouldPersistTaps="handled"
        >
          {/* Координаты для подсказки */}
          {coords && (
            <View style={styles.coordsBox}>
              <Ionicons name="location" size={14} color={colors.accent} />
              <Text style={styles.coordsText}>
                {coords.lat.toFixed(5)}, {coords.lng.toFixed(5)}
              </Text>
            </View>
          )}

          {/* Номер подъезда */}
          <Text style={styles.label}>
            {t('addEntrance.fieldNumber', 'Номер подъезда')}
            <Text style={styles.required}> *</Text>
          </Text>
          <TextInput
            style={styles.input}
            value={number}
            onChangeText={setNumber}
            placeholder="A, 1, 2..."
            placeholderTextColor={colors.textMuted}
            maxLength={5}
            editable={!submitting}
          />

          {/* Диапазоны квартир */}
          <Text style={[styles.label, { marginTop: 16 }]}>
            {t('addEntrance.fieldRanges', 'Диапазоны квартир')}
          </Text>

          {ranges.map((r, idx) => (
            <View key={idx} style={styles.rangeRow}>
              <Text style={styles.rangeIdx}>{idx + 1}</Text>
              <TextInput
                style={[styles.input, styles.rangeInput]}
                value={r.from}
                onChangeText={(v) => updateRange(idx, 'from', v)}
                placeholder="101"
                placeholderTextColor={colors.textMuted}
                keyboardType="number-pad"
                editable={!submitting}
              />
              <Text style={styles.dash}>—</Text>
              <TextInput
                style={[styles.input, styles.rangeInput]}
                value={r.to}
                onChangeText={(v) => updateRange(idx, 'to', v)}
                placeholder="115"
                placeholderTextColor={colors.textMuted}
                keyboardType="number-pad"
                editable={!submitting}
              />
              <Pressable
                onPress={() => removeRange(idx)}
                style={styles.rangeRemoveBtn}
                disabled={submitting}
              >
                <Ionicons name="close" size={18} color={colors.error} />
              </Pressable>
            </View>
          ))}

          {ranges.length < MAX_RANGES && (
            <Pressable
              onPress={addRange}
              style={styles.addRangeBtn}
              disabled={submitting}
            >
              <Ionicons name="add" size={16} color={colors.accent} />
              <Text style={styles.addRangeText}>
                {t('addEntrance.addRange', 'Добавить диапазон')}
              </Text>
            </Pressable>
          )}

          {/* Доп.квартиры (extras) */}
          <Text style={[styles.label, { marginTop: 16 }]}>
            {t('addEntrance.fieldExtras', 'Доп. квартиры')}
            <Text style={styles.optional}>
              {' '}
              — {t('addEntrance.optional', 'необязательно')}
            </Text>
          </Text>
          <TextInput
            style={styles.input}
            value={extras}
            onChangeText={setExtras}
            placeholder="55, 17А, 22Б"
            placeholderTextColor={colors.textMuted}
            editable={!submitting}
            autoCapitalize="characters"
          />
          <Text style={styles.hint}>
            {t(
              'addEntrance.extrasHint',
              'Одиночные квартиры через запятую (например 17А, 55)'
            )}
          </Text>

          {/* Корпус */}
          <Text style={[styles.label, { marginTop: 16 }]}>
            {t('addEntrance.fieldKorpus', 'Корпус')}
            <Text style={styles.optional}>
              {' '}
              — {t('addEntrance.optional', 'необязательно')}
            </Text>
          </Text>
          <TextInput
            style={styles.input}
            value={korpus}
            onChangeText={setKorpus}
            placeholder="A, B, C..."
            placeholderTextColor={colors.textMuted}
            maxLength={5}
            autoCapitalize="characters"
            editable={!submitting}
          />
          <Text style={styles.hint}>
            {t(
              'addEntrance.korpusHint',
              'Если в комплексе несколько корпусов с одинаковым адресом'
            )}
          </Text>
        </ScrollView>

        {/* Submit-кнопка */}
        <View style={styles.formFooter}>
          <Pressable
            onPress={handleSubmit}
            style={[styles.submitBtn, submitting && { opacity: 0.6 }]}
            disabled={submitting}
          >
            {submitting ? (
              <ActivityIndicator color="#fff" />
            ) : (
              <>
                <Ionicons name="send" size={18} color="#fff" />
                <Text style={styles.submitBtnText}>
                  {t('addEntrance.submit', 'Отправить на проверку')}
                </Text>
              </>
            )}
          </Pressable>
        </View>
      </View>
    </View>
  );
}

const makeStyles = (colors: any) =>
  StyleSheet.create({
    // Pin в центре карты
    centerPin: {
      position: 'absolute',
      top: '50%',
      left: '50%',
      marginLeft: -24,
      marginTop: -48,
      alignItems: 'center',
      zIndex: 5,
    },
    pinShadow: {
      position: 'absolute',
      bottom: 0,
      width: 12,
      height: 4,
      borderRadius: 6,
      backgroundColor: 'rgba(0,0,0,0.3)',
    },

    // Top bar инструкции
    topBar: {
      position: 'absolute',
      top: 50,
      left: 16,
      right: 16,
      flexDirection: 'row',
      alignItems: 'center',
      gap: 10,
      backgroundColor: colors.surface,
      borderRadius: 16,
      paddingVertical: 10,
      paddingHorizontal: 12,
      elevation: 6,
      shadowColor: '#000',
      shadowOpacity: 0.3,
      shadowRadius: 6,
      shadowOffset: { width: 0, height: 2 },
      zIndex: 10,
    },
    topBarTitle: {
      color: colors.text,
      fontSize: 15,
      fontWeight: '600',
    },
    topBarHint: {
      color: colors.textMuted,
      fontSize: 12,
      marginTop: 2,
    },
    closeBtn: {
      width: 36,
      height: 36,
      borderRadius: 18,
      justifyContent: 'center',
      alignItems: 'center',
    },

    // Кнопка "Здесь"
    confirmBtn: {
      position: 'absolute',
      bottom: 32,
      left: '50%',
      marginLeft: -90,
      width: 180,
      flexDirection: 'row',
      alignItems: 'center',
      justifyContent: 'center',
      gap: 8,
      backgroundColor: colors.accent,
      paddingVertical: 14,
      borderRadius: 28,
      elevation: 8,
      shadowColor: '#000',
      shadowOpacity: 0.4,
      shadowRadius: 8,
      shadowOffset: { width: 0, height: 4 },
      zIndex: 10,
    },
    confirmBtnText: {
      color: '#fff',
      fontSize: 16,
      fontWeight: '600',
    },

    // Форма (overlay)
    formOverlay: {
      position: 'absolute',
      inset: 0,
      backgroundColor: 'rgba(0,0,0,0.5)',
      justifyContent: 'flex-end',
      zIndex: 50,
    },
    formSheet: {
      backgroundColor: colors.background,
      borderTopLeftRadius: 24,
      borderTopRightRadius: 24,
      maxHeight: '92%',
      flexDirection: 'column',
    },
    formHeader: {
      flexDirection: 'row',
      alignItems: 'center',
      paddingVertical: 12,
      paddingHorizontal: 8,
      borderBottomWidth: 1,
      borderBottomColor: colors.border,
    },
    formTitle: {
      flex: 1,
      textAlign: 'center',
      color: colors.text,
      fontSize: 16,
      fontWeight: '600',
    },

    coordsBox: {
      flexDirection: 'row',
      alignItems: 'center',
      gap: 6,
      paddingVertical: 8,
      paddingHorizontal: 12,
      backgroundColor: colors.surface,
      borderRadius: 8,
      marginBottom: 16,
      alignSelf: 'flex-start',
    },
    coordsText: {
      color: colors.textMuted,
      fontSize: 12,
      fontFamily: 'monospace',
    },

    label: {
      color: colors.text,
      fontSize: 13,
      fontWeight: '600',
      marginBottom: 6,
    },
    required: { color: colors.error },
    optional: {
      color: colors.textMuted,
      fontWeight: '400',
      fontSize: 12,
    },
    input: {
      backgroundColor: colors.surface,
      borderRadius: 10,
      paddingHorizontal: 14,
      paddingVertical: 12,
      color: colors.text,
      fontSize: 15,
      borderWidth: 1,
      borderColor: colors.border,
    },
    hint: {
      color: colors.textMuted,
      fontSize: 11,
      marginTop: 4,
      lineHeight: 14,
    },

    // Range row
    rangeRow: {
      flexDirection: 'row',
      alignItems: 'center',
      gap: 8,
      marginBottom: 8,
    },
    rangeIdx: {
      width: 16,
      color: colors.textMuted,
      fontSize: 12,
      textAlign: 'center',
    },
    rangeInput: {
      flex: 1,
      paddingVertical: 10,
    },
    dash: {
      color: colors.textMuted,
      fontSize: 16,
    },
    rangeRemoveBtn: {
      width: 32,
      height: 32,
      borderRadius: 16,
      justifyContent: 'center',
      alignItems: 'center',
    },

    addRangeBtn: {
      flexDirection: 'row',
      alignItems: 'center',
      justifyContent: 'center',
      gap: 6,
      paddingVertical: 10,
      borderRadius: 10,
      borderWidth: 1.5,
      borderStyle: 'dashed',
      borderColor: colors.accent + '60',
      marginTop: 4,
    },
    addRangeText: {
      color: colors.accent,
      fontSize: 13,
      fontWeight: '500',
    },

    // Footer
    formFooter: {
      padding: 16,
      paddingBottom: 24,
      borderTopWidth: 1,
      borderTopColor: colors.border,
    },
    submitBtn: {
      flexDirection: 'row',
      alignItems: 'center',
      justifyContent: 'center',
      gap: 8,
      backgroundColor: colors.accent,
      paddingVertical: 14,
      borderRadius: 12,
    },
    submitBtnText: {
      color: '#fff',
      fontSize: 15,
      fontWeight: '600',
    },
  });