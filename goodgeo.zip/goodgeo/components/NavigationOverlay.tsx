import React from 'react';
import { View, Text, Pressable, StyleSheet } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { formatDistance, formatDuration, ManeuverModifier, ManeuverType } from '../lib/directions';
import { useSettings } from '../lib/settings';

type Props = {
  remainingMeters: number;
  remainingSeconds: number;
  totalMeters: number;
  arrivedAtBuilding: boolean;
  maneuverType?: ManeuverType;
  maneuverModifier?: ManeuverModifier | null;
  maneuverInstruction?: string;
  distanceToManeuver?: number;
  followingUser: boolean;
  onRecenter: () => void;
  onStop: () => void;
};

export default function NavigationOverlay({
  remainingMeters,
  remainingSeconds,
  totalMeters,
  arrivedAtBuilding,
  maneuverType,
  maneuverModifier,
  maneuverInstruction,
  distanceToManeuver,
  followingUser,
  onRecenter,
  onStop,
}: Props) {
  const { colors } = useSettings();
  const styles = makeStyles(colors);

  const iconName = maneuverIconName(maneuverType, maneuverModifier);

  const progress = totalMeters > 0
    ? Math.max(0, Math.min(1, 1 - remainingMeters / totalMeters))
    : 0;

  const arrivalDate = new Date(Date.now() + remainingSeconds * 1000);
  const arrivalText = `${pad(arrivalDate.getHours())}:${pad(arrivalDate.getMinutes())}`;

  return (
    <>
      {/* TOP: maneuver card with safe area for notch */}
      <SafeAreaView style={styles.topBar} edges={['top']} pointerEvents="box-none">
        <View style={styles.topCard}>
          {arrivedAtBuilding ? (
            <View style={styles.arrivedBox}>
              <Ionicons name="flag" size={32} color={colors.accent} />
              <Text style={styles.bigText}>Вы у двери</Text>
            </View>
          ) : maneuverInstruction ? (
            <View style={styles.maneuverBox}>
              <View style={styles.iconCircle}>
                <Ionicons name={iconName} size={30} color="#fff" />
              </View>
              <View style={styles.maneuverText}>
                <Text style={styles.maneuverDist}>
                  {distanceToManeuver !== undefined ? formatDistance(distanceToManeuver) : ''}
                </Text>
                <Text style={styles.maneuverInstr} numberOfLines={2}>
                  {maneuverInstruction}
                </Text>
              </View>
            </View>
          ) : (
            <View style={styles.maneuverBox}>
              <Ionicons name="navigate" size={24} color={colors.accent} />
              <Text style={styles.bigText}>{formatDistance(remainingMeters)}</Text>
            </View>
          )}
        </View>
      </SafeAreaView>

      {/* RIGHT: "where am I" — only if user moved camera */}
      {!followingUser && !arrivedAtBuilding && (
        <Pressable onPress={onRecenter} style={styles.recenterButton}>
          <Ionicons name="locate" size={26} color="#fff" />
        </Pressable>
      )}

      {/* BOTTOM: solid bar that COVERS tab bar entirely + safe area */}
      <View style={styles.bottomCover}>
        <SafeAreaView edges={['bottom']} style={styles.bottomSafe}>
          <View style={styles.bottomCard}>
            <View style={styles.bottomRow}>
              <View style={styles.bottomInfo}>
                <Text style={styles.bottomDist}>{formatDistance(remainingMeters)}</Text>
                <Text style={styles.bottomDuration}>· {formatDuration(remainingSeconds)}</Text>
              </View>
              <Text style={styles.arrival}>прибытие {arrivalText}</Text>
            </View>

            <View style={styles.progressTrack}>
              <View style={[styles.progressFill, { width: `${progress * 100}%` }]} />
            </View>

            <Pressable
              onPress={onStop}
              android_ripple={{ color: '#991b1b' }}
              style={({ pressed }) => [
                styles.stopButton,
                pressed && { opacity: 0.85 },
              ]}
              hitSlop={10}
            >
              <Ionicons name="close" size={20} color="#fff" />
              <Text style={styles.stopText}>Завершить</Text>
            </Pressable>
          </View>
        </SafeAreaView>
      </View>
    </>
  );
}

function maneuverIconName(
  type?: ManeuverType,
  modifier?: ManeuverModifier | null
): keyof typeof Ionicons.glyphMap {
  if (type === 'arrive') return 'flag';
  if (type === 'depart') return 'navigate';
  if (type === 'roundabout' || type === 'rotary') return 'sync';

  switch (modifier) {
    case 'left': return 'arrow-back';
    case 'right': return 'arrow-forward';
    case 'sharp left': return 'return-up-back';
    case 'sharp right': return 'return-up-forward';
    case 'slight left': return 'arrow-back-outline';
    case 'slight right': return 'arrow-forward-outline';
    case 'uturn': return 'reload';
    case 'straight': return 'arrow-up';
    default: return 'arrow-up';
  }
}

function pad(n: number): string {
  return n < 10 ? `0${n}` : `${n}`;
}

const makeStyles = (colors: any) =>
  StyleSheet.create({
    topBar: {
      position: 'absolute',
      top: 0,
      left: 0,
      right: 0,
      paddingHorizontal: 12,
      zIndex: 100,
    },
    topCard: {
      backgroundColor: colors.surface,
      borderRadius: 14,
      padding: 12,
      marginTop: 4,
      elevation: 6,
      shadowColor: '#000',
      shadowOpacity: 0.3,
      shadowRadius: 8,
      shadowOffset: { width: 0, height: 2 },
    },
    maneuverBox: { flexDirection: 'row', alignItems: 'center', gap: 12 },
    arrivedBox: { flexDirection: 'row', alignItems: 'center', gap: 12, justifyContent: 'center' },
    iconCircle: {
      width: 52,
      height: 52,
      borderRadius: 26,
      backgroundColor: colors.accent,
      justifyContent: 'center',
      alignItems: 'center',
    },
    maneuverText: { flex: 1 },
    maneuverDist: { color: colors.text, fontSize: 22, fontWeight: '700' },
    maneuverInstr: { color: colors.textMuted, fontSize: 14, marginTop: 2 },
    bigText: { color: colors.text, fontSize: 22, fontWeight: '700' },

    recenterButton: {
      position: 'absolute',
      bottom: 240,
      right: 14,
      width: 57,
      height: 57,
      borderRadius: 28.5,
      backgroundColor: colors.accent,
      justifyContent: 'center',
      alignItems: 'center',
      elevation: 8,
      zIndex: 101,
      shadowColor: '#000',
      shadowOpacity: 0.3,
      shadowRadius: 6,
      shadowOffset: { width: 0, height: 2 },
    },

    bottomCover: {
      position: 'absolute',
      bottom: 0,
      left: 0,
      right: 0,
      backgroundColor: colors.surface,
      zIndex: 9999,
      elevation: 30,
    },
    bottomSafe: {
      backgroundColor: colors.surface,
    },
    bottomCard: {
      padding: 14,
      gap: 10,
      backgroundColor: colors.surface,
    },
    bottomRow: {
      flexDirection: 'row',
      alignItems: 'baseline',
      justifyContent: 'space-between',
    },
    bottomInfo: { flexDirection: 'row', alignItems: 'baseline', gap: 6 },
    bottomDist: { color: colors.text, fontSize: 20, fontWeight: '700' },
    bottomDuration: { color: colors.textMuted, fontSize: 14 },
    arrival: { color: colors.textMuted, fontSize: 13 },

    progressTrack: {
      height: 7,
      borderRadius: 4,
      backgroundColor: colors.background,
      overflow: 'hidden',
    },
    progressFill: {
      height: '100%',
      backgroundColor: colors.accent,
      borderRadius: 4,
    },

    stopButton: {
      flexDirection: 'row',
      alignItems: 'center',
      justifyContent: 'center',
      gap: 8,
      backgroundColor: '#dc2626',
      paddingVertical: 14,
      borderRadius: 10,
      marginTop: 4,
      elevation: 4,
    },
    stopText: { color: '#fff', fontSize: 16, fontWeight: '600' },
  });