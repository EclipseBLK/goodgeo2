import React, { forwardRef, useEffect, useImperativeHandle, useRef, useState } from 'react';
import { View, Text, Pressable, StyleSheet, ActivityIndicator } from 'react-native';
import BottomSheet, { BottomSheetView } from '@gorhom/bottom-sheet';
import { Ionicons } from '@expo/vector-icons';
import { useTranslation } from 'react-i18next';
import { fetchAllRoutes, formatDistance, formatDuration, RouteData, TransportType } from '../lib/directions';

import { useSettings } from '../lib/settings';

export type RouteSheetHandle = {
  open: (
    from: { lat: number; lng: number },
    to: { lat: number; lng: number },
    title: string
  ) => void;
  close: () => void;
};

type Props = {
  onStartNavigation: (route: RouteData, transport: TransportType) => void;
  onClose: () => void;
  onTransportChange?: (transport: TransportType, route: RouteData | null) => void;
};

const TRANSPORTS: { key: TransportType; label: string; icon: keyof typeof Ionicons.glyphMap }[] = [
  { key: 'car', label: 'Авто', icon: 'car' },
  { key: 'scooter', label: 'Скутер', icon: 'bicycle' },
  { key: 'bicycle', label: 'Велосипед', icon: 'bicycle-outline' },
];

const RouteSheet = forwardRef<RouteSheetHandle, Props>(({ onStartNavigation, onClose, onTransportChange }, ref) => {
  const { colors } = useSettings();
  const { i18n } = useTranslation();
  const styles = makeStyles(colors);

  const sheetRef = useRef<BottomSheet>(null);
  const [title, setTitle] = useState('');
  const [routes, setRoutes] = useState<Record<TransportType, RouteData | null> | null>(null);
  const [loading, setLoading] = useState(false);
  const [selected, setSelected] = useState<TransportType>('car');

  useImperativeHandle(ref, () => ({
    open: async (from, to, t) => {
      setTitle(t);
      setRoutes(null);
      setLoading(true);
      setSelected('car');
      sheetRef.current?.snapToIndex(0);

      const result = await fetchAllRoutes(from, to, i18n.language);
      setRoutes(result);
      setLoading(false);
      // Сообщаем родителю что маршруты подгрузились — обновить previewRoute
      onTransportChange?.('car', result.car);
    },
    close: () => sheetRef.current?.close(),
  }));

  const selectedRoute = routes?.[selected] ?? null;

  return (
    <BottomSheet
      ref={sheetRef}
      index={-1}
      snapPoints={['42%']}
      enablePanDownToClose
      onClose={() => onClose()}
      backgroundStyle={{ backgroundColor: colors.surface }}
      handleIndicatorStyle={{ backgroundColor: colors.textMuted }}
    >
      <BottomSheetView style={styles.content}>
        <Text style={styles.title} numberOfLines={2}>{title}</Text>

        <View style={styles.transportRow}>
          {TRANSPORTS.map((tr) => {
            const r = routes?.[tr.key];
            const isSelected = selected === tr.key;
            return (
              <Pressable
                key={tr.key}
                onPress={() => {
                  setSelected(tr.key);
                  onTransportChange?.(tr.key, routes?.[tr.key] ?? null);
                }}
                style={[
                  styles.transportCard,
                  { backgroundColor: isSelected ? colors.accent : colors.background },
                ]}
              >
                <Ionicons
                  name={tr.icon}
                  size={22}
                  color={isSelected ? '#fff' : colors.text}
                />
                <Text style={[styles.transportLabel, { color: isSelected ? '#fff' : colors.text }]}>
                  {tr.label}
                </Text>
                {loading && !r ? (
                  <ActivityIndicator size="small" color={isSelected ? '#fff' : colors.textMuted} />
                ) : r ? (
                  <Text style={[styles.transportTime, { color: isSelected ? '#fff' : colors.textMuted }]}>
                    {formatDuration(r.durationSeconds)}
                  </Text>
                ) : (
                  <Text style={[styles.transportTime, { color: isSelected ? '#fff' : colors.textMuted }]}>
                    —
                  </Text>
                )}
              </Pressable>
            );
          })}
        </View>

        {selectedRoute && (
          <View style={styles.summary}>
            <Text style={styles.summaryDist}>
              {formatDistance(selectedRoute.distanceMeters)} · {formatDuration(selectedRoute.durationSeconds)}
            </Text>
          </View>
        )}

        <Pressable
          disabled={!selectedRoute}
          onPress={() => selectedRoute && onStartNavigation(selectedRoute, selected)}
          style={[
            styles.startButton,
            { backgroundColor: selectedRoute ? colors.accent : colors.textMuted, opacity: selectedRoute ? 1 : 0.5 },
          ]}
        >
          <Ionicons name="navigate" size={20} color="#fff" />
          <Text style={styles.startText}>В путь</Text>
        </Pressable>

        <Pressable
          onPress={() => {
            sheetRef.current?.close();
            onClose();
          }}
          style={styles.cancelButton}
        >
          <Ionicons name="close" size={20} color="#fff" />
          <Text style={styles.cancelText}>Отмена</Text>
        </Pressable>
      </BottomSheetView>
    </BottomSheet>
  );
});

RouteSheet.displayName = 'RouteSheet';
export default RouteSheet;

const makeStyles = (colors: any) =>
  StyleSheet.create({
    content: { padding: 16, gap: 12 },
    title: { color: colors.text, fontSize: 16, fontWeight: '600' },
    transportRow: { flexDirection: 'row', gap: 8 },
    transportCard: {
      flex: 1,
      paddingVertical: 12,
      borderRadius: 12,
      alignItems: 'center',
      gap: 4,
    },
    transportLabel: { fontSize: 13, fontWeight: '500' },
    transportTime: { fontSize: 12 },
    summary: { paddingHorizontal: 8 },
    summaryDist: { color: colors.text, fontSize: 14 },
    startButton: {
      flexDirection: 'row',
      alignItems: 'center',
      justifyContent: 'center',
      gap: 8,
      paddingVertical: 14,
      borderRadius: 12,
    },
    startText: { color: '#fff', fontSize: 16, fontWeight: '600' },
    cancelButton: {
      flexDirection: 'row',
      alignItems: 'center',
      justifyContent: 'center',
      gap: 8,
      paddingVertical: 12,
      borderRadius: 12,
      backgroundColor: '#dc2626',
      marginTop: 8,
    },
    cancelText: { color: '#fff', fontSize: 15, fontWeight: '500' },
  });