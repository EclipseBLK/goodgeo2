import React, { useEffect, useState } from 'react';
import { View, Text, TextInput, Pressable, FlatList, StyleSheet, ActivityIndicator } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { router } from 'expo-router';
import { searchAddresses, GeocodeResult } from '../lib/searchAddress';
import { parseAddress } from '../lib/parseAddress';
import { useSettings } from '../lib/settings';

export type SearchResult = GeocodeResult & { aptNumber: number | null; korpus: string | null };

type Props = {
  value: string;
  onChange: (s: string) => void;
  onSelect: (result: SearchResult) => void;
};

export default function SearchOverlay({ value, onChange, onSelect }: Props) {
  const { colors } = useSettings();
  const styles = makeStyles(colors);

  const [results, setResults] = useState<GeocodeResult[]>([]);
  const [loading, setLoading] = useState(false);
  const [focused, setFocused] = useState(false);

  const parsed = parseAddress(value);

  useEffect(() => {
    const trimmed = value.trim();
    if (trimmed.length < 3) {
      setResults([]);
      return;
    }
    setLoading(true);
    const timer = setTimeout(async () => {
      // Ищем по адресу без квартиры
      const queryWithoutApt = parsed.house ? `${parsed.street} ${parsed.house}` : parsed.street;
      const r = await searchAddresses(queryWithoutApt);
      setResults(r);
      setLoading(false);
    }, 300);
    return () => clearTimeout(timer);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [value]);

  const showDropdown = focused && (results.length > 0 || loading);

  return (
    <SafeAreaView style={styles.container} edges={['top']}>
      <View style={styles.searchBar}>
        <Ionicons name="search" size={20} color={colors.textMuted} />
        <TextInput
          style={styles.input}
          placeholder="Адрес и квартира (Marszałkowska 81/8)"
          placeholderTextColor={colors.textMuted}
          value={value}
          onChangeText={onChange}
          onFocus={() => setFocused(true)}
          onBlur={() => setTimeout(() => setFocused(false), 150)}
          autoCorrect={false}
          autoCapitalize="none"
        />
        {value.length > 0 && (
          <Pressable onPress={() => onChange('')}>
            <Ionicons name="close-circle" size={20} color={colors.textMuted} />
          </Pressable>
        )}
      </View>

      {showDropdown && (
        <View style={styles.dropdown}>
          {loading ? (
            <View style={styles.loadingBox}>
              <ActivityIndicator size="small" color={colors.accent} />
            </View>
          ) : (
            <FlatList
              keyboardShouldPersistTaps="handled"
              data={results}
              keyExtractor={(item) => item.id}
              renderItem={({ item }) => (
                <Pressable
                  style={styles.resultRow}
                  onPress={() => {
                    onSelect({ ...item, aptNumber: parsed.apt, korpus: parsed.korpus });
                    setFocused(false);
                  }}
                >
                  <Ionicons name="location-outline" size={18} color={colors.accent} />
                  <View style={{ flex: 1 }}>
                    <Text style={styles.resultText} numberOfLines={2}>
                      {item.placeName}
                    </Text>
                    {parsed.apt !== null && (
                      <Text style={styles.aptText}>
                        кв. {parsed.apt}
                      </Text>
                    )}
                  </View>
                </Pressable>
              )}
            />
          )}
        </View>
      )}
    </SafeAreaView>
  );
}

const makeStyles = (colors: any) =>
  StyleSheet.create({
    container: { position: 'absolute', top: 0, left: 0, right: 0, paddingHorizontal: 16, zIndex: 10 },
    searchBar: {
      flexDirection: 'row',
      alignItems: 'center',
      backgroundColor: colors.surface,
      borderRadius: 28,
      paddingHorizontal: 16,
      paddingVertical: 8,
      marginTop: 8,
      gap: 12,
      elevation: 4,
      shadowColor: '#000',
      shadowOpacity: 0.3,
      shadowRadius: 8,
      shadowOffset: { width: 0, height: 2 },
    },
    input: { flex: 1, color: colors.text, fontSize: 16, paddingVertical: 8 },
    avatar: {
      width: 36,
      height: 36,
      borderRadius: 18,
      backgroundColor: colors.accent,
      justifyContent: 'center',
      alignItems: 'center',
    },
    dropdown: {
      backgroundColor: colors.surface,
      borderRadius: 16,
      marginTop: 4,
      maxHeight: 300,
      overflow: 'hidden',
      elevation: 4,
    },
    loadingBox: { padding: 16, alignItems: 'center' },
    resultRow: {
      flexDirection: 'row',
      alignItems: 'center',
      gap: 12,
      paddingVertical: 12,
      paddingHorizontal: 16,
      borderBottomWidth: 1,
      borderBottomColor: colors.background,
    },
    resultText: { color: colors.text, fontSize: 14 },
    aptText: { color: colors.accent, fontSize: 12, marginTop: 2, fontWeight: '500' },
  });