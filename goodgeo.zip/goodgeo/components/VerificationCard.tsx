import React, { useEffect, useRef, useState } from 'react';
import { View, Text, Pressable, StyleSheet, Animated } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useSettings } from '../lib/settings';

type Props = {
  onVote: (vote: 'correct' | 'incorrect') => void;
  onClose: () => void;
};

export default function VerificationCard({ onVote, onClose }: Props) {
  const { colors } = useSettings();
  const styles = makeStyles(colors);

  const [submitting, setSubmitting] = useState(false);
  const opacity = useRef(new Animated.Value(0)).current;
  const translateY = useRef(new Animated.Value(20)).current;

  useEffect(() => {
    Animated.parallel([
      Animated.timing(opacity, { toValue: 1, duration: 220, useNativeDriver: true }),
      Animated.timing(translateY, { toValue: 0, duration: 260, useNativeDriver: true }),
    ]).start();
  }, []);

  const handlePress = (vote: 'correct' | 'incorrect') => {
    if (submitting) return;
    setSubmitting(true);
    onVote(vote);
  };

  return (
    <Animated.View style={[styles.wrap, { opacity, transform: [{ translateY }] }]}>
      <Pressable
        accessibilityLabel="Закрыть"
        onPress={onClose}
        hitSlop={10}
        style={styles.closeBtn}
      >
        <Ionicons name="close" size={18} color={colors.textMuted} />
      </Pressable>

      <Text style={styles.title}>Это правильный подъезд?</Text>
      <Text style={styles.subtitle}>Помогите другим курьерам</Text>

      <View style={styles.row}>
        <Pressable
          disabled={submitting}
          onPress={() => handlePress('correct')}
          style={[styles.btn, styles.btnYes]}
        >
          <Ionicons name="thumbs-up" size={18} color="#0F6E56" />
          <Text style={[styles.btnText, { color: '#0F6E56' }]}>Да, верно</Text>
        </Pressable>

        <Pressable
          disabled={submitting}
          onPress={() => handlePress('incorrect')}
          style={[styles.btn, styles.btnNo]}
        >
          <Ionicons name="thumbs-down" size={18} color="#A32D2D" />
          <Text style={[styles.btnText, { color: '#A32D2D' }]}>Нет, ошибка</Text>
        </Pressable>
      </View>
    </Animated.View>
  );
}

const makeStyles = (colors: any) =>
  StyleSheet.create({
    wrap: {
      backgroundColor: colors.surface,
      borderRadius: 14,
      paddingVertical: 14,
      paddingHorizontal: 14,
      borderWidth: 1,
      borderColor: colors.border ?? 'rgba(255,255,255,0.08)',
      // тень для светлой темы
      shadowColor: '#000',
      shadowOffset: { width: 0, height: 4 },
      shadowOpacity: 0.18,
      shadowRadius: 12,
      elevation: 8,
    },
    closeBtn: {
      position: 'absolute',
      top: 6,
      right: 6,
      padding: 6,
      zIndex: 2,
    },
    title: {
      color: colors.text,
      fontSize: 15,
      fontWeight: '600',
      marginBottom: 2,
      paddingRight: 24,
    },
    subtitle: {
      color: colors.textMuted,
      fontSize: 12,
      marginBottom: 12,
    },
    row: {
      flexDirection: 'row',
      gap: 8,
    },
    btn: {
      flex: 1,
      flexDirection: 'row',
      alignItems: 'center',
      justifyContent: 'center',
      gap: 6,
      paddingVertical: 12,
      borderRadius: 10,
      borderWidth: 1,
    },
    btnText: {
      fontSize: 14,
      fontWeight: '600',
    },
    btnYes: {
      backgroundColor: '#E1F5EE',
      borderColor: '#9FE1CB',
    },
    btnNo: {
      backgroundColor: '#FCEBEB',
      borderColor: '#F7C1C1',
    },
  });