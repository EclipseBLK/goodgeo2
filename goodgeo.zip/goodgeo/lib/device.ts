import * as Device from 'expo-device';
import * as Application from 'expo-application';
import * as Crypto from 'expo-crypto';
import { Platform } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';

const DEVICE_FP_KEY = 'goodgeo_device_fingerprint';

/**
 * Собирает fingerprint устройства из стабильных характеристик.
 * Кешируется в AsyncStorage для скорости.
 */
export async function getDeviceFingerprint(): Promise<string> {
  // Если уже считали — вернём из кеша
  const cached = await AsyncStorage.getItem(DEVICE_FP_KEY);
  if (cached) return cached;

  // Платформо-специфичный установочный ID
  let installId = '';
  if (Platform.OS === 'android') {
    installId = Application.getAndroidId() ?? '';
  } else if (Platform.OS === 'ios') {
    installId = (await Application.getIosIdForVendorAsync()) ?? '';
  }

  // Собираем характеристики устройства
  const parts = [
    Platform.OS,
    Device.brand ?? '',
    Device.manufacturer ?? '',
    Device.modelName ?? '',
    Device.modelId ?? '',
    Device.osName ?? '',
    Device.osVersion ?? '',
    Device.osBuildId ?? '',
    String(Device.totalMemory ?? ''),
    String(Device.deviceYearClass ?? ''),
    installId,
  ];

  const raw = parts.join('|');

  // Хешируем в SHA-256 → 64-символьная строка
  const fingerprint = await Crypto.digestStringAsync(
    Crypto.CryptoDigestAlgorithm.SHA256,
    raw
  );

  await AsyncStorage.setItem(DEVICE_FP_KEY, fingerprint);
  return fingerprint;
}