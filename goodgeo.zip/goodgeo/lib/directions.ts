const TOKEN = process.env.EXPO_PUBLIC_MAPBOX_TOKEN!;

export type TransportType = 'car' | 'scooter' | 'bicycle';

export type ManeuverType =
  | 'turn' | 'continue' | 'merge' | 'depart' | 'arrive'
  | 'fork' | 'end of road' | 'new name' | 'rotary' | 'roundabout'
  | 'roundabout turn' | 'notification';

export type ManeuverModifier =
  | 'left' | 'right' | 'sharp left' | 'sharp right' | 'slight left'
  | 'slight right' | 'straight' | 'uturn';

export type Step = {
  instruction: string;
  distance: number;
  duration: number;
  maneuverType: ManeuverType;
  maneuverModifier: ManeuverModifier | null;
  maneuverLocation: [number, number];
  geometry: { type: 'LineString'; coordinates: [number, number][] };
};

export type RouteData = {
  geometry: { type: 'LineString'; coordinates: [number, number][] };
  distanceMeters: number;
  durationSeconds: number;
  steps: Step[];
};

const PROFILES: Record<TransportType, string> = {
  car: 'driving-traffic',
  scooter: 'driving-traffic',
  bicycle: 'walking',
};

const DURATION_MULTIPLIER: Record<TransportType, number> = {
  car: 1,
  scooter: 1,
  bicycle: 0.3,
};

function pickMapboxLanguage(appLang: string): string {
  const lang = (appLang || 'en').toLowerCase().split(/[-_]/)[0];
  if (lang === 'pl') return 'pl';
  if (lang === 'ru') return 'ru';
  if (lang === 'uk') return 'ru';
  return 'en';
}

/**
 * Запрос одного маршрута для одного транспорта.
 */
export async function fetchRoute(
  from: { lat: number; lng: number },
  to: { lat: number; lng: number },
  transport: TransportType,
  appLang: string = 'en'
): Promise<RouteData | null> {
  const profile = PROFILES[transport];
  const language = pickMapboxLanguage(appLang);

  const url =
    `https://api.mapbox.com/directions/v5/mapbox/${profile}/` +
    `${from.lng},${from.lat};${to.lng},${to.lat}` +
    `?geometries=geojson&overview=full&steps=true&language=${language}` +
    `&access_token=${TOKEN}`;

  try {
    const res = await fetch(url);
    if (!res.ok) return null;
    const data = await res.json();
    const route = data.routes?.[0];
    if (!route) return null;

    const multiplier = DURATION_MULTIPLIER[transport] ?? 1;

    const rawSteps = route.legs?.[0]?.steps ?? [];
    const steps: Step[] = rawSteps.map((s: any) => ({
      instruction: s.maneuver?.instruction ?? '',
      distance: s.distance ?? 0,
      duration: (s.duration ?? 0) * multiplier,
      maneuverType: s.maneuver?.type ?? 'continue',
      maneuverModifier: s.maneuver?.modifier ?? null,
      maneuverLocation: s.maneuver?.location ?? [from.lng, from.lat],
      geometry: s.geometry,
    }));

    return {
      geometry: route.geometry,
      distanceMeters: route.distance,
      durationSeconds: route.duration * multiplier,
      steps,
    };
  } catch (e) {
    console.warn('fetchRoute error:', e);
    return null;
  }
}

/**
 * Возвращает по одному маршруту для каждого транспорта.
 */
export function fetchAllRoutes(
  from: { lat: number; lng: number },
  to: { lat: number; lng: number },
  appLang: string = 'en'
): Promise<Record<TransportType, RouteData | null>> {
  return Promise.all([
    fetchRoute(from, to, 'car', appLang),
    fetchRoute(from, to, 'scooter', appLang),
    fetchRoute(from, to, 'bicycle', appLang),
  ]).then(([car, scooter, bicycle]) => ({ car, scooter, bicycle }));
}

export function formatDistance(m: number): string {
  if (m < 1000) return `${Math.round(m)} м`;
  return `${(m / 1000).toFixed(1)} км`;
}

export function formatDuration(s: number): string {
  const mins = Math.round(s / 60);
  if (mins < 60) return `${mins} мин`;
  const hours = Math.floor(mins / 60);
  const remMin = mins % 60;
  return `${hours} ч ${remMin} мин`;
}

export function findCurrentStep(
  steps: Step[],
  user: { lat: number; lng: number }
): { step: Step; distanceToManeuver: number; index: number } | null {
  if (steps.length === 0) return null;

  let bestIndex = 0;
  let bestDist = Infinity;

  for (let i = 0; i < steps.length; i++) {
    const [lng, lat] = steps[i].maneuverLocation;
    const d = haversine(user, { lat, lng });
    if (d < bestDist) {
      bestDist = d;
      bestIndex = i;
    }
  }

  const idx = bestIndex < steps.length - 1 ? bestIndex + 1 : bestIndex;
  const step = steps[idx];
  const [lng, lat] = step.maneuverLocation;

  return {
    step,
    distanceToManeuver: haversine(user, { lat, lng }),
    index: idx,
  };
}

function haversine(a: { lat: number; lng: number }, b: { lat: number; lng: number }): number {
  const R = 6371000;
  const toRad = (deg: number) => (deg * Math.PI) / 180;
  const dLat = toRad(b.lat - a.lat);
  const dLng = toRad(b.lng - a.lng);
  const lat1 = toRad(a.lat);
  const lat2 = toRad(b.lat);
  const x =
    Math.sin(dLat / 2) ** 2 + Math.sin(dLng / 2) ** 2 * Math.cos(lat1) * Math.cos(lat2);
  return 2 * R * Math.asin(Math.sqrt(x));
}

// === Snap to route (без изменений) ===
export function snapToRoute(
  user: { lat: number; lng: number },
  routeCoords: [number, number][]
): { lat: number; lng: number; segmentIndex: number; distanceFromRoute: number } | null {
  if (routeCoords.length < 2) return null;

  let bestPoint: { lat: number; lng: number } | null = null;
  let bestDist = Infinity;
  let bestSegment = 0;

  for (let i = 0; i < routeCoords.length - 1; i++) {
    const a = { lat: routeCoords[i][1], lng: routeCoords[i][0] };
    const b = { lat: routeCoords[i + 1][1], lng: routeCoords[i + 1][0] };
    const projected = projectOnSegment(user, a, b);
    const d = haversine(user, projected);
    if (d < bestDist) {
      bestDist = d;
      bestPoint = projected;
      bestSegment = i;
    }
  }

  if (!bestPoint) return null;
  return {
    lat: bestPoint.lat,
    lng: bestPoint.lng,
    segmentIndex: bestSegment,
    distanceFromRoute: bestDist,
  };
}

function projectOnSegment(
  p: { lat: number; lng: number },
  a: { lat: number; lng: number },
  b: { lat: number; lng: number }
): { lat: number; lng: number } {
  const dx = b.lng - a.lng;
  const dy = b.lat - a.lat;
  const lenSq = dx * dx + dy * dy;
  if (lenSq === 0) return a;

  let t = ((p.lng - a.lng) * dx + (p.lat - a.lat) * dy) / lenSq;
  t = Math.max(0, Math.min(1, t));

  return {
    lat: a.lat + t * dy,
    lng: a.lng + t * dx,
  };
}