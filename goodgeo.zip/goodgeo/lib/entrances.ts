import { useEffect, useRef, useState, useCallback } from 'react';
import { supabase } from './supabase';

export type AptRange = {
  id: string;
  entrance_id: string;
  apt_from: number;
  apt_to: number;
  order_index: number;
};

export type Entrance = {
  id: string;
  entrance_number: string | null;
  apt_from: number | null;        // legacy fallback (общий мин-макс)
  apt_to: number | null;          // legacy fallback
  lat: number;
  lng: number;
  address: string | null;
  mapbox_building_id: string | null;
  korpus: string | null;
  ranges?: AptRange[];            // массив диапазонов (новая структура)
};

export type Approach = {
  id: string;
  entrance_id: string;
  mapbox_building_id: string | null;
  lat: number;
  lng: number;
  order_index: number;
};

export async function loadAllEntrances(): Promise<Entrance[]> {
  // Загружаем подъезды и диапазоны параллельно
  const [entrancesResult, rangesResult] = await Promise.all([
    supabase
      .from('entrances')
      .select('id, entrance_number, apt_from, apt_to, lat, lng, address, mapbox_building_id, korpus'),
    supabase
      .from('entrance_apt_ranges')
      .select('id, entrance_id, apt_from, apt_to, order_index')
      .order('order_index', { ascending: true }),
  ]);

  if (entrancesResult.error) {
    console.warn('loadAllEntrances:', entrancesResult.error.message);
    return [];
  }
  if (rangesResult.error) {
    console.warn('loadAllAptRanges:', rangesResult.error.message);
  }

  const entrances = entrancesResult.data ?? [];
  const ranges = rangesResult.data ?? [];

  // Группируем диапазоны по entrance_id
  const rangesByEntrance = new Map<string, AptRange[]>();
  for (const r of ranges) {
    const list = rangesByEntrance.get(r.entrance_id) ?? [];
    list.push(r);
    rangesByEntrance.set(r.entrance_id, list);
  }

  // Прикладываем диапазоны к каждому подъезду
  return entrances.map((e) => ({
    ...e,
    ranges: rangesByEntrance.get(e.id) ?? [],
  }));
}

export async function loadAllApproaches(): Promise<Approach[]> {
  const { data, error } = await supabase
    .from('entrance_approaches')
    .select('id, entrance_id, mapbox_building_id, lat, lng, order_index')
    .order('order_index', { ascending: true });
  if (error) {
    console.warn('loadAllApproaches:', error.message);
    return [];
  }
  return data ?? [];
}

/**
 * Хук с Realtime-подпиской на изменения подъездов, диапазонов и подходов.
 * При любом INSERT/UPDATE/DELETE в этих таблицах — рефетч с debounce 500мс.
 * Точечные апдейты не делаем намеренно, чтобы не запутаться с ranges/approaches связями.
 */
export function useEntrancesData() {
  const [entrances, setEntrances] = useState<Entrance[]>([]);
  const [approaches, setApproaches] = useState<Approach[]>([]);

  const entrancesTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const approachesTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  const refreshEntrances = useCallback(() => {
    if (entrancesTimer.current) clearTimeout(entrancesTimer.current);
    entrancesTimer.current = setTimeout(() => {
      loadAllEntrances().then(setEntrances);
    }, 500);
  }, []);

  const refreshApproaches = useCallback(() => {
    if (approachesTimer.current) clearTimeout(approachesTimer.current);
    approachesTimer.current = setTimeout(() => {
      loadAllApproaches().then(setApproaches);
    }, 500);
  }, []);

  useEffect(() => {
    // Первичная загрузка
    loadAllEntrances().then(setEntrances);
    loadAllApproaches().then(setApproaches);

    // Подписка на entrances + entrance_apt_ranges
    const entrancesChannel = supabase
      .channel('entrances-realtime')
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'entrances' },
        () => refreshEntrances()
      )
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'entrance_apt_ranges' },
        () => refreshEntrances()
      )
      .subscribe();

    // Подписка на entrance_approaches
    const approachesChannel = supabase
      .channel('approaches-realtime')
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'entrance_approaches' },
        () => refreshApproaches()
      )
      .subscribe();

    return () => {
      if (entrancesTimer.current) clearTimeout(entrancesTimer.current);
      if (approachesTimer.current) clearTimeout(approachesTimer.current);
      supabase.removeChannel(entrancesChannel);
      supabase.removeChannel(approachesChannel);
    };
  }, [refreshEntrances, refreshApproaches]);

  return { entrances, approaches };
}

export function getApproachesForEntrance(
  approaches: Approach[],
  entranceId: string
): Approach[] {
  return approaches
    .filter((a) => a.entrance_id === entranceId)
    .sort((a, b) => a.order_index - b.order_index);
}

export function getRouteTarget(
  entrance: { lat: number; lng: number },
  approachesForEntrance: Approach[]
): { lat: number; lng: number } {
  if (approachesForEntrance.length > 0) {
    const first = approachesForEntrance[0];
    return { lat: first.lat, lng: first.lng };
  }
  return { lat: entrance.lat, lng: entrance.lng };
}

function normalizeKorpus(input: string | null | undefined): string | null {
  if (!input) return null;
  const cleaned = input.trim();
  if (!cleaned) return null;
  const map: Record<string, string> = {
    'А': 'A', 'В': 'B', 'С': 'C', 'Е': 'E', 'Н': 'H',
    'К': 'K', 'М': 'M', 'О': 'O', 'Р': 'P', 'Т': 'T', 'Х': 'X',
    'а': 'a', 'в': 'b', 'с': 'c', 'е': 'e', 'к': 'k',
    'м': 'm', 'о': 'o', 'р': 'p', 'т': 't', 'х': 'x',
  };
  let r = '';
  for (const ch of cleaned) r += map[ch] ?? ch;
  return r.toUpperCase();
}

/**
 * Проверяет входит ли квартира в любой из диапазонов подъезда.
 * Сначала проверяет массив ranges (новая структура), потом legacy apt_from/apt_to.
 */
function aptFitsEntrance(entrance: Entrance, apt: number): boolean {
  // 1) Новые диапазоны (приоритет)
  if (entrance.ranges && entrance.ranges.length > 0) {
    for (const r of entrance.ranges) {
      if (apt >= r.apt_from && apt <= r.apt_to) return true;
    }
    return false; // если есть массив — игнорируем legacy
  }
  // 2) Legacy fallback
  if (entrance.apt_from && entrance.apt_to) {
    return apt >= entrance.apt_from && apt <= entrance.apt_to;
  }
  return false;
}

/**
 * Найти подъезд по адресу + номеру квартиры (+ опциональный корпус).
 */
export function findEntranceByAptNumber(
  entrances: Entrance[],
  address: string,
  apt: number,
  searchCoords?: { lat: number; lng: number },
  korpus?: string | null
): Entrance | null {
  const normalize = (s: string) => s.toLowerCase().replace(/\s+/g, ' ').trim();
  const targetAddr = normalize(address);
  const targetKorpus = normalizeKorpus(korpus);

  // Шаг 1: точный матч по address
  let candidates = entrances.filter((e) => {
    if (!e.address) return false;
    return normalize(e.address) === targetAddr;
  });

  // Шаг 2: расширяем по mapbox_building_id (для разных фасадов)
  if (candidates.length > 0) {
    const buildingIds = new Set<string>();
    for (const c of candidates) {
      if (c.mapbox_building_id) buildingIds.add(c.mapbox_building_id);
    }
    if (buildingIds.size > 0) {
      candidates = entrances.filter(
        (e) => e.mapbox_building_id && buildingIds.has(e.mapbox_building_id)
      );
    }
  }

  // Шаг 3: fallback по координатам (50м радиус)
  if (candidates.length === 0 && searchCoords) {
    const NEARBY_RADIUS_M = 50;
    const nearby = entrances.filter((e) => {
      const d = haversineMeters(searchCoords, { lat: e.lat, lng: e.lng });
      return d <= NEARBY_RADIUS_M;
    });
    if (nearby.length > 0) {
      const buildingIds = new Set<string>();
      for (const e of nearby) {
        if (e.mapbox_building_id) buildingIds.add(e.mapbox_building_id);
      }
      candidates = buildingIds.size > 0
        ? entrances.filter(
            (e) => e.mapbox_building_id && buildingIds.has(e.mapbox_building_id)
          )
        : nearby;
    }
  }

  if (candidates.length === 0) return null;

  // Шаг 4: фильтр по korpus (если указан)
  if (targetKorpus) {
    const withKorpus = candidates.filter(
      (e) => normalizeKorpus(e.korpus) === targetKorpus
    );
    if (withKorpus.length > 0) {
      // Внутри корпуса ищем по диапазонам
      for (const e of withKorpus) {
        if (aptFitsEntrance(e, apt)) return e;
      }
      // Корпус нашли но квартира не подходит — возвращаем null
      return null;
    }
    // Если в БД нет подъездов с таким korpus — продолжаем без него
  }

  // Шаг 5: поиск по диапазонам без учёта korpus
  for (const e of candidates) {
    if (aptFitsEntrance(e, apt)) return e;
  }

  return null;
}

function haversineMeters(
  a: { lat: number; lng: number },
  b: { lat: number; lng: number }
): number {
  const R = 6371000;
  const toRad = (deg: number) => (deg * Math.PI) / 180;
  const dLat = toRad(b.lat - a.lat);
  const dLng = toRad(b.lng - a.lng);
  const lat1 = toRad(a.lat);
  const lat2 = toRad(b.lat);
  const x =
    Math.sin(dLat / 2) ** 2 + Math.sin(dLng / 2) ** 2 * Math.cos(lat1) * Math.cos(lat2);
  return 2 * R * Math.asin(Math.sqrt(x));
}