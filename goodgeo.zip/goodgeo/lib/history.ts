import { supabase } from './supabase';

export type HistoryEntry = {
  id: string;
  user_id: string;
  address: string;
  lat: number;
  lng: number;
  visited_at: string;
};

// Добавить запись в историю при выборе адреса
export async function addHistoryEntry(params: {
  address: string;
  lat: number;
  lng: number;
}): Promise<void> {
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return;

  const { error } = await supabase.from('history').insert({
    user_id: user.id,
    address: params.address,
    lat: params.lat,
    lng: params.lng,
    // visited_at заполнится автоматически (default now())
  });

  if (error) console.warn('addHistoryEntry:', error.message);
  // Триггер trim_history_to_20 в БД сам удалит старые записи
}

// Загрузить последние 20 записей текущего пользователя (новые сверху)
export async function loadHistory(): Promise<HistoryEntry[]> {
  const { data, error } = await supabase
    .from('history')
    .select('id, user_id, address, lat, lng, visited_at')
    .order('visited_at', { ascending: false })
    .limit(20);

  if (error) {
    console.warn('loadHistory:', error.message);
    return [];
  }
  return data ?? [];
}