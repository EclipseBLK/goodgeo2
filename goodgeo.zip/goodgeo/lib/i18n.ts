import i18n from 'i18next';
import { initReactI18next } from 'react-i18next';

import pl from '../locales/pl.json';
import ru from '../locales/ru.json';
import en from '../locales/en.json';
import uk from '../locales/uk.json';

i18n.use(initReactI18next).init({
  resources: {
    pl: { translation: pl },
    ru: { translation: ru },
    en: { translation: en },
    uk: { translation: uk },
  },
  lng: 'pl',
  fallbackLng: 'en',
  interpolation: { escapeValue: false },
  compatibilityJSON: 'v4',
});

export default i18n;