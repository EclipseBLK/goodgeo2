import { useSyncExternalStore } from 'react';

let isNavigating = false;
const listeners = new Set<() => void>();

export function setNavigatingState(value: boolean) {
  if (isNavigating === value) return;
  isNavigating = value;
  listeners.forEach((l) => l());
}

export function useIsNavigating(): boolean {
  return useSyncExternalStore(
    (cb) => {
      listeners.add(cb);
      return () => listeners.delete(cb);
    },
    () => isNavigating,
    () => isNavigating
  );
}