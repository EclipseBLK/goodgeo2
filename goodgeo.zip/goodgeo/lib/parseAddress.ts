// Парсит адреса с поддержкой корпусов:
// "Marszałkowska 81/8"          → { house: "81",  korpus: null, apt: 8 }
// "Marszałkowska 181C/15"       → { house: "181", korpus: "C",  apt: 15 }
// "Marszałkowska 181/C/15"      → { house: "181", korpus: "C",  apt: 15 }
// "Marszałkowska 181, korp. C"  → { house: "181", korpus: "C",  apt: null }

export type ParsedAddress = {
  raw: string;
  street: string;
  house: string | null;
  korpus: string | null;
  apt: number | null;
};

// Нормализация буквы корпуса: кириллица С → латинская C, верхний регистр
function normalizeKorpus(letter: string): string {
  const map: Record<string, string> = {
    'А': 'A', 'В': 'B', 'С': 'C', 'Е': 'E', 'Н': 'H',
    'К': 'K', 'М': 'M', 'О': 'O', 'Р': 'P', 'Т': 'T', 'Х': 'X',
    'а': 'a', 'в': 'b', 'с': 'c', 'е': 'e', 'к': 'k',
    'м': 'm', 'о': 'o', 'р': 'p', 'т': 't', 'х': 'x',
  };
  let r = '';
  for (const ch of letter) r += map[ch] ?? ch;
  return r.toUpperCase();
}

export function parseAddress(input: string): ParsedAddress {
  const raw = input.trim();
  if (!raw) return { raw, street: '', house: null, korpus: null, apt: null };

  // Нормализуем "korp.", "корп.", "klatka" → "/"
  const cleaned = raw
    .replace(/,\s*(?:korp\.?|корп\.?|klatka|kl\.?)\s*/gi, '/')
    .replace(/\s+(?:korp\.?|корп\.?|klatka|kl\.?)\s*/gi, '/')
    .replace(/,\s*(?:kw|кв|apt|m\.?)\.?\s*/gi, '/')
    .replace(/\s+(?:kw|кв|apt|m\.?)\.?\s*/gi, '/');

  // Шаблон 1: "Marszałkowska 181/C/15" — явное разделение слешами
  const explicitKorpus = cleaned.match(/^(.+?)\s+(\d+)\s*\/\s*([A-Za-zА-Яа-я])\s*\/\s*(\d+)\s*$/);
  if (explicitKorpus) {
    return {
      raw,
      street: explicitKorpus[1].trim(),
      house: explicitKorpus[2],
      korpus: normalizeKorpus(explicitKorpus[3]),
      apt: parseInt(explicitKorpus[4], 10),
    };
  }

  // Шаблон 2: "Marszałkowska 181C/15" — буква слитно с домом, потом кв.
  const stickyKorpus = cleaned.match(/^(.+?)\s+(\d+)([A-Za-zА-Яа-я])\s*\/\s*(\d+)\s*$/);
  if (stickyKorpus) {
    return {
      raw,
      street: stickyKorpus[1].trim(),
      house: stickyKorpus[2],
      korpus: normalizeKorpus(stickyKorpus[3]),
      apt: parseInt(stickyKorpus[4], 10),
    };
  }

  // Шаблон 3: "Marszałkowska 181C" — только дом+корпус, без квартиры
  const stickyNoApt = cleaned.match(/^(.+?)\s+(\d+)([A-Za-zА-Яа-я])\s*$/);
  if (stickyNoApt) {
    return {
      raw,
      street: stickyNoApt[1].trim(),
      house: stickyNoApt[2],
      korpus: normalizeKorpus(stickyNoApt[3]),
      apt: null,
    };
  }

  // Шаблон 4: "Marszałkowska 81/8" — стандартный (без корпуса)
  const slashMatch = cleaned.match(/^(.+?)\s+(\d+)\s*\/\s*(\d+)\s*$/);
  if (slashMatch) {
    return {
      raw,
      street: slashMatch[1].trim(),
      house: slashMatch[2],
      korpus: null,
      apt: parseInt(slashMatch[3], 10),
    };
  }

  // Шаблон 5: "Marszałkowska 81 8" — пробел вместо слеша
  const houseAptMatch = cleaned.match(/^(.+?)\s+(\d+)\s+(\d+)\s*$/);
  if (houseAptMatch) {
    return {
      raw,
      street: houseAptMatch[1].trim(),
      house: houseAptMatch[2],
      korpus: null,
      apt: parseInt(houseAptMatch[3], 10),
    };
  }

  // Шаблон 6: только улица + дом
  const houseOnlyMatch = cleaned.match(/^(.+?)\s+(\d+)\s*$/);
  if (houseOnlyMatch) {
    return {
      raw,
      street: houseOnlyMatch[1].trim(),
      house: houseOnlyMatch[2],
      korpus: null,
      apt: null,
    };
  }

  return { raw, street: cleaned, house: null, korpus: null, apt: null };
}