import type { Language } from './settings';

/**
 * Возвращает форму существительного "день/дня/дней" в зависимости от числа и языка.
 * Использует ключи из переводов: days.one, days.few, days.many
 */
export function pluralKey(n: number, lang: Language): 'one' | 'few' | 'many' {
  // Польский, русский, украинский — славянские правила
  if (lang === 'pl' || lang === 'ru' || lang === 'uk') {
    const mod10 = n % 10;
    const mod100 = n % 100;
    if (mod10 === 1 && mod100 !== 11) return 'one';
    if (mod10 >= 2 && mod10 <= 4 && (mod100 < 12 || mod100 > 14)) return 'few';
    return 'many';
  }
  // English
  return n === 1 ? 'one' : 'many';
}