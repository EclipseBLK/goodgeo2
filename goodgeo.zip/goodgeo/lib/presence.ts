import { useEffect, useRef } from 'react';
import { AppState, AppStateStatus } from 'react-native';
import { supabase } from './supabase';
import { useAuth } from './auth';

const PING_INTERVAL_MS = 3 * 60 * 1000; // 3 минуты
const MIN_GAP_MS = 60 * 1000; // не чаще раза в минуту

export function usePresencePing() {
  const { session } = useAuth();
  const userId = session?.user?.id;
  const lastPingRef = useRef<number>(0);

  useEffect(() => {
    if (!userId) return;

    const ping = async () => {
      const now = Date.now();
      if (now - lastPingRef.current < MIN_GAP_MS) return;
      lastPingRef.current = now;

      try {
        const { error } = await supabase
          .from('profiles')
          .update({ last_seen_at: new Date().toISOString() })
          .eq('id', userId);

        if (error) {
          console.warn('🟢 Presence ping ERROR:', error.message);
        } else {
          console.log('🟢 Presence ping OK at', new Date().toLocaleTimeString());
        }
      } catch (e) {
        console.warn('🟢 Presence ping crashed:', e);
      }
    };

    // Первый пинг сразу
    ping();

    // Каждые 3 минуты
    const interval = setInterval(ping, PING_INTERVAL_MS);

    // Возврат из фона
    const sub = AppState.addEventListener('change', (state: AppStateStatus) => {
      if (state === 'active') ping();
    });

    return () => {
      clearInterval(interval);
      sub.remove();
    };
  }, [userId]);
}

export default function PresencePing() {
  usePresencePing();
  return null;
}