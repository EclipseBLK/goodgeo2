import { useEffect, useState, useCallback } from 'react';
import { supabase } from './supabase';
import { useAuth } from './auth';

export type Profile = {
  id: string;
  email: string;
  name: string | null;
  avatar_url: string | null;
  subscription_status: 'trial' | 'active' | 'expired' | 'cancelled';
  trial_ends_at: string | null;
  subscription_ends_at: string | null;
  created_at: string;
  // Creator-фича
  role: 'user' | 'creator' | 'admin';
  client_number: string | null;
  suggestions_total_count: number;
  suggestions_approved_count: number;
  bonus_days_earned: number;
  is_creator_applied: boolean;
  creator_applied_at: string | null;
};

export function useProfile() {
  const { session } = useAuth();
  const [profile, setProfile] = useState<Profile | null>(null);
  const [loading, setLoading] = useState(true);

  const fetchProfile = useCallback(async () => {
    if (!session?.user) {
      setProfile(null);
      setLoading(false);
      return;
    }

    const { data, error } = await supabase
      .from('profiles')
      .select('*')
      .eq('id', session.user.id)
      .single();

    if (!error && data) {
      setProfile(data as Profile);
    }
    setLoading(false);
  }, [session?.user?.id]);

  useEffect(() => {
    fetchProfile();
  }, [fetchProfile]);

  // Realtime подписка на изменения собственного профиля
  useEffect(() => {
    const userId = session?.user?.id;
    if (!userId) return;

    const channel = supabase
      .channel(`profile-${userId}-${Math.random().toString(36).slice(2, 8)}`)
      .on(
        'postgres_changes',
        {
          event: 'UPDATE',
          schema: 'public',
          table: 'profiles',
          filter: `id=eq.${userId}`,
        },
        () => {
          fetchProfile();
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [session?.user?.id, fetchProfile]);

  // Возвращаем функцию refetch чтобы можно было обновить профиль после действий
  return { profile, loading, refetch: fetchProfile };
}

/**
 * Возвращает количество дней до конца триала.
 * Отрицательное значение — триал уже истёк.
 */
export function getDaysLeft(trialEndsAt: string | null): number {
  if (!trialEndsAt) return 0;
  const ms = new Date(trialEndsAt).getTime() - Date.now();
  return Math.ceil(ms / (1000 * 60 * 60 * 24));
}

/**
 * Имеет ли юзер права creator (или выше).
 */
export function isCreator(profile: Profile | null): boolean {
  if (!profile) return false;
  return profile.role === 'creator' || profile.role === 'admin';
}

/**
 * Сколько подъездов осталось до следующего бонусного дня (1 день за 10 принятых).
 */
export function getNextBonusIn(approvedCount: number): number {
  return 10 - (approvedCount % 10);
}