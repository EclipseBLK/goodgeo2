const TOKEN = process.env.EXPO_PUBLIC_MAPBOX_TOKEN!;
const WARSAW_BBOX = '20.85,52.10,21.27,52.37';

export type GeocodeResult = {
  id: string;
  placeName: string;
  street: string;
  house: string | null;
  lat: number;
  lng: number;
};

export async function searchAddresses(query: string): Promise<GeocodeResult[]> {
  const trimmed = query.trim();
  if (trimmed.length < 3) return [];

  const url =
    `https://api.mapbox.com/geocoding/v5/mapbox.places/${encodeURIComponent(trimmed)}.json` +
    `?access_token=${TOKEN}` +
    `&language=pl` +
    `&country=pl` +
    `&bbox=${WARSAW_BBOX}` +
    `&types=address` +
    `&limit=5`;

  try {
    const res = await fetch(url);
    if (!res.ok) return [];
    const data = await res.json();
    return (data.features ?? []).map((f: any) => ({
      id: f.id,
      placeName: f.place_name,
      street: f.text ?? '',
      house: f.address ?? null,
      lat: f.center[1],
      lng: f.center[0],
    }));
  } catch {
    return [];
  }
}