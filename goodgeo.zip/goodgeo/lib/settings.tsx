import { createContext, useContext, useEffect, useState, ReactNode } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useColorScheme } from 'react-native';
import { darkColors, lightColors, Colors } from '../theme/colors';import i18n from '../lib/i18n';

export type Language = 'pl' | 'ru' | 'en' | 'uk';
export type ThemeMode = 'dark' | 'light' | 'auto';
export type MapStyle = 'day' | 'night' | 'satellite';

type Settings = {
  language: Language;
  theme: ThemeMode;
  pushEnabled: boolean;
  mapStyle: MapStyle;
  autoNightMode: boolean;
};

const DEFAULTS: Settings = {
  language: 'pl',
  theme: 'dark',
  pushEnabled: true,
  mapStyle: 'day',
  autoNightMode: false,
};

const STORAGE_KEY = 'goodgeo_settings';

type SettingsContextType = {
  settings: Settings;
  colors: Colors;
  isDark: boolean;
  loading: boolean;
  setLanguage: (lang: Language) => Promise<void>;
  setTheme: (theme: ThemeMode) => Promise<void>;
  setPushEnabled: (enabled: boolean) => Promise<void>;
  setMapStyle: (style: MapStyle) => Promise<void>;
  setAutoNightMode: (enabled: boolean) => Promise<void>;
};

const SettingsContext = createContext<SettingsContextType | null>(null);

export function SettingsProvider({ children }: { children: ReactNode }) {
  const [settings, setSettings] = useState<Settings>(DEFAULTS);
  const [loading, setLoading] = useState(true);
  const systemScheme = useColorScheme();

  useEffect(() => {
    AsyncStorage.getItem(STORAGE_KEY).then((raw) => {
      if (raw) {
        try {
          const parsed = { ...DEFAULTS, ...JSON.parse(raw) };
          setSettings(parsed);
          i18n.changeLanguage(parsed.language);
        } catch {}
      } else {
        i18n.changeLanguage(DEFAULTS.language);
      }
      setLoading(false);
    });
  }, []);

  const update = async (patch: Partial<Settings>) => {
    const next = { ...settings, ...patch };
    setSettings(next);
    await AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(next));
    if (patch.language) {
      i18n.changeLanguage(patch.language);
    }
  };

  const isDark =
    settings.theme === 'dark' ||
    (settings.theme === 'auto' && systemScheme !== 'light');

  const colors = isDark ? darkColors : lightColors;

  return (
    <SettingsContext.Provider
      value={{
        settings,
        colors,
        isDark,
        loading,
        setLanguage: (language) => update({ language }),
        setTheme: (theme) => update({ theme }),
        setPushEnabled: (pushEnabled) => update({ pushEnabled }),
        setMapStyle: (mapStyle) => update({ mapStyle, autoNightMode: false }), // ручной выбор всегда выключает авто
        setAutoNightMode: (autoNightMode) => update({ autoNightMode }),
      }}
    >
      {children}
    </SettingsContext.Provider>
  );
}

export function useSettings() {
  const ctx = useContext(SettingsContext);
  if (!ctx) throw new Error('useSettings must be used inside SettingsProvider');
  return ctx;
}