import { useEffect, useState } from 'react';
import { supabase } from './supabase';
import { useAuth } from './auth';

export type Stats = {
  daysInApp: number;
  visitedToday: number;
  visitedTotal: number;
};

export function useStats(createdAt: string | null | undefined) {
  const { session } = useAuth();
  const [stats, setStats] = useState<Stats>({
    daysInApp: 0,
    visitedToday: 0,
    visitedTotal: 0,
  });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!session?.user) {
      setLoading(false);
      return;
    }

    let cancelled = false;

    const fetchStats = async () => {
      // Стаж в приложении
      const daysInApp = createdAt ? calcDays(createdAt) : 0;

      // Начало сегодняшнего дня (UTC)
      const todayStart = new Date();
      todayStart.setHours(0, 0, 0, 0);

      // Адресов посещено сегодня
      const { count: todayCount } = await supabase
        .from('history')
        .select('*', { count: 'exact', head: true })
        .eq('user_id', session.user.id)
        .gte('visited_at', todayStart.toISOString());

      // Адресов посещено всего
      const { count: totalCount } = await supabase
        .from('history')
        .select('*', { count: 'exact', head: true })
        .eq('user_id', session.user.id);

      if (cancelled) return;

      setStats({
        daysInApp,
        visitedToday: todayCount ?? 0,
        visitedTotal: totalCount ?? 0,
      });
      setLoading(false);
    };

    fetchStats();
    return () => { cancelled = true; };
  }, [session?.user?.id, createdAt]);

  return { stats, loading };
}

function calcDays(createdAt: string): number {
  const ms = Date.now() - new Date(createdAt).getTime();
  return Math.max(1, Math.floor(ms / (1000 * 60 * 60 * 24)));
}

export function pluralDaysShort(n: number): string {
  const mod10 = n % 10;
  const mod100 = n % 100;
  if (mod10 === 1 && mod100 !== 11) return 'день';
  if (mod10 >= 2 && mod10 <= 4 && (mod100 < 12 || mod100 > 14)) return 'дня';
  return 'дней';
}