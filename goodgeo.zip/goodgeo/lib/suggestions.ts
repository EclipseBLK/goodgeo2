import { supabase } from './supabase';

// =====================================================
// === ТИПЫ ===
// =====================================================

export type SuggestionRangeInput = {
  apt_from: number;
  apt_to: number;
  order_index: number;
};

export type SuggestionInput = {
  entrance_number: string | null;
  apt_extras?: string[];
  korpus?: string | null;
  lat: number;
  lng: number;
  mapbox_building_id?: string | null;
  address?: string | null;
  ranges?: SuggestionRangeInput[];
};

export type LeaderboardEntry = {
  user_id: string;
  client_number: string | null;
  name: string | null;
  approved_count: number;
  total_count: number;
  rank: number;
};

export type CreatorStats = {
  client_number: string | null;
  role: string;
  is_creator_applied: boolean;
  total_count: number;
  approved_count: number;
  bonus_days_earned: number;
  next_bonus_in: number;
};

export type VerificationVote = 'correct' | 'wrong_coords' | 'wrong_apt_range' | 'not_exists';

// =====================================================
// === SUBMIT SUGGESTION ===
// =====================================================

/**
 * Курьер создаёт предложение нового подъезда.
 * Проверки (роль, дубли) выполняются на сервере через RLS + триггеры.
 */
export async function submitSuggestion(input: SuggestionInput) {
  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) return { error: 'not_authenticated' };

  // Проверяем что юзер creator или admin
  const { data: profile } = await supabase
    .from('profiles')
    .select('role')
    .eq('id', user.id)
    .single();

  if (!profile || (profile.role !== 'creator' && profile.role !== 'admin')) {
    return { error: 'not_creator' };
  }

  // === 1) Проверка: дом помечен как готовый ===
  if (input.mapbox_building_id) {
    const { data: completed } = await supabase
      .from('completed_buildings')
      .select('mapbox_building_id')
      .eq('mapbox_building_id', input.mapbox_building_id)
      .maybeSingle();

    if (completed) return { error: 'building_completed' };
  }

  // === 2) Проверка дубля: радиус 5м + тот же entrance_number + пересечение apt_ranges ===
  const radiusDeg = 0.00005; // ~5м (примерно)
  const inputRanges = input.ranges ?? [];

  // Загружаем рядом стоящие entrances
  const { data: nearbyEntrances } = await supabase
    .from('entrances')
    .select('id, lat, lng, entrance_number')
    .gte('lat', input.lat - radiusDeg)
    .lte('lat', input.lat + radiusDeg)
    .gte('lng', input.lng - radiusDeg)
    .lte('lng', input.lng + radiusDeg);

  // Загружаем рядом стоящие pending suggestions от ДРУГИХ юзеров
  const { data: nearbyPending } = await supabase
    .from('entrance_suggestions')
    .select('id, lat, lng, entrance_number, suggested_by')
    .eq('status', 'pending')
    .neq('suggested_by', user.id) // свои pending НЕ блокируют — позволяем перезаписывать
    .gte('lat', input.lat - radiusDeg)
    .lte('lat', input.lat + radiusDeg)
    .gte('lng', input.lng - radiusDeg)
    .lte('lng', input.lng + radiusDeg);

  // Собираем кандидатов на проверку дубля
  type Candidate = {
    id: string;
    lat: number;
    lng: number;
    entrance_number: string | null;
    source: 'entrance' | 'suggestion';
  };
  const candidates: Candidate[] = [];
  for (const e of nearbyEntrances ?? []) {
    candidates.push({ ...e, source: 'entrance' });
  }
  for (const s of nearbyPending ?? []) {
    candidates.push({
      id: s.id,
      lat: s.lat,
      lng: s.lng,
      entrance_number: s.entrance_number,
      source: 'suggestion',
    });
  }

  if (candidates.length > 0 && input.entrance_number) {
    // Фильтр 1: по расстоянию <5м
    const close = candidates.filter(
      (c) => haversineMeters(input.lat, input.lng, c.lat, c.lng) <= 5
    );

    // Фильтр 2: тот же entrance_number (нормализация)
    const sameNumber = close.filter(
      (c) =>
        (c.entrance_number ?? '').trim().toLowerCase() ===
        (input.entrance_number ?? '').trim().toLowerCase()
    );

    if (sameNumber.length > 0) {
      // Фильтр 3: пересечение диапазонов
      const candidateIds = sameNumber.map((c) => c.id);
      const entranceIds = sameNumber.filter((c) => c.source === 'entrance').map((c) => c.id);
      const suggestionIds = sameNumber.filter((c) => c.source === 'suggestion').map((c) => c.id);

      // Загружаем диапазоны для всех кандидатов
      const allRanges: { ownerId: string; apt_from: number; apt_to: number }[] = [];

      if (entranceIds.length > 0) {
        const { data: r } = await supabase
          .from('entrance_apt_ranges')
          .select('entrance_id, apt_from, apt_to')
          .in('entrance_id', entranceIds);
        for (const x of r ?? [])
          allRanges.push({ ownerId: x.entrance_id, apt_from: x.apt_from, apt_to: x.apt_to });
      }
      if (suggestionIds.length > 0) {
        const { data: r } = await supabase
          .from('entrance_suggestion_apt_ranges')
          .select('suggestion_id, apt_from, apt_to')
          .in('suggestion_id', suggestionIds);
        for (const x of r ?? [])
          allRanges.push({ ownerId: x.suggestion_id, apt_from: x.apt_from, apt_to: x.apt_to });
      }

      // Проверяем пересечение хотя бы с одним кандидатом
      const hasOverlap = candidateIds.some((cid) => {
        const candRanges = allRanges.filter((r) => r.ownerId === cid);
        if (candRanges.length === 0) return false; // у кандидата нет диапазонов — не дубль
        if (inputRanges.length === 0) return false; // у нас нет диапазонов — не дубль
        return candRanges.some((cr) =>
          inputRanges.some((ir) =>
            // пересечение интервалов: [a,b] ∩ [c,d] != ∅ ⇔ a ≤ d && c ≤ b
            ir.apt_from <= cr.apt_to && cr.apt_from <= ir.apt_to
          )
        );
      });

      if (hasOverlap) return { error: 'duplicate_exact' };
    }
  }

  // === 3) Если есть свой pending в этой же точке — удаляем его (перезапись) ===
  // Это позволяет креатору повторно подать после ошибки.
  const { data: ownPending } = await supabase
    .from('entrance_suggestions')
    .select('id, lat, lng')
    .eq('status', 'pending')
    .eq('suggested_by', user.id)
    .gte('lat', input.lat - radiusDeg)
    .lte('lat', input.lat + radiusDeg)
    .gte('lng', input.lng - radiusDeg)
    .lte('lng', input.lng + radiusDeg);

  if (ownPending && ownPending.length > 0) {
    const closeOwn = ownPending.filter(
      (s) => haversineMeters(input.lat, input.lng, s.lat, s.lng) <= 10
    );
    if (closeOwn.length > 0) {
      const ids = closeOwn.map((s) => s.id);
      // Cascade удалит и связанные ranges
      await supabase.from('entrance_suggestions').delete().in('id', ids);
    }
  }

  // === Определяем адрес ===
  // Приоритет: 1) явный input.address от юзера 2) адрес соседних подъездов того же здания 3) reverse geocoding
  let resolvedAddress: string | null = input.address ?? null;

  if (!resolvedAddress && input.mapbox_building_id) {
    // Ищем подъезды того же здания с уже известным адресом
    const { data: siblings } = await supabase
      .from('entrances')
      .select('address')
      .eq('mapbox_building_id', input.mapbox_building_id)
      .not('address', 'is', null);

    if (siblings && siblings.length > 0) {
      // Берём самый частый адрес (на случай если фасады разные — Marszałkowska 20 vs 20A)
      const counts = new Map<string, number>();
      for (const s of siblings) {
        if (!s.address) continue;
        counts.set(s.address, (counts.get(s.address) ?? 0) + 1);
      }
      let bestAddr: string | null = null;
      let bestCount = 0;
      for (const [addr, count] of counts) {
        if (count > bestCount) {
          bestCount = count;
          bestAddr = addr;
        }
      }
      resolvedAddress = bestAddr;
    }
  }

  // Fallback: reverse geocoding если ничего не нашли
  if (!resolvedAddress) {
    resolvedAddress = await reverseGeocode(input.lat, input.lng);
  }

  // Создаём suggestion
  const { data: suggestion, error: insertError } = await supabase
    .from('entrance_suggestions')
    .insert({
      entrance_number: input.entrance_number,
      apt_extras: input.apt_extras ?? [],
      korpus: input.korpus ?? null,
      lat: input.lat,
      lng: input.lng,
      mapbox_building_id: input.mapbox_building_id ?? null,
      address: resolvedAddress,
      suggested_by: user.id,
    })
    .select()
    .single();

  if (insertError) return { error: insertError.message };

  // Вставляем диапазоны
  if (input.ranges && input.ranges.length > 0) {
    const ranges = input.ranges.map((r) => ({
      suggestion_id: suggestion.id,
      apt_from: r.apt_from,
      apt_to: r.apt_to,
      order_index: r.order_index,
    }));

    const { error: rangesError } = await supabase
      .from('entrance_suggestion_apt_ranges')
      .insert(ranges);

    if (rangesError) {
      await supabase.from('entrance_suggestions').delete().eq('id', suggestion.id);
      return { error: 'ranges_failed: ' + rangesError.message };
    }
  }

  // Инкрементим counter напрямую (RPC можем добавить позже)
  const { data: p } = await supabase
    .from('profiles')
    .select('suggestions_total_count')
    .eq('id', user.id)
    .single();
  if (p) {
    await supabase
      .from('profiles')
      .update({ suggestions_total_count: (p.suggestions_total_count ?? 0) + 1 })
      .eq('id', user.id);
  }

  return { data: suggestion };
}

// =====================================================
// === ROLE / APPLICATION ===
// =====================================================

/**
 * Подать заявку на роль creator.
 */
export async function applyForCreator() {
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) return { error: 'not_authenticated' };

  const { data: profile } = await supabase
    .from('profiles')
    .select('role, is_creator_applied')
    .eq('id', user.id)
    .single();

  if (!profile) return { error: 'profile_not_found' };

  if (profile.role === 'creator' || profile.role === 'admin') {
    return { error: 'already_creator' };
  }

  if (profile.is_creator_applied) {
    return { error: 'already_applied' };
  }

  const { error } = await supabase
    .from('profiles')
    .update({
      is_creator_applied: true,
      creator_applied_at: new Date().toISOString(),
    })
    .eq('id', user.id);

  if (error) return { error: error.message };

  return { success: true };
}

// =====================================================
// === STATS / LEADERBOARD ===
// =====================================================

export async function getCreatorStats(): Promise<CreatorStats | null> {
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) return null;

  const { data } = await supabase
    .from('profiles')
    .select(
      'client_number, role, is_creator_applied, suggestions_total_count, suggestions_approved_count, bonus_days_earned'
    )
    .eq('id', user.id)
    .single();

  if (!data) return null;

  const approved = data.suggestions_approved_count ?? 0;
  return {
    client_number: data.client_number,
    role: data.role,
    is_creator_applied: data.is_creator_applied ?? false,
    total_count: data.suggestions_total_count ?? 0,
    approved_count: approved,
    bonus_days_earned: data.bonus_days_earned ?? 0,
    next_bonus_in: 10 - (approved % 10),
  };
}

export async function getLeaderboard(limit: number = 50): Promise<LeaderboardEntry[]> {
  const { data } = await supabase
    .from('profiles')
    .select(
      'id, client_number, name, suggestions_approved_count, suggestions_total_count, role'
    )
    .in('role', ['creator', 'admin'])
    .gt('suggestions_approved_count', 0)
    .order('suggestions_approved_count', { ascending: false })
    .limit(limit);

  if (!data) return [];

  return data.map((p, idx) => ({
    user_id: p.id,
    client_number: p.client_number,
    name: p.name,
    approved_count: p.suggestions_approved_count ?? 0,
    total_count: p.suggestions_total_count ?? 0,
    rank: idx + 1,
  }));
}

// =====================================================
// === VERIFICATIONS (для будущей сессии) ===
// =====================================================

export async function submitVerification(entranceId: string, vote: VerificationVote) {
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) return { error: 'not_authenticated' };

  const { error } = await supabase
    .from('entrance_verifications')
    .insert({ entrance_id: entranceId, user_id: user.id, vote });

  if (error) {
    if (error.code === '23505') return { success: true, alreadyVoted: true };
    return { error: error.message };
  }

  return { success: true };
}

export async function hasUserVerified(entranceId: string): Promise<boolean> {
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) return false;

  const { data } = await supabase
    .from('entrance_verifications')
    .select('id')
    .eq('entrance_id', entranceId)
    .eq('user_id', user.id)
    .maybeSingle();

  return !!data;
}

// =====================================================
// === HELPERS ===
// =====================================================

function haversineMeters(lat1: number, lng1: number, lat2: number, lng2: number): number {
  const R = 6371000;
  const toRad = (deg: number) => (deg * Math.PI) / 180;
  const dLat = toRad(lat2 - lat1);
  const dLng = toRad(lng2 - lng1);
  const a = toRad(lat1);
  const b = toRad(lat2);
  const x =
    Math.sin(dLat / 2) ** 2 + Math.sin(dLng / 2) ** 2 * Math.cos(a) * Math.cos(b);
  return 2 * R * Math.asin(Math.sqrt(x));
}
async function reverseGeocode(lat: number, lng: number): Promise<string | null> {
  const token = process.env.EXPO_PUBLIC_MAPBOX_TOKEN;
  if (!token) return null;
  try {
    const url = `https://api.mapbox.com/geocoding/v5/mapbox.places/${lng},${lat}.json?access_token=${token}&language=pl&types=address&limit=1`;
    const res = await fetch(url);
    if (!res.ok) return null;
    const data = await res.json();
    const feature = data.features?.[0];
    if (!feature) return null;
    const street = (feature.text ?? '').trim();
    const number = (feature.address ?? '').trim();
    const combined = `${street} ${number}`.trim();
    return combined || feature.place_name || null;
  } catch {
    return null;
  }
}