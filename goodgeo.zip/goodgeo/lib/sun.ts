/**
 * Расчёт день/ночь по астрономическим параметрам.
 * Без библиотек, упрощённая формула NOAA. Точность ±5 минут.
 */

export function isNightAt(lat: number, lng: number, date: Date = new Date()): boolean {
  const sunPos = getSunPosition(lat, lng, date);
  // Считаем "ночью" когда солнце ниже горизонта (altitude < 0)
  return sunPos.altitude < 0;
}

export function getSunPosition(lat: number, lng: number, date: Date) {
  // Юлианская дата
  const jd = toJulianDate(date);
  const T = (jd - 2451545.0) / 36525;

  // Средняя долгота солнца
  const L0 = norm360(280.46646 + T * (36000.76983 + T * 0.0003032));
  // Средняя аномалия
  const M = norm360(357.52911 + T * (35999.05029 - 0.0001537 * T));
  // Эксцентриситет орбиты
  const e = 0.016708634 - T * (0.000042037 + 0.0000001267 * T);
  // Уравнение центра
  const Mrad = (M * Math.PI) / 180;
  const C =
    Math.sin(Mrad) * (1.914602 - T * (0.004817 + 0.000014 * T)) +
    Math.sin(2 * Mrad) * (0.019993 - 0.000101 * T) +
    Math.sin(3 * Mrad) * 0.000289;

  // Истинная долгота
  const trueLong = L0 + C;
  // Видимая долгота
  const omega = 125.04 - 1934.136 * T;
  const lambda = trueLong - 0.00569 - 0.00478 * Math.sin((omega * Math.PI) / 180);

  // Наклон оси Земли
  const epsilon =
    23 + (26 + (21.448 - T * (46.815 + T * (0.00059 - T * 0.001813))) / 60) / 60 +
    0.00256 * Math.cos((omega * Math.PI) / 180);

  // Прямое восхождение и склонение
  const lambdaRad = (lambda * Math.PI) / 180;
  const epsilonRad = (epsilon * Math.PI) / 180;
  const declination = Math.asin(Math.sin(epsilonRad) * Math.sin(lambdaRad));

  // Часовой угол
  const hours = date.getUTCHours() + date.getUTCMinutes() / 60 + date.getUTCSeconds() / 3600;
  const localHourAngle = (hours - 12) * 15 + lng;
  const hourAngleRad = (localHourAngle * Math.PI) / 180;
  const latRad = (lat * Math.PI) / 180;

  // Высота солнца над горизонтом (altitude)
  const altitude = Math.asin(
    Math.sin(latRad) * Math.sin(declination) +
      Math.cos(latRad) * Math.cos(declination) * Math.cos(hourAngleRad)
  );

  return { altitude: (altitude * 180) / Math.PI, declination };
}

function toJulianDate(date: Date): number {
  return date.getTime() / 86400000 + 2440587.5;
}

function norm360(deg: number): number {
  return ((deg % 360) + 360) % 360;
}