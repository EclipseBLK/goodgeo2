import { supabase } from './supabase';

export type Vote = 'correct' | 'incorrect';

/**
 * Записать голос курьера за подъезд.
 * Если голос уже был — обновляет (UPSERT по UNIQUE(entrance_id, user_id)).
 */
export async function submitVerification(
  entranceId: string,
  userId: string,
  vote: Vote
): Promise<boolean> {
  const { error } = await supabase
    .from('entrance_verifications')
    .upsert(
      { entrance_id: entranceId, user_id: userId, vote },
      { onConflict: 'entrance_id,user_id' }
    );

  if (error) {
    console.warn('submitVerification error:', error);
    return false;
  }
  return true;
}

/**
 * Проверить, голосовал ли уже этот юзер за этот подъезд.
 */
export async function hasVerifiedEntrance(
  entranceId: string,
  userId: string
): Promise<boolean> {
  const { data, error } = await supabase
    .from('entrance_verifications')
    .select('id')
    .eq('entrance_id', entranceId)
    .eq('user_id', userId)
    .maybeSingle();

  if (error) {
    console.warn('hasVerifiedEntrance error:', error);
    return false;
  }
  return !!data;
}

/**
 * Проверить, является ли подъезд "креаторским" (т.е. подлежащим верификации).
 * Возвращает true только если created_by указывает на юзера с ролью 'creator'.
 * Подъезды от админа или со старыми данными (created_by IS NULL) — не верифицируются.
 */
export async function isCreatorEntrance(entranceId: string): Promise<boolean> {
  const { data, error } = await supabase
    .from('entrances')
    .select('created_by, profiles:created_by(role)')
    .eq('id', entranceId)
    .maybeSingle();

  if (error) {
    console.warn('isCreatorEntrance error:', error);
    return false;
  }
  if (!data?.created_by) return false;

  // Supabase возвращает связанную запись либо как объект, либо как массив (при некоторых конфигах)
  const profile: any = Array.isArray((data as any).profiles)
    ? (data as any).profiles[0]
    : (data as any).profiles;

  return profile?.role === 'creator';
}