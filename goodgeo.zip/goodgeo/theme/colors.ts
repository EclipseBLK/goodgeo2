export const darkColors = {
  primary: '#1B3A5C',
  accent: '#3b9bff',
  background: '#0F1F33',
  surface: '#1B3A5C',
  text: '#FFFFFF',
  textMuted: '#9CA3AF',
  border: '#2A4A6B',
  error: '#EF4444',
};

export const lightColors = {
  primary: '#1B3A5C',
  accent: '#3b9bff',
  background: '#FFFFFF',
  surface: '#F3F4F6',
  text: '#0F1F33',
  textMuted: '#6B7280',
  border: '#E5E7EB',
  error: '#EF4444',
};

export type Colors = typeof darkColors;

// Старый экспорт — оставляем для обратной совместимости (пока заменим импорты).
// После окончания миграции этот экспорт можно удалить.
export const colors = darkColors;